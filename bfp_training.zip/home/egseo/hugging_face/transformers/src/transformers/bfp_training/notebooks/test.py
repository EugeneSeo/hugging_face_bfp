from torchvision import models
import torch
import numpy as np

def load_np(path):
    with open(path, "rb") as f:
        data = np.load(f, allow_pickle=False)
    return data

if __name__ == "__main__":
    for rank in range(4):
        print("rank")
        output0 = load_np(f"case0/fwd-output-{rank}.npy")
        output1 = load_np(f"case1/fwd-output-{rank}.npy")
        print(f"{np.sum(output0.flatten() - output1.flatten()):.5f}")
        print()
        
    # for i in range(62):
    #     data0 = load_np(f"case0/grad-rank0-{i}.npy")
    #     data1 = load_np(f"case1/grad-rank0-{i}.npy")
    #     print(f"{np.sum(data0.flatten() - data1.flatten()):.5f}")
