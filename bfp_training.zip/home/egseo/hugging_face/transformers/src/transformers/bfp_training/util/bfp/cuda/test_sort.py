from numpy import indices
import torch
import numpy as np
from ctypes import *
import copy

import sys
if "/home/yskim/projects/sparse-bfp" not in sys.path:
    sys.path.append("/home/yskim/projects/sparse-bfp")

from util.bfp.bfp_config import BfpConfig
from util.reprod_util import set_reproducibility

# lib = CDLL("./lib_cuda_bfp_converter_sorted.so")
lib = CDLL("./lib_sort.so")

if __name__ == "__main__":
    set_reproducibility(1234)

    device = "cuda"
    shape = (16, 4096)

    inputs = torch.rand(shape).to(device)
    indice = torch.zeros(shape, dtype=torch.int32).to(device)

    chunk_size = 1024

    # for r in range(shape[0]):
    #     for c in range(shape[1]):
    #         if c % (chunk_size ) == 0:
    #             print(f"|", end=" ")

    #         print(f"{inputs.flatten()[r * shape[1] + c].item():.2f}", end=" ")
    #     print("|")
    
    # print()

    lib.sort(
        c_void_p(inputs.data_ptr()),
        c_void_p(indice.data_ptr()),
        c_int(inputs.shape[0]),
        c_int(inputs.shape[1]),
        c_int(chunk_size)
    )

    # print(f"indice")
    # for r in range(shape[0]):
    #     for c in range(shape[1]):
    #         if c % chunk_size == 0:
    #             print(f"|", end=" ")
    #         print(f"{indice[r,c].item():.2f}", end=" ")
    #     print("|")

    # print(f"value")
    sorted = []
    for r in range(shape[0]):
        for c in range(shape[1]):
            sorted.append(inputs.flatten()[indice[r,c].item()].item())
            # if c % chunk_size == 0:
                # print(f"|", end=" ")
            # print(f"{inputs.flatten()[indice[r,c].item()].item():.2f}", end=" ")
        # print("|")

    sorted = torch.tensor(sorted).reshape(shape).numpy()
    inputs = inputs.cpu().numpy()
    manual = copy.deepcopy(inputs)

    for r in range(shape[0]):
        for c in range(0, shape[1], chunk_size):
            size = chunk_size
            if c == shape[1] - chunk_size:
                if shape[1] % chunk_size != 0:
                    size = shape[1] % chunk_size
            manual[r, c:c+size] = np.sort(manual[r, c:c+size])


    for r in range(shape[0]):
        for c in range(shape[1]):
            manual_v = manual[r, c]
            sorted_v = sorted[r, c]
            if manual_v != sorted_v:
                print(f"({r}, {c}) {inputs[r, c]:.2f} -> {manual[r, c]:.2f}, {sorted[r, c]:.2f}")
                exit()
    print("done")