import sys
import torch
from ctypes import *

if "/home/yskim/projects/sparse-bfp" not in sys.path:
    sys.path.append("/home/yskim/projects/sparse-bfp")

from util.bfp.bfp_wrapper import BfpWrapper
from util.bfp.bfp_config import BfpConfig
from util.custom_transpose import custom_transpose

bfp_so_file_path = "/home/yskim/projects/sparse-bfp/util/bfp/bfp_converter.so"
c_lib = CDLL(bfp_so_file_path)

def custom_dot_product(lhs_S_vec: torch.Tensor, lhs_E_vec: torch.Tensor, lhs_M_vec: torch.Tensor,
                       rhs_S_vec: torch.Tensor, rhs_E_vec: torch.Tensor, rhs_M_vec: torch.Tensor,
                       lhs_ori_E: torch.Tensor=None, rhs_ori_E: torch.Tensor=None) -> float:
    # print(f"len: {len(lhs_S_vec)}")
    # exit()

    output = torch.zeros(size=(1, len(lhs_S_vec)), dtype=torch.float32)
    # print("???")

    Ss = lhs_S_vec * rhs_S_vec
    Es = lhs_E_vec + rhs_E_vec
    Ms = lhs_M_vec * rhs_M_vec

    # print(f"S: {Ss.numpy()}")
    # print(f"E    : {lhs_E_vec.numpy()}")
    # print(f"ori E: {lhs_ori_E.numpy()}")
    # print(f"M: {Ms.numpy()}")

    # print("cvt...")
    c_lib.convert_acc_bfp_to_fp_1d(Ss.numpy().ctypes.data_as(POINTER(c_int32)),
                                   Es.numpy().ctypes.data_as(POINTER(c_int32)),
                                   Ms.numpy().ctypes.data_as(POINTER(c_int64)),
                                   output.numpy().ctypes.data_as(POINTER(c_float)),
                                   c_int32(output.shape[0]),
                                   c_int32(output.shape[1]),
                                   c_int32(BfpConfig.group_size),
                                   c_int32(BfpConfig.bfp_M_Bit),
                                   c_int32(BfpConfig.thread_num))
    return torch.sum(output).item()


def custom_gemm(lhs: BfpWrapper, rhs: BfpWrapper) -> torch.Tensor:
    if lhs.bfp_M.shape[1] != rhs.bfp_M.shape[1]:
        raise ValueError(f"cannot matched dim: {lhs.bfp_M.shape} x {rhs.bfp_M.shape}")
    
    lhs.run_convert_fp_to_bfp()
    rhs.run_convert_fp_to_bfp()


    M = lhs.bfp_M.shape[0]
    K = lhs.bfp_M.shape[1]
    N = rhs.bfp_M.shape[0]

    outputs = []

    for m in range(M):
        output_row = []
        for n in range(N):
            output = custom_dot_product(lhs.bfp_S[m,:], lhs.bfp_E[m,:], lhs.bfp_M[m,:],
                                        rhs.bfp_S[n,:], rhs.bfp_E[n,:], rhs.bfp_M[n,:],
                                        lhs.ori_E[m,:], rhs.ori_E[n,:])
            output_row.append(output)

        outputs.append(output_row)

    return torch.tensor(outputs)


cuda_lib = CDLL("/home/yskim/projects/sparse-bfp/util/bfp/cuda/lib_gemm_cuda.so")

def custom_gemm_cuda(lhs: BfpWrapper, rhs: BfpWrapper) -> torch.Tensor:
    if lhs.bfp_M.shape[1] != rhs.bfp_M.shape[1]:
        raise ValueError(f"cannot matched dim: {lhs.bfp_M.shape} x {rhs.bfp_M.shape}")

    M = lhs.bfp_M.shape[0]
    K = lhs.bfp_M.shape[1]
    N = rhs.bfp_M.shape[0]
    bfp_M_bit = BfpConfig.bfp_M_Bit
    group_size = BfpConfig.group_size

    output = torch.zeros(size=(M, N), dtype=torch.float)
    
    lhs.run_convert_fp_to_bfp()
    rhs.run_convert_fp_to_bfp()

    cuda_lib.bfp_gemm_2d(
        lhs.np_bfp_S.ctypes.data_as(POINTER(c_int32)),
        lhs.np_bfp_E.ctypes.data_as(POINTER(c_int32)),
        lhs.np_bfp_M.ctypes.data_as(POINTER(c_int64)),
        rhs.np_bfp_S.ctypes.data_as(POINTER(c_int32)),
        rhs.np_bfp_E.ctypes.data_as(POINTER(c_int32)),
        rhs.np_bfp_M.ctypes.data_as(POINTER(c_int64)),
        output.numpy().ctypes.data_as(POINTER(c_float)),
        c_int32(M),
        c_int32(K),
        c_int32(N),
        c_int32(group_size),
        c_int32(bfp_M_bit),
    )
    """
    void bfp_gemm_2d(
    // LHS: [M x K]
    const int32_t* lhs_S,
    const int32_t* lhs_E,
    const int64_t* lhs_M,

    // RHS: [N x K]
    const int32_t* rhs_S,
    const int32_t* rhs_E,
    const int64_t* rhs_M,

    // output: [M, N]
    float* output,

    const int M,
    const int K,
    const int N,
    const int group_size,
    const int bfp_M_bit
);
    """

    return output

from util.reprod_util import set_reproducibility
import numpy as np

sample_lib = CDLL("/home/yskim/projects/sparse-bfp/util/bfp/sample.so")

if __name__ == "__main__":
    set_reproducibility(1234)
    BfpConfig.bfp_M_Bit = 8
    M = 1024 # 1024 # 923
    K = 1024 * 4
    N = 1024 # 1024 # 1233

    should_sort = False
    scale = 1
    lhs = torch.randn((M, K), dtype=torch.float32) * scale
    # lhs = torch.randint(low=-25, high=25, size=(M, K), dtype=torch.float32)
    lhs_wrapper = BfpWrapper(fp_tensor=lhs, should_sort=should_sort)
    lhs_wrapper_cuda = BfpWrapper(fp_tensor=lhs, should_sort=should_sort)

    rhs = torch.randn((K, N), dtype=torch.float32) * scale
    # rhs = torch.randint(low=-25, high=25, size=(K, N), dtype=torch.float32)
    rhs = custom_transpose(rhs, [1, 0])
    rhs_wrapper = BfpWrapper(fp_tensor=rhs, should_sort=should_sort)
    rhs_wrapper_cuda = BfpWrapper(fp_tensor=rhs, should_sort=should_sort)

    # outputs = custom_gemm(lhs_wrapper, rhs_wrapper)
    outputs_cuda = custom_gemm_cuda(lhs_wrapper_cuda, rhs_wrapper_cuda)

    # for elem in lhs_wrapper_cuda.np_bfp_M.flatten():
    #     if elem < -3 or elem > 3:
    #         print(elem)

    # print("[quant loss]")
    # print(f"[lhs quant loss]\n"
    #       f"mean : {torch.mean(torch.abs(lhs.flatten() - lhs_wrapper.get_fp_from_current_bfp_info().flatten())):.10f}\n"
    #       f"max  : {torch.max(torch.abs(lhs.flatten() - lhs_wrapper.get_fp_from_current_bfp_info().flatten())):.10f}\n"
    #       f"min  : {torch.min(torch.abs(lhs.flatten() - lhs_wrapper.get_fp_from_current_bfp_info().flatten())):.10f}\n")
    # print(f"[rhs quant loss]\n"
    #       f"mean : {torch.mean(torch.abs(rhs.flatten() - rhs_wrapper.get_fp_from_current_bfp_info().flatten())):.10f}\n"
    #       f"max  : {torch.max(torch.abs(rhs.flatten() - rhs_wrapper.get_fp_from_current_bfp_info().flatten())):.10f}\n"
    #       f"min  : {torch.min(torch.abs(rhs.flatten() - rhs_wrapper.get_fp_from_current_bfp_info().flatten())):.10f}\n")

    fp_outputs = torch.matmul(lhs, rhs.t())

    # diff = torch.abs(fp_outputs.flatten() - outputs.flatten())
    diff_cuda = torch.abs(fp_outputs.flatten() - outputs_cuda.flatten())

    # print(f"[diff not sorted]\nmean: {torch.mean(diff):.10f}\nmax: {torch.max(diff):.10f}\nmin: {torch.min(diff):.10f}")
    print(f"[diff not sorted]\nmean: {torch.mean(diff_cuda):.10f}\nmax: {torch.max(diff_cuda):.10f}\nmin: {torch.min(diff_cuda):.10f}")
