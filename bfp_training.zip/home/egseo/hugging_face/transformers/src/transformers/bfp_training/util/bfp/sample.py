# To add a new cell, type '# %%'
# To add a new markdown cell, type '# %% [markdown]'
# %%
from math import ceil
import sys
import numpy as np
from ctypes import *
import ctypes
import torch

if "/home/yskim/projects/sparse-bfp" not in sys.path:
    sys.path.append("/home/yskim/projects/sparse-bfp")
from util.reprod_util import set_reproducibility

c_lib = ctypes.CDLL("/home/yskim/projects/sparse-bfp/util/sample/lib_sample.so")


# %%
# set_reproducibility(1234)
group_size = 16
vec_size = group_size
bfp_M_bit = 8
scale_lhs = 1
scale_rhs = 0.0001

# lhs_vec = torch.randn(vec_size, dtype=torch.float32) * scale_lhs
lhs_vec = torch.abs(torch.randn(vec_size, dtype=torch.float32)) * scale_lhs
lhs_S = torch.zeros(vec_size, dtype=torch.int32)
lhs_E = torch.zeros(vec_size, dtype=torch.int32)
lhs_M = torch.zeros(vec_size, dtype=torch.int64)
c_lib.get_info(
    c_void_p(lhs_vec.data_ptr()),
    c_void_p(lhs_S.data_ptr()),
    c_void_p(lhs_E.data_ptr()),
    c_void_p(lhs_M.data_ptr()),
    c_int32(bfp_M_bit),
    c_int32(group_size)
)
lhs_M_ours = lhs_M.clone().detach()

v = lhs_M.numpy()
print("lhs M")
for i in range(group_size):
    print(f"{i}: {v[i]:08b}")
print(f"lhs S: {lhs_S.numpy()}")
print(f"lhs shared E: {lhs_E.numpy()[0]}")
print()

# rhs_vec = torch.randn(vec_size, dtype=torch.float32) * scale_rhs
rhs_vec = torch.abs(torch.randn(vec_size, dtype=torch.float32)) * scale_rhs
rhs_S = torch.zeros(vec_size, dtype=torch.int32)
rhs_E = torch.zeros(vec_size, dtype=torch.int32)
rhs_M = torch.zeros(vec_size, dtype=torch.int64)
c_lib.get_info(
    c_void_p(rhs_vec.data_ptr()),
    c_void_p(rhs_S.data_ptr()),
    c_void_p(rhs_E.data_ptr()),
    c_void_p(rhs_M.data_ptr()),
    c_int32(bfp_M_bit),
    c_int32(group_size)
)
rhs_M_ours = rhs_M.clone().detach()

v = rhs_M.numpy()
print("rhs M")
for i in range(group_size):
    print(f"{i}: {v[i]:08b}")
print(f"rhs S: {rhs_S.numpy()}")
print(f"rhs shared E: {rhs_E.numpy()[0]}")
print()


#############
# 6-bit
lhs_S_6bit = torch.zeros(vec_size, dtype=torch.int32)
lhs_E_6bit = torch.zeros(vec_size, dtype=torch.int32)
lhs_M_6bit = torch.zeros(vec_size, dtype=torch.int64)
c_lib.get_info(
    c_void_p(lhs_vec.data_ptr()),
    c_void_p(lhs_S_6bit.data_ptr()),
    c_void_p(lhs_E_6bit.data_ptr()),
    c_void_p(lhs_M_6bit.data_ptr()),
    c_int32(6),
    c_int32(group_size)

)

rhs_S_6bit = torch.zeros(vec_size, dtype=torch.int32)
rhs_E_6bit = torch.zeros(vec_size, dtype=torch.int32)
rhs_M_6bit = torch.zeros(vec_size, dtype=torch.int64)
c_lib.get_info(
    c_void_p(rhs_vec.data_ptr()),
    c_void_p(rhs_S_6bit.data_ptr()),
    c_void_p(rhs_E_6bit.data_ptr()),
    c_void_p(rhs_M_6bit.data_ptr()),
    c_int32(6),
    c_int32(group_size)
)

# 4-bit
lhs_S_4bit = torch.zeros(vec_size, dtype=torch.int32)
lhs_E_4bit = torch.zeros(vec_size, dtype=torch.int32)
lhs_M_4bit = torch.zeros(vec_size, dtype=torch.int64)
c_lib.get_info(
    c_void_p(lhs_vec.data_ptr()),
    c_void_p(lhs_S_4bit.data_ptr()),
    c_void_p(lhs_E_4bit.data_ptr()),
    c_void_p(lhs_M_4bit.data_ptr()),
    c_int32(4),
    c_int32(group_size)

)

rhs_S_4bit = torch.zeros(vec_size, dtype=torch.int32)
rhs_E_4bit = torch.zeros(vec_size, dtype=torch.int32)
rhs_M_4bit = torch.zeros(vec_size, dtype=torch.int64)
c_lib.get_info(
    c_void_p(rhs_vec.data_ptr()),
    c_void_p(rhs_S_4bit.data_ptr()),
    c_void_p(rhs_E_4bit.data_ptr()),
    c_void_p(rhs_M_4bit.data_ptr()),
    c_int32(4),
    c_int32(group_size)
)

# 2-bit
lhs_S_2bit = torch.zeros(vec_size, dtype=torch.int32)
lhs_E_2bit = torch.zeros(vec_size, dtype=torch.int32)
lhs_M_2bit = torch.zeros(vec_size, dtype=torch.int64)
c_lib.get_info(
    c_void_p(lhs_vec.data_ptr()),
    c_void_p(lhs_S_2bit.data_ptr()),
    c_void_p(lhs_E_2bit.data_ptr()),
    c_void_p(lhs_M_2bit.data_ptr()),
    c_int32(2),
    c_int32(group_size)

)

rhs_S_2bit = torch.zeros(vec_size, dtype=torch.int32)
rhs_E_2bit = torch.zeros(vec_size, dtype=torch.int32)
rhs_M_2bit = torch.zeros(vec_size, dtype=torch.int64)
c_lib.get_info(
    c_void_p(rhs_vec.data_ptr()),
    c_void_p(rhs_S_2bit.data_ptr()),
    c_void_p(rhs_E_2bit.data_ptr()),
    c_void_p(rhs_M_2bit.data_ptr()),
    c_int32(2),
    c_int32(group_size)
)
#############


# %%
def split_bit_level(value):
    value_str = f"{value:08b}"
    return [
        int(value_str[0:2], 2),
        int(value_str[2:2+2], 2),
        int(value_str[4:4+2], 2),
        int(value_str[6:6+2], 2),
    ]


def decide_precision(M, group_size):
    value_threshold = group_size * 3 * 0.5
    curr_precision = 2

    results = []
    for i in range(group_size):
        results.append(split_bit_level(M[i]))
    print(results)

    zero_pass = [False] * group_size

    for curr_level in range(3):
        for i in range(group_size):
            if results[i][curr_level] != 0:
                zero_pass[i] = True
        
        is_pass_zero = True
        # for i in range(group_size):
        #     if zero_pass[i] == False:
        #         is_pass_zero = False
        #         break

        pass_cnt = 0
        for i in range(group_size):
            if zero_pass[i] == True:
                pass_cnt += 1

        if pass_cnt < 16 * 0.8:
            is_pass_zero = False

        print(f"level: {curr_level}, {pass_cnt}/16, {is_pass_zero}")

        if is_pass_zero:
            value_sum = 0
            for i in range(group_size):
                value_sum += results[i][curr_level]
            
            should_return = value_sum > value_threshold

            print(f"level: {curr_level}, {value_sum}/{int(ceil(value_threshold))}/{group_size * 3}, {should_return}")
            
            if should_return:
                return curr_precision

        curr_precision += 2

    return curr_precision

def change_prec(M, precision, group_size):
    for i in range(group_size):
        value = int(f"{M[i]:08b}"[0:precision], 2)
        M[i] = value
        # print(f"{M[i]:08b} {value:08b}")


lhs_prec = decide_precision(lhs_M_ours, group_size)
print(lhs_prec)
change_prec(lhs_M_ours, lhs_prec, group_size)
# for i in range(group_size):
#     print(f"{lhs_M[i]:08b} {lhs_M_ours[i]:08b}")

rhs_prec = decide_precision(rhs_M_ours, group_size)
change_prec(rhs_M_ours, rhs_prec, group_size)
print(rhs_prec)
# for i in range(group_size):
#     print(f"{rhs_M[i]:08b} {rhs_M_ours[i]:08b}")


def dp(
    lhs_S,
    lhs_E,
    lhs_M,
    lhs_M_bit,
    
    rhs_S,
    rhs_E,
    rhs_M,
    rhs_M_bit,
    
    group_size):

    mantissa = 0

    for i in range(group_size):
        mantissa += (lhs_S[i] * lhs_M[i]) * (rhs_S[i] * rhs_M[i])

    sign = 1.
    if mantissa < 0:
        sign = -1.
        mantissa *= -1

    double_mantissa = mantissa / pow(2., (lhs_M_bit - 1) + (rhs_M_bit - 1))
    print(f"double mantissa: {double_mantissa} {lhs_M_bit} {rhs_M_bit}")

    return sign * pow(2., lhs_E[0] + rhs_E[0]) * double_mantissa


# %%
# print(f"{v[0]:08b}")
# print(split_bit_level(v[0]))

fp_result = torch.dot(lhs_vec, rhs_vec).item()
bfp_8bit_result = dp(
    lhs_S,
    lhs_E,
    lhs_M,
    8, 
    
    rhs_S,
    rhs_E,
    rhs_M,
    8,

    group_size
).item()

bfp_6bit_result = dp(
    lhs_S_6bit,
    lhs_E_6bit,
    lhs_M_6bit,
    6, 
    
    rhs_S_6bit,
    rhs_E_6bit,
    rhs_M_6bit,
    6,

    group_size
).item()

bfp_4bit_result = dp(
    lhs_S_4bit,
    lhs_E_4bit,
    lhs_M_4bit,
    4, 
    
    rhs_S_4bit,
    rhs_E_4bit,
    rhs_M_4bit,
    4,

    group_size
).item()

bfp_2bit_result = dp(
    lhs_S_2bit,
    lhs_E_2bit,
    lhs_M_2bit,
    2, 
    
    rhs_S_2bit,
    rhs_E_2bit,
    rhs_M_2bit,
    2,

    group_size
).item()


bfp_flex_result = dp(
    lhs_S,
    lhs_E,
    lhs_M_ours,
    lhs_prec, 
    
    rhs_S,
    rhs_E,
    rhs_M_ours,
    rhs_prec,

    group_size
).item()


print(f"fp:       {fp_result:.10f}")
print(f"bfp 8bit: {bfp_8bit_result:.10f} (diff: {abs(fp_result - bfp_8bit_result):.10f}, 8-bit)")
print(f"bfp 6bit: {bfp_6bit_result:.10f} (diff: {abs(fp_result - bfp_6bit_result):.10f}, 6-bit)")
print(f"bfp 4bit: {bfp_4bit_result:.10f} (diff: {abs(fp_result - bfp_4bit_result):.10f}, 4-bit)")
print(f"bfp 2bit: {bfp_2bit_result:.10f} (diff: {abs(fp_result - bfp_2bit_result):.10f}, 2-bit)")
print(f"bfp flex: {bfp_flex_result:.10f} (diff: {abs(fp_result - bfp_flex_result):.10f}, {(lhs_prec + rhs_prec) / 2.:.1f}-bit)")


