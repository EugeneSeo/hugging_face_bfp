#include <curand.h>
#include <curand_kernel.h>
#include <cuda_runtime.h>
#include <device_launch_parameters.h>

#include <cstdio>
#include <iostream>
#include <vector>
#include <random>
#include <cmath>

#include <cstdint>

extern "C" {
void sort(
    const float* data_mat,
    int* index_mat,
    const int height,
    const int width,
    const int chunk_size
);
}