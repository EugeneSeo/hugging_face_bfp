import torch
import numpy as np
from ctypes import *


lib = CDLL("/home/yskim/projects/sparse-bfp/util/bfp/cuda/lib_cuda_memory_helper.so")
allocate_cuda = lib.allocate_cuda
allocate_cuda.restype = c_void_p


class CudaStorage:
    def __init__(self, data_count, np_data_type, data_type_byte):
        self.ptr = c_void_p(0)
        self.data_count = data_count
        self.np_data_type = np_data_type
        self.data_type_byte = data_type_byte
        self.ptr = allocate_cuda(
            c_size_t(data_count),
            c_size_t(data_type_byte)
        )

    def __del__(self):
        lib.free_cuda(c_void_p(self.ptr))

    def send(self, np_tensor: np.ndarray):
        if not np_tensor.dtype == self.np_data_type:
            raise ValueError(f"{self} should have {self.np_data_type}, but given {np_tensor.dtype}")

        lib.send(
            c_void_p(self.ptr),
            np_tensor.ctypes.data_as(c_void_p),
            c_size_t(self.data_count),
            c_size_t(self.data_type_byte)
        )

    def recv(self, np_tensor: np.ndarray):
        if not np_tensor.dtype == self.np_data_type:
            raise ValueError(f"{self} should have {self.np_data_type}, but given {np_tensor.dtype}")

        lib.recv(
            np_tensor.ctypes.data_as(c_void_p),
            c_void_p(self.ptr),
            c_size_t(self.data_count),
            c_size_t(self.data_type_byte)
        )


class CudaFloatStorage(CudaStorage):
    data_type_byte = 4

    def __init__(self, data_count):
        super().__init__(data_count, np.float32, CudaFloatStorage.data_type_byte)


class CudaInt32Storage(CudaStorage):
    data_type_byte = 4

    def __init__(self, data_count):
        super().__init__(data_count, np.int32, CudaInt32Storage.data_type_byte)


class CudaInt64Storage(CudaStorage):
    data_type_byte = 8

    def __init__(self, data_count):
        super().__init__(data_count, np.int64, CudaInt64Storage.data_type_byte)


if __name__ == "__main__":
    h = 32
    w = 32
    t = torch.randint(low=-3, high=3, size=(h, w), dtype=torch.float)
    cmp = torch.zeros(size=(h, w), dtype=torch.float)

    t_np = t.numpy()
    cmp_np = cmp.numpy()

    float_storage = CudaFloatStorage(data_count=np.prod(cmp_np.shape))
    float_storage.send(t_np)
    float_storage.recv(cmp_np)

    print(t)
    print(t_np)
    print()
    print(cmp)

    arr = np.ndarray(shape=[4, 3, 22, 22])
    print(arr.shape)
    print(np.prod(arr.shape))
