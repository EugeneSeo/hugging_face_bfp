import sys
import torch
import time
from ctypes import *

# if "/home/yskim/projects/sparse-bfp" not in sys.path:
#     sys.path.append("/home/yskim/projects/sparse-bfp")

from util.bfp.bfp_config import BfpConfig
from util.reprod_util import set_reproducibility
from util.custom_transpose import custom_transpose_2d
from util.bfp.cuda_bfp_wrapper import CudaBfpWrapper
from util.bfp.cuda.cuda_memory_helper import CudaFloatStorage

import os
BFP_HOME = os.environ["BFP_HOME"]
cuda_lib = CDLL(f"{BFP_HOME}/util/bfp/cuda/lib_gemm_cuda.so")


def custom_gemm_cuda(lhs: CudaBfpWrapper, rhs: CudaBfpWrapper, output_storage: CudaFloatStorage) -> torch.Tensor:
    if lhs.bfp_M.shape[1] != rhs.bfp_M.shape[1]:
        raise ValueError(f"cannot matched dim: {lhs.bfp_M.shape} x {rhs.bfp_M.shape}")

    M = lhs.bfp_M.shape[0]
    K = lhs.bfp_M.shape[1]
    N = rhs.bfp_M.shape[0]
    bfp_M_bit = BfpConfig.bfp_M_Bit
    group_size = BfpConfig.group_size

    output = torch.zeros(size=(M, N), dtype=torch.float)
    
    lhs.run_convert_fp_to_bfp()
    rhs.run_convert_fp_to_bfp()

    cuda_lib.bfp_gemm_2d(
        c_void_p(lhs.cuda_bfp_S.ptr),
        c_void_p(lhs.cuda_bfp_E.ptr),
        c_void_p(lhs.cuda_bfp_M.ptr),
        c_void_p(rhs.cuda_bfp_S.ptr),
        c_void_p(rhs.cuda_bfp_E.ptr),
        c_void_p(rhs.cuda_bfp_M.ptr),
        c_void_p(output_storage.ptr),
        c_int32(M),
        c_int32(K),
        c_int32(N),
        c_int32(group_size),
        c_int32(bfp_M_bit),
    )

    output_storage.recv(output.numpy())

    return output

class BfpGemm:
    def __init__(self, lhs_shape: torch.Size, rhs_shape: torch.Size, use_stochastic_rounding: bool, should_sort: bool):
        self.device = "cuda"

        self.should_sort = should_sort

        self.lhs_wrapper = CudaBfpWrapper(fp_tensor_shape=lhs_shape, should_sort=self.should_sort)
        self.rhs_wrapper = CudaBfpWrapper(fp_tensor_shape=rhs_shape, should_sort=self.should_sort)

        self.output = torch.zeros(
            size=(lhs_shape[0], rhs_shape[0]),
            dtype=torch.float,
            device=self.device)

        self.use_stochastic_rounding = use_stochastic_rounding

        # self.cuda_output = CudaFloatStorage(data_count=lhs_shape[0] * rhs_shape[0])

    def run(self, lhs: torch.Tensor, rhs: torch.Tensor):
        self.lhs_wrapper.run_convert_fp_to_bfp(src_tensor=lhs, is_stochastic_rounding=self.use_stochastic_rounding)
        self.rhs_wrapper.run_convert_fp_to_bfp(src_tensor=rhs, is_stochastic_rounding=self.use_stochastic_rounding)

        if self.lhs_wrapper.bfp_M.shape[1] != self.rhs_wrapper.bfp_M.shape[1]:
            raise ValueError(f"cannot matched dim: {self.lhs_wrapper.bfp_M.shape} x {self.rhs_wrapper.bfp_M.shape}")

        M = self.lhs_wrapper.bfp_M.shape[0]
        K = self.lhs_wrapper.bfp_M.shape[1]
        N = self.rhs_wrapper.bfp_M.shape[0]
        bfp_M_bit = BfpConfig.bfp_M_Bit
        group_size = BfpConfig.group_size

        # output = torch.zeros(size=(M, N), dtype=torch.float)
        
        # self.lhs_wrapper.run_convert_fp_to_bfp()
        # self.rhs_wrapper.run_convert_fp_to_bfp()

        cuda_lib.bfp_gemm_2d(
            c_void_p(self.lhs_wrapper.bfp_S.data_ptr()),
            c_void_p(self.lhs_wrapper.bfp_E.data_ptr()),
            c_void_p(self.lhs_wrapper.bfp_M.data_ptr()),
            c_void_p(self.rhs_wrapper.bfp_S.data_ptr()),
            c_void_p(self.rhs_wrapper.bfp_E.data_ptr()),
            c_void_p(self.rhs_wrapper.bfp_M.data_ptr()),
            c_void_p(self.output.data_ptr()),
            c_int32(M),
            c_int32(K),
            c_int32(N),
            c_int32(group_size),
            c_int32(bfp_M_bit),
        )

        # self.cuda_output.recv(self.output.numpy())

        return self.output



if __name__ == "__main__":
    set_reproducibility(1234)
    BfpConfig.bfp_M_Bit = 4
    BfpConfig.chunk_size_to_sort = 1024
    should_sort = True
    M = 1024 # 1024 # 923
    K = 1024 * 4
    N = 1024 # 1024 # 1233
    print(f"dims: [{M}, {K}] x [{K}, {N}]")
    print(f"bfp m bits: {BfpConfig.bfp_M_Bit}")

    if should_sort:
        print(f"sort size: {BfpConfig.chunk_size_to_sort}")
    else:
        print("not sort")

    scale = 0.001
    lhs = torch.randn((M, K), dtype=torch.float32) * scale
    # lhs = torch.randint(low=-25, high=25, size=(M, K), dtype=torch.float32)
    lhs = lhs.to('cuda')

    rhs = torch.randn((K, N), dtype=torch.float32) * scale
    rhs = rhs.to('cuda')
    # rhs = torch.randint(low=-25, high=25, size=(K, N), dtype=torch.float32)
    rhs_t = torch.empty((N, K), dtype=torch.float).to('cuda')

    custom_transpose_2d(dst=rhs_t, src=rhs)
    
    bfp_gemm = BfpGemm(lhs.shape, rhs_t.shape, use_stochastic_rounding=False, should_sort=should_sort)

    outputs_cuda = bfp_gemm.run(lhs, rhs_t)

    start = time.time_ns()
    for i in range(1):
        outputs_cuda = bfp_gemm.run(lhs, rhs_t)
    end = time.time_ns()

    print(f"exec time: {((end - start) / 10 / 1000_000):.3f}ms")

    fp_outputs = torch.matmul(lhs, rhs)

    # diff = torch.abs(fp_outputs.flatten() - outputs.flatten())
    diff_cuda = torch.abs(fp_outputs.flatten() - outputs_cuda.flatten())

    # print(f"[diff not sorted]\nmean: {torch.mean(diff):.10f}\nmax: {torch.max(diff):.10f}\nmin: {torch.min(diff):.10f}")
    print(f"[diff not sorted]\nmean: {torch.mean(diff_cuda):.10f}\nmax: {torch.max(diff_cuda):.10f}\nmin: {torch.min(diff_cuda):.10f}")