#include <cmath>
#include <stdio.h>
#include <cstdlib>
#include <cstdint>
#include <vector>
#include <iostream>
#include <thread>
#include <chrono>
#include <algorithm>

extern "C" {
int get_exp_bit(const float fp_val);

int get_E(const int exp_bit);

void convert_fp_to_bfp_2d(const float* fp_mat_ptr, 
                          int* bfp_mat_S_ptr,
                          int* bfp_mat_E_ptr,
                          int64_t* bfp_mat_M_ptr,

                          int* ori_E_ptr,
                          const bool should_sort,

                          const int fp_height,
                          const int fp_width,
                          const int bfp_group_size,
                          const int bfp_M_bit,
                          const int thread_num);

void convert_bfp_to_fp_2d(int* bfp_mat_S_ptr,
                          int* bfp_mat_E_ptr,
                          int64_t* bfp_mat_M_ptr,
                          float* fp_mat_ptr, 
                          const int fp_height,
                          const int fp_width,
                          const int bfp_group_size,
                          const int bfp_M_bit,
                          const int thread_num);

void convert_acc_bfp_to_fp_1d(int* bfp_mat_S_ptr,
                              int* bfp_mat_E_ptr,
                              int64_t* bfp_mat_M_ptr,
                              float* fp_mat_ptr, 
                              const int fp_height,
                              const int fp_width,
                              const int bfp_group_size,
                              const int bfp_M_bit,
                              const int thread_num);
}

using namespace std;

struct Element {
    int E;
    int ori_w;
    float fp_value;
};

bool compare_element(Element const& lhs, Element const& rhs) {
    return lhs.E < rhs.E; 
}

int get_sign_bit(const float fp_val) {
    const unsigned int* ptr = (const unsigned int*) &fp_val;
    unsigned int uint32_val = *ptr;

    uint32_val >>= 31;

    return uint32_val;
}

int get_S(const float fp_val) {
    const int sign_bit = get_sign_bit(fp_val);

    if (sign_bit == 0) {
        return 1;
    } else {
        return -1;
    }
}

int get_exp_bit(const float fp_val) {
    const unsigned int* ptr = (const unsigned int*) &fp_val;
    unsigned int uint32_val = *ptr;

    uint32_val <<= 1;
    uint32_val >>= 24; // 1 + 23

    return uint32_val;
}

int get_E(const int exp_bit) {
    // const int exp_bit = get_exp_bit(fp_value);
    const int bias = 127; // 2^(8-1)-1

    if (exp_bit == 0) {
        return 1 - bias;
    } else {
        return exp_bit - bias;
    }
}

int get_frac_bit(const float fp_val) {
    const unsigned int* ptr = (const unsigned int*) &fp_val;
    unsigned int uint32_val = *ptr;

    uint32_val <<= 9; // 1 + 8
    uint32_val >>= 9; 

    return uint32_val;
}

int64_t get_M(const float fp_val, 
              const int bfp_M_bit,
              const int max_E_bit) {
    const unsigned int* ptr = (const unsigned int*) &fp_val;
    unsigned int uint32_val = *ptr;

    // const unsigned int ori = uint32_val;

    uint32_val <<= 9; // 1 + 8
    uint32_val >>= 9; 

    // const unsigned int frac_only = uint32_val;

    const int exp_bit = get_exp_bit(fp_val);
    if (exp_bit != 0) {
        unsigned int head_bit_for_M = 1;
        uint32_val += (head_bit_for_M << 23);
    }

    const int E_bit = get_E(exp_bit);

    unsigned int offset = (unsigned int)(24 - bfp_M_bit + (max_E_bit - E_bit));
    if (offset > 24) {
        offset = 24;
    }
    uint32_val >>= offset; // 1 (head_bit) + 23

    // if (uint32_val >= (1 << bfp_M_bit)) {

    //     printf("ori: %u, frac: %u, bfp_M_bit: %d, exp_offset: %d, offsets:%d, M: %u\n", 
    //             ori, 
    //             frac_only, 
    //             bfp_M_bit,
    //             (max_E_bit - E_bit),
    //             24 - bfp_M_bit + (max_E_bit - E_bit),                
    //             uint32_val);
    // }

    return (int64_t) uint32_val;
}

void show_data(int* ptr, const int size) {
    for (int i = 0; i < size; ++i) {
        printf("%d: %d\n", i, ptr[i]);
    }
}

void show_binary(const float fp_val) {
    const unsigned int* ptr = (const unsigned int*) &fp_val;
    unsigned int val = *ptr;

    // unsigned int val = (unsigned int) ((void*) fp_val);
    // printf("%d\n", val);
    
    int result[32];

    for (int i = 31; i >= 0; --i) {
        result[i] = val % 2;
        val >>= 1;
    }

    for (int i = 0; i < 32; ++i) {
        printf("%d", result[i]);
        if (i == 0 || i == 8) {
            printf("_");
        }
    }
    printf("\n");
}

void show_binary_int(int val) {
    int result[32];

    for (int i = 31; i >= 0; --i) {
        result[i] = val % 2;
        val >>= 1;
    }

    for (int i = 0; i < 32; ++i) {
        printf("%d", result[i]);
    }
    printf("\n");
}

void convert_fp_to_bfp_1d(const float* fp_vec_ptr, 
                          int* bfp_vec_S_ptr,
                          int* bfp_E_ptr,
                          int64_t* bfp_vec_M_ptr,
                          int* ori_E_ptr,
                          const int bfp_group_size,
                          const int bfp_M_bit) {
    // set S vector
    // get the max E value
    int max_E = get_E(get_exp_bit(*fp_vec_ptr));

    for (int i = 0; i < bfp_group_size; ++i) {
        const float fp_value = fp_vec_ptr[i];
        
        // show_binary(fp_value);

        bfp_vec_S_ptr[i] = get_S(fp_value);

        const int E_value = get_E(get_exp_bit(fp_value));
        // set ori E
        ori_E_ptr[i] = E_value;


        // printf("%d ", E_value);

        if (E_value > max_E) {
            max_E = E_value;
        }
    }

    // printf("\n");
    // printf("max: %d\n", max_E);

    // set the max E value
    // *bfp_E_ptr = max_E;

    // set vectors
    for (int i = 0; i < bfp_group_size; ++i) {
        const float fp_value = fp_vec_ptr[i];

        // set M
        bfp_vec_M_ptr[i] = get_M(fp_value, bfp_M_bit, max_E);

        // set the max E value
        bfp_E_ptr[i] = max_E;
    }
}

void convert_fp_to_bfp_1d_sorted(const float* fp_vec_ptr, 
                                 int* bfp_vec_S_ptr,
                                 int* bfp_E_ptr,
                                 int64_t* bfp_vec_M_ptr,

                                 int* ori_E_ptr,
                                 const Element* elements,

                                 const int bfp_group_size,
                                 const int bfp_M_bit) {
    // set S vector
    // get the max E value
    int max_E = get_E(get_exp_bit(*fp_vec_ptr));

    for (int i = 0; i < bfp_group_size; ++i) {
        const float fp_value = fp_vec_ptr[i];
        
        // show_binary(fp_value);

        const int E_value = get_E(get_exp_bit(fp_value));
        const int ori_w = elements[i].ori_w;
        ori_E_ptr[ori_w] = E_value;

        // printf("%d ", E_value);

        if (E_value > max_E) {
            max_E = E_value;
        }
    }

    // printf("\n");
    // printf("max: %d\n", max_E);

    // set the max E value
    // *bfp_E_ptr = max_E;

    // set vectors
    for (int i = 0; i < bfp_group_size; ++i) {
        const int ori_w = elements[i].ori_w;
        const float fp_value = fp_vec_ptr[i];

        // set S
        bfp_vec_S_ptr[ori_w] = get_S(fp_value);

        // set M
        bfp_vec_M_ptr[ori_w] = get_M(fp_value, bfp_M_bit, max_E);

        // set the max E value
        bfp_E_ptr[ori_w] = max_E;
    }
}

void convert_fp_to_bfp_2d_single_thread(const float* fp_mat_ptr, 
                                        int* bfp_mat_S_ptr,
                                        int* bfp_mat_E_ptr,
                                        int64_t* bfp_mat_M_ptr,

                                        int* ori_E_ptr,
                                        const bool should_sort,

                                        const int fp_height,
                                        const int fp_width,
                                        const int bfp_group_size,
                                        const int bfp_M_bit) {
    // compress FP to BFP in width direction
    const int bfp_height = fp_height;
    const int bfp_width = (int) ceil((double) fp_width / (double) bfp_group_size);
    const int bfp_width_tail = fp_width % bfp_group_size;
    const int has_tail = (bfp_width_tail == 0 ? 0 : 1);

    std::vector<Element> row_elements;
    row_elements.reserve(fp_width);

    std::vector<float> fp_values;
    fp_values.reserve(fp_width);

    for (int w = 0; w < fp_width; ++w) {
        row_elements.emplace_back(Element{0, -1, 0.f});
        fp_values.emplace_back(0.f);
    }

    for (int fp_h = 0; fp_h < fp_height; ++fp_h) {
        for (int fp_w = 0; fp_w < fp_width; ++fp_w) {
            const float fp_value = *(fp_mat_ptr+fp_w);
            row_elements[fp_w].E = get_E(get_exp_bit(fp_value));
            row_elements[fp_w].ori_w = fp_w;
            row_elements[fp_w].fp_value = fp_value;
            // printf("E: %d, ori_w: %d, FP: %f\n", row_elements[fp_w].E,
            //                                      row_elements[fp_w].ori_w,
            //                                      fp_value);
        }

        if (should_sort == true) {
            std::sort(row_elements.begin(), row_elements.end(), &compare_element);
        }
        // cout << endl;
        // for (int fp_w = 0; fp_w < fp_width; ++fp_w) {
        //     printf("E: %d, ori_w: %d, FP: %f\n", row_elements[fp_w].E,
        //                                          row_elements[fp_w].ori_w,
        //                                          row_elements[fp_w].fp_value);
        // }

        for (int fp_w = 0; fp_w < fp_width; ++fp_w) {
            fp_values[fp_w] = row_elements[fp_w].fp_value;
        }

        float* fp_sorted_mat_ptr = fp_values.data();
        Element* element_ptr = row_elements.data();

        if (should_sort == true) {
            for (int bfp_w = 0; bfp_w < (bfp_width - has_tail); ++bfp_w) {
                convert_fp_to_bfp_1d_sorted(fp_sorted_mat_ptr,

                                            bfp_mat_S_ptr,
                                            bfp_mat_E_ptr,
                                            bfp_mat_M_ptr,

                                            ori_E_ptr,
                                            element_ptr,

                                            bfp_group_size,
                                            bfp_M_bit);

                fp_sorted_mat_ptr += bfp_group_size;
                element_ptr += bfp_group_size;
            }

            if (has_tail) {
                convert_fp_to_bfp_1d_sorted(fp_sorted_mat_ptr,

                                            bfp_mat_S_ptr,
                                            bfp_mat_E_ptr,
                                            bfp_mat_M_ptr,

                                            ori_E_ptr,
                                            element_ptr,

                                            bfp_width_tail,
                                            bfp_M_bit);
                                     
                fp_sorted_mat_ptr += bfp_width_tail;
                element_ptr += bfp_width_tail;
            }

            fp_mat_ptr += fp_width;
            bfp_mat_S_ptr += fp_width;
            bfp_mat_M_ptr += fp_width;
            bfp_mat_E_ptr += fp_width;
            ori_E_ptr += fp_width;
        } else {
            for (int bfp_w = 0; bfp_w < (bfp_width - has_tail); ++bfp_w) {
                // ++bfp_index;

                convert_fp_to_bfp_1d(fp_mat_ptr,
                                     // (should_sort == true ? fp_sorted_mat_ptr : fp_mat_ptr),

                                     bfp_mat_S_ptr,
                                     bfp_mat_E_ptr,
                                     bfp_mat_M_ptr,

                                     ori_E_ptr,

                                     bfp_group_size,
                                     bfp_M_bit);
                // bfp_ptr[bfp_index] = output;

                fp_mat_ptr += bfp_group_size;
                // fp_sorted_mat_ptr += bfp_group_size;

                bfp_mat_S_ptr += bfp_group_size;
                bfp_mat_M_ptr += bfp_group_size;
                bfp_mat_E_ptr += bfp_group_size;
                ori_E_ptr += bfp_group_size;

                // ++bfp_mat_E_ptr;
            }

            if (has_tail) {
                convert_fp_to_bfp_1d(fp_mat_ptr,
                                     // (should_sort == true ? fp_sorted_mat_ptr : fp_mat_ptr),

                                     bfp_mat_S_ptr,
                                     bfp_mat_E_ptr,
                                     bfp_mat_M_ptr,

                                     ori_E_ptr,

                                     bfp_width_tail,
                                     bfp_M_bit);

                fp_mat_ptr += bfp_width_tail;
                // fp_sorted_mat_ptr += bfp_width_tail;

                bfp_mat_S_ptr += bfp_width_tail;
                bfp_mat_M_ptr += bfp_width_tail;
                bfp_mat_E_ptr += bfp_width_tail;
                ori_E_ptr += bfp_width_tail;

                // ++bfp_mat_E_ptr;
            }
        }
    }

}

void convert_fp_to_bfp_2d(const float* fp_mat_ptr, 
                          int* bfp_mat_S_ptr,
                          int* bfp_mat_E_ptr,
                          int64_t* bfp_mat_M_ptr,

                          int* ori_E_ptr,
                          const bool should_sort,

                          const int fp_height,
                          const int fp_width,
                          const int bfp_group_size,
                          const int bfp_M_bit,
                          const int thread_num) {
    if (thread_num < 1) {
        cout << "invalid thread_num " << thread_num << endl;
        exit(0);
    }

    int height_per_job = (int) floor((double) fp_height / (double) thread_num);

    if (thread_num > 1 && height_per_job >= 1) {
        std::vector<std::thread> threads;
        threads.reserve(thread_num);
        for (int t = 0; t < thread_num; ++t) {
            // int height_per_job = (int) floor((double) fp_height / (double) thread_num);
            if (t == thread_num - 1) {
                const int height_tail = fp_height % thread_num;
                height_per_job += height_tail;
            }

            threads.emplace_back(std::thread(convert_fp_to_bfp_2d_single_thread, 
                                             fp_mat_ptr, 
                                             bfp_mat_S_ptr,
                                             bfp_mat_E_ptr,
                                             bfp_mat_M_ptr,

                                             ori_E_ptr,
                                             should_sort,

                                             height_per_job,
                                             fp_width,
                                             bfp_group_size,
                                             bfp_M_bit));
            fp_mat_ptr += height_per_job * fp_width;
            bfp_mat_S_ptr += height_per_job * fp_width;
            bfp_mat_M_ptr += height_per_job * fp_width;
            bfp_mat_E_ptr += height_per_job * fp_width;
            ori_E_ptr += height_per_job * fp_width;

            // const int bfp_width = (int) ceil((double) fp_width / (double) bfp_group_size);
            // bfp_mat_E_ptr += height_per_job * bfp_width;
        }

        for (int t = 0; t < thread_num; ++t) {
            threads[t].join();
        }
    } else {
        convert_fp_to_bfp_2d_single_thread(fp_mat_ptr, 
                                           bfp_mat_S_ptr,
                                           bfp_mat_E_ptr,
                                           bfp_mat_M_ptr,

                                           ori_E_ptr,
                                           should_sort,
                                           
                                           fp_height,
                                           fp_width,
                                           bfp_group_size,
                                           bfp_M_bit);
    }
}

void show_mat(const float *ptr, const int height, const int width) {
    for (int h = 0; h < height; ++h) {
        for (int w = 0; w < width; ++w) {
            printf("%f ", ptr[h * width + w]);
        }
        printf("\n");
    }
}

void convert_bfp_to_fp_2d_single_thread(const int* bfp_mat_S_ptr,
                                        const int* bfp_mat_E_ptr,
                                        const int64_t* bfp_mat_M_ptr,
                                        float* fp_mat_ptr,
                                        const int fp_height,
                                        const int fp_width,
                                        const int bfp_group_size,
                                        const int bfp_M_bit) {
    const int bfp_height = fp_height;
    const int bfp_width = (int) ceil((double) fp_width / (double) bfp_group_size);
    const int bfp_width_tail = fp_width % bfp_group_size;
    const int has_tail = (bfp_width_tail == 0 ? 0 : 1);
    for (int bfp_h = 0; bfp_h < bfp_height; ++bfp_h) {
        for (int bfp_w = 0; bfp_w < (bfp_width - has_tail); ++bfp_w) {
            // const double E = (double) *bfp_mat_E_ptr;

            for (int i = 0; i < bfp_group_size; ++i) {
                const double E = (double) bfp_mat_E_ptr[i];
                const double S = (double) bfp_mat_S_ptr[i];

                // const double M = (double) bfp_mat_M_ptr[i];
                // const double mantissa = M / pow(2., (double) (bfp_M_bit - 1));
                
                int64_t M = bfp_mat_M_ptr[i];
                double mantissa = 0.f;
                double scale = 1. / pow(2., (double) (bfp_M_bit - 1));

                for (int m = 0; m < bfp_M_bit; ++m) {
                    const double bit = (const double) (M % 2);
                    mantissa += scale * bit;

                    M >>= 1;
                    scale *= 2;
                }

                // printf("%f * 2^(%f) * %f\n", S, E, mantissa);
                fp_mat_ptr[i] = S * pow(2., E) * mantissa;
            }

            fp_mat_ptr += bfp_group_size;
            bfp_mat_S_ptr += bfp_group_size;
            bfp_mat_M_ptr += bfp_group_size;
            bfp_mat_E_ptr += bfp_group_size;
            // ++bfp_mat_E_ptr;
        }

        if (has_tail) {
            // const int E = *bfp_mat_E_ptr;

            for (int i = 0; i < bfp_width_tail; ++i) {
                const double E = (double) bfp_mat_E_ptr[i];
                const double S = (double) bfp_mat_S_ptr[i];

                // const double M = (double) bfp_mat_M_ptr[i];
                // const double mantissa = M / pow(2., (double) (bfp_M_bit - 1));

                int64_t M = bfp_mat_M_ptr[i];
                double mantissa = 0.f;
                double scale = 1. / pow(2., (double) (bfp_M_bit - 1));

                for (int m = 0; m < bfp_M_bit; ++m) {
                    const double bit = (const double) (M % 2);

                    mantissa += scale * bit;

                    M >>= 1;
                    scale *= 2;
                }

                fp_mat_ptr[i] = S * pow(2., E) * mantissa;
            }

            fp_mat_ptr += bfp_width_tail;
            bfp_mat_S_ptr += bfp_width_tail;
            bfp_mat_M_ptr += bfp_width_tail;
            bfp_mat_E_ptr += bfp_width_tail;
            // ++bfp_mat_E_ptr;
        }
    }
}

void convert_bfp_to_fp_2d(int* bfp_mat_S_ptr,
                          int* bfp_mat_E_ptr,
                          int64_t* bfp_mat_M_ptr,
                          float* fp_mat_ptr, 
                          const int fp_height,
                          const int fp_width,
                          const int bfp_group_size,
                          const int bfp_M_bit,
                          const int thread_num) {
    if (thread_num < 1) {
        cout << "invalid thread_num " << thread_num << endl;
        exit(0);
    }

    int height_per_job = (int) floor((double) fp_height / (double) thread_num);

    if (thread_num > 1 && height_per_job >= 1) {
        std::vector<std::thread> threads;
        threads.reserve(thread_num);
        for (int t = 0; t < thread_num; ++t) {
            // int height_per_job = (int) floor((double) fp_height / (double) thread_num);
            if (t == thread_num - 1) {
                const int height_tail = fp_height % thread_num;
                height_per_job += height_tail;
            }

            threads.emplace_back(std::thread(convert_bfp_to_fp_2d_single_thread,  
                                             bfp_mat_S_ptr,
                                             bfp_mat_E_ptr,
                                             bfp_mat_M_ptr,
                                             fp_mat_ptr,
                                             height_per_job,
                                             fp_width,
                                             bfp_group_size,
                                             bfp_M_bit));
            fp_mat_ptr += height_per_job * fp_width;
            bfp_mat_S_ptr += height_per_job * fp_width;
            bfp_mat_M_ptr += height_per_job * fp_width;
            bfp_mat_E_ptr += height_per_job * fp_width;


            // const int bfp_width = (int) ceil((double) fp_width / (double) bfp_group_size);
            // bfp_mat_E_ptr += height_per_job * bfp_width;
        }

        for (int t = 0; t < thread_num; ++t) {
            threads[t].join();
        }
    } else {
        convert_bfp_to_fp_2d_single_thread(bfp_mat_S_ptr,
                                           bfp_mat_E_ptr,
                                           bfp_mat_M_ptr,
                                           fp_mat_ptr,
                                           fp_height,
                                           fp_width,
                                           bfp_group_size,
                                           bfp_M_bit);
    }
}

///////////////////////////////////////////////////////////////////////////////
/*****************************************************************************/

void convert_acc_bfp_to_fp_1d_single_thread(const int* bfp_mat_S_ptr,
                                            const int* bfp_mat_E_ptr,
                                            const int64_t* bfp_mat_M_ptr,
                                            float* fp_mat_ptr,
                                            const int fp_height,
                                            const int fp_width,
                                            const int bfp_group_size,
                                            const int bfp_M_bit) {
    const int bfp_height = fp_height;
    const int bfp_width = (int) ceil((double) fp_width / (double) bfp_group_size);
    const int bfp_width_tail = fp_width % bfp_group_size;
    const int has_tail = (bfp_width_tail == 0 ? 0 : 1);
    for (int bfp_h = 0; bfp_h < bfp_height; ++bfp_h) {
        for (int bfp_w = 0; bfp_w < (bfp_width - has_tail); ++bfp_w) {
            // const double E = (double) *bfp_mat_E_ptr;

            for (int i = 0; i < bfp_group_size; ++i) {
                const double E = (double) bfp_mat_E_ptr[i];
                const double S = (double) bfp_mat_S_ptr[i];

                // const double M = (double) bfp_mat_M_ptr[i];
                // const double mantissa = M / pow(2., (double) (2 * (bfp_M_bit - 1)));

                int64_t M = bfp_mat_M_ptr[i];
                double mantissa = 0.f;
                double scale = 1. / pow(2., (double) (2 * (bfp_M_bit - 1)));

                for (int m = 0; m < 2 * bfp_M_bit; ++m) {
                    const double bit = (const double) (M % 2);
                    mantissa += scale * bit;

                    M >>= 1;
                    scale *= 2;
                }

                // printf("%f * 2^(%f) * %f\n", S, E, mantissa);
                fp_mat_ptr[i] = S * pow(2., E) * mantissa;
            }

            fp_mat_ptr += bfp_group_size;
            bfp_mat_S_ptr += bfp_group_size;
            bfp_mat_M_ptr += bfp_group_size;
            bfp_mat_E_ptr += bfp_group_size;
            // ++bfp_mat_E_ptr;
        }

        if (has_tail) {
            // const int E = *bfp_mat_E_ptr;

            for (int i = 0; i < bfp_width_tail; ++i) {
                const double E = (double) bfp_mat_E_ptr[i];
                const double S = (double) bfp_mat_S_ptr[i];

                // const double M = (double) bfp_mat_M_ptr[i];
                // const double mantissa = M / pow(2., (double) (2 * (bfp_M_bit - 1)));

                int64_t M = bfp_mat_M_ptr[i];
                double mantissa = 0.f;
                double scale = 1. / pow(2., (double) (2 * (bfp_M_bit - 1)));
                
                for (int m = 0; m < 2 * bfp_M_bit; ++m) {
                    const double bit = (const double) (M % 2);

                    mantissa += scale * bit;

                    M >>= 1;
                    scale *= 2;
                }

                fp_mat_ptr[i] = S * pow(2., E) * mantissa;
            }

            fp_mat_ptr += bfp_width_tail;
            bfp_mat_S_ptr += bfp_width_tail;
            bfp_mat_M_ptr += bfp_width_tail;
            bfp_mat_E_ptr += bfp_width_tail;
            // ++bfp_mat_E_ptr;
        }
    }
}

void convert_acc_bfp_to_fp_1d(int* bfp_mat_S_ptr,
                              int* bfp_mat_E_ptr,
                              int64_t* bfp_mat_M_ptr,
                              float* fp_mat_ptr, 
                              const int fp_height,
                              const int fp_width,
                              const int bfp_group_size,
                              const int bfp_M_bit,
                              const int thread_num) {
    if (thread_num < 1) {
        cout << "invalid thread_num " << thread_num << endl;
        exit(0);
    }

    int height_per_job = (int) floor((double) fp_height / (double) thread_num);

    if (thread_num > 1 && height_per_job >= 1) {
        std::vector<std::thread> threads;
        threads.reserve(thread_num);
        for (int t = 0; t < thread_num; ++t) {
            // int height_per_job = (int) floor((double) fp_height / (double) thread_num);
            if (t == thread_num - 1) {
                const int height_tail = fp_height % thread_num;
                height_per_job += height_tail;
            }

            threads.emplace_back(std::thread(convert_acc_bfp_to_fp_1d_single_thread,  
                                             bfp_mat_S_ptr,
                                             bfp_mat_E_ptr,
                                             bfp_mat_M_ptr,
                                             fp_mat_ptr,
                                             height_per_job,
                                             fp_width,
                                             bfp_group_size,
                                             bfp_M_bit));
            fp_mat_ptr += height_per_job * fp_width;
            bfp_mat_S_ptr += height_per_job * fp_width;
            bfp_mat_M_ptr += height_per_job * fp_width;
            bfp_mat_E_ptr += height_per_job * fp_width;


            // const int bfp_width = (int) ceil((double) fp_width / (double) bfp_group_size);
            // bfp_mat_E_ptr += height_per_job * bfp_width;
        }

        for (int t = 0; t < thread_num; ++t) {
            threads[t].join();
        }
    } else {
        convert_acc_bfp_to_fp_1d_single_thread(bfp_mat_S_ptr,
                                               bfp_mat_E_ptr,
                                               bfp_mat_M_ptr,
                                               fp_mat_ptr,
                                               fp_height,
                                               fp_width,
                                               bfp_group_size,
                                               bfp_M_bit);
    }
}

/*****************************************************************************/
///////////////////////////////////////////////////////////////////////////////


int main(int argc, char* argv[]) {
    // const float v = -123.1234f;
    const int thread_num = 16;
    const float v = -1.125f;
    show_binary(v);
    printf("\n");
    show_binary_int(get_sign_bit(v));
    show_binary_int(get_exp_bit(v));
    printf("%d\n", get_exp_bit(v));
    show_binary_int(get_frac_bit(v));
    printf("\n");
    printf("%d\n", get_S(v));
    printf("%d\n", get_E(get_exp_bit(v)));
    int a = 5 / 3;
    printf("%d\n", a);

    // const int height = 16;
    // const int width = 16;
    // should change unsigned long
    // support multi-thread
    const int height = 16;
    const int width = 16;

    vector<float> x;
    x.reserve(height * width);
    // float x[height * width];

    for (int i = 0; i < height * width; ++i) {
        float a = 5.0;
        x.emplace_back((float)rand() / (float)(RAND_MAX / a));
        // x[i] = (float)rand()/(float)(RAND_MAX / a);
    }

    show_mat(x.data(), 1, 16);

    const int group_size = 16;
    const int bfp_M_bit = 24;

    // int bfp_S[height * width];
    // int bfp_M[height * width];
    vector<int> bfp_S;
    bfp_S.reserve(height * width);

    vector<int> bfp_E;
    // bfp_E.reserve(height * ((int) ceil((double) width / (double) group_size)));
    bfp_E.reserve(height * width);
    
    vector<int64_t> bfp_M;
    bfp_M.reserve(height * width);

    vector<int> ori_E;
    ori_E.reserve(height * width);
    
    // vector<int> bfp_ori_w;
    // bfp_ori_w.reserve(height * width);

    for (int i = 0; i < height * width; ++i) {
        bfp_S.emplace_back(0);
        bfp_E.emplace_back(0);
        bfp_M.emplace_back(0);
        ori_E.emplace_back(0);
        // bfp_ori_w.emplace_back(-1);
    }
    

    // int bfp_E[height * ((int) ceil((double) width / (double) group_size))];
    // printf("%d\n", height * ((int) ceil((double) width / (double) group_size)));
    
    // for (int i = 0; i < height * ((int) ceil((double) width / (double) group_size)); ++i) {
    //     bfp_E.emplace_back(0);
    // }

    cout << "convert FPs to BFPs..."; 
    const auto fp2bfp_start = chrono::high_resolution_clock::now();
    convert_fp_to_bfp_2d(x.data(), 
                         bfp_S.data(), 
                         bfp_E.data(), 
                         bfp_M.data(),

                        //  bfp_ori_w.data(),
                         ori_E.data(),
                         true,
                         
                         height, 
                         width, 
                         group_size, 
                         bfp_M_bit,
                         thread_num);
    const auto fp2bfp_end = chrono::high_resolution_clock::now();
    cout << "done" << endl;

    vector<float> y;
    y.reserve(height * width);
    vector<float> y_sorted;
    y_sorted.reserve(height * width);
    for (int i = 0; i < height * width; ++i) {
        y.emplace_back(0);
        y_sorted.emplace_back(0);
    }
    // float y[height * width];

    cout << "convert BFPs to FPs...";
    const auto bfp2fp_start = chrono::high_resolution_clock::now();
    convert_bfp_to_fp_2d(bfp_S.data(), 

                         bfp_E.data(), 
                         bfp_M.data(), 
                         y.data(), 
                         height, 
                         width, 
                         group_size, 
                         bfp_M_bit,
                         thread_num);
    const auto bfp2fp_end = chrono::high_resolution_clock::now();
    cout << "done" << endl;


    for (int h = 0; h < height; ++h) {
        int h_offset = h * width;
        for (int w = 0; w < width; ++w) {
            // int ori_w = bfp_ori_w[h_offset + w];
            y_sorted[h_offset + w] = y[h_offset + w];
        }
    }


    show_mat(y_sorted.data(), 1, 16);

    // show_binary(x[0]);
    // show_binary(y[0]);


    double sum_diff = 0.;
    for (int i = 0; i < height * width; ++i) {
        sum_diff += fabs((double) (x[i] - y_sorted[i]));
    }

    const double mean_diff = sum_diff / ((double) height * width);

    const double fp2bfp_ns = chrono::duration_cast<chrono::nanoseconds>(fp2bfp_end - fp2bfp_start).count();
    const double bfp2fp_ns = chrono::duration_cast<chrono::nanoseconds>(bfp2fp_end - bfp2fp_start).count();
    cout << "fp2bfp: " << (fp2bfp_ns / (double) 1000000000) << " sec" << endl;
    cout << "bfp2fp: " << (bfp2fp_ns / (double) 1000000000) << " sec" << endl;
    printf("mean diff: %f\n", mean_diff);


    return 0;
}

// make my own example with simple floating values