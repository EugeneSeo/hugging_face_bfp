import torch
import torch.nn as nn
import torch.nn.parallel
import torch.backends.cudnn as cudnn
import torch.distributed as dist
import torch.optim
from torch.optim.lr_scheduler import StepLR
import torch.multiprocessing as mp
import torch.utils.data
import torch.utils.data.distributed
import torchvision.transforms as transforms
import torchvision.datasets as datasets
import torchvision.models as models
from typing import List, OrderedDict

import torch.multiprocessing as mp

import sys
if "/home/yskim/projects/sparse-bfp" not in sys.path:
    sys.path.append("/home/yskim/projects/sparse-bfp")
from util.data_load import DL_TYPE_CIFAR_10, DL_TYPE_CIFAR_100, DL_TYPE_IMAGENET, generate_data_loaders
from util.reprod_util import set_reproducibility
from util.parameter_server_gradient_storage import ParameterServerGradientStorage
from util.parameter_server_weight_storage import ParameterServerWeightStorage


def main_worker(gpu, global_seed, num_procs, in_features, out_features, weight_tensor):
    set_reproducibility(global_seed * (gpu + 1))
    
    dist.init_process_group(backend="nccl",
                            init_method="tcp://127.0.0.1:8800",
                            world_size=num_procs,
                            rank=gpu)
    
    batch_size = 1
    bias = False
    
    # inputs = torch.randint(low=0, high=4, size=(in_features,), dtype=torch.float)
    # targets = torch.randint(low=0, high=4, size=(out_features,), dtype=torch.float)
    inputs = torch.randn(size=(in_features,), dtype=torch.float)
    targets = torch.randn(size=(out_features,), dtype=torch.float)
    
    print(f"gpu: {gpu}, num_procs: {num_procs}, tensor: {inputs.numpy()}")
    
    l0 = nn.Linear(
        in_features=in_features,
        out_features=out_features,
        bias=bias)
    
    # print(weight_tensor)
    
    l0.weight = nn.Parameter(weight_tensor.clone().detach())
    
    model = nn.Sequential(OrderedDict([
        ("l0", l0)
    ]))
    
    
    # crit = nn.CrossEntropyLoss()
    sgd = torch.optim.SGD(model.parameters(), lr=1.0)
    
    model = model.to(f"cuda:{dist.get_rank()}")
    inputs = inputs.to(f"cuda:{dist.get_rank()}")
    targets = targets.to(f"cuda:{dist.get_rank()}")
    
    # print(l0.weight.data)
    
    if dist.get_rank() == 0:
        gradient_storage = ParameterServerGradientStorage(model, num_replicas=num_procs, rank=dist.get_rank())
    else:
        gradient_storage = ParameterServerGradientStorage(model, num_replicas=1, rank=dist.get_rank())
    
    weight_storage = ParameterServerWeightStorage(model, num_replicas=4, rank=dist.get_rank())
    
    dist.barrier(device_ids=[gpu])
    
    outputs = model(inputs)
    
    loss = torch.sum(targets * outputs)
    
    sgd.zero_grad()
    loss.backward()
    
    if dist.get_rank() == 0:
        gradient_storage.recv_gradients()
    else:
        gradient_storage.send_gradients()
    
    # weight_storage.load_weights_from_module()
    
    dist.barrier(device_ids=[gpu])
        
    # sgd.step()
    
    print(f"rank {dist.get_rank()}, weight: {model.l0.weight.clone().detach().cpu().numpy()}, grad: {model.l0.weight.grad.clone().detach().cpu().numpy()}")
    
    dist.barrier(device_ids=[gpu])
    
    if dist.get_rank() == 0:
        gradient_storage.load_gradients_from_module()
        
        for grad in gradient_storage.gradients:
            grad_cpu = grad.clone().detach().cpu()
            print(grad_cpu)
            
        gradient_storage.reduce_gradients_to_module()
            
        print("reduced")
        print(model.l0.weight.grad.clone().detach().cpu().numpy())
            
    if dist.get_rank() == 0:
        sgd.step()
        
    dist.barrier(device_ids=[gpu])
    
    print(f"rank {dist.get_rank()}, weight: {model.l0.weight.clone().detach().cpu().numpy()}")
    
    dist.barrier(device_ids=[gpu])
    
    if dist.get_rank() == 0:
        print("broad_cast...")
        weight_storage.send_weights()
    else:
        weight_storage.recv_weights()
        weight_storage.store_weights_to_module()    
    
    dist.barrier(device_ids=[gpu])
    
    print(f"rank {dist.get_rank()}, weight: {model.l0.weight.clone().detach().cpu().numpy()}")
    
    dist.barrier(device_ids=[gpu])
        
    # print(outputs.shape)

if __name__ == "__main__":
    num_procs = 4
    global_seed = 1234
    in_features = 8
    out_features = 1
    
    set_reproducibility(global_seed * (num_procs + 1))
    
    # weight_tensor = torch.randint(low=0, high=4, size=(out_features, in_features), dtype=torch.float)
    weight_tensor = torch.randn(size=(out_features, in_features), dtype=torch.float) * 0.001
    
    # model = models.alexnet(pretrained=False)
    
    # inputs = torch.randn(size=(1, 3, 224, 224))
    
    # outputs = model(inputs)
    # targets = torch.randn(size=(1000,))
    
    # loss = torch.sum(outputs - targets)
    
    # sgd = torch.optim.SGD(model.parameters(), lr=1.0)
    # sgd.zero_grad()
    # loss.backward()
    # sgd.step()
    
    # result = []
    # generate_gradient_buffers(model, 4, result)
    
    # for param in result:
    #     print(param.shape)
    
    # # print(model.parameters().grad)
    # exit()
    
    mp.spawn(main_worker, nprocs=num_procs, args=(global_seed, num_procs, in_features, out_features, weight_tensor))