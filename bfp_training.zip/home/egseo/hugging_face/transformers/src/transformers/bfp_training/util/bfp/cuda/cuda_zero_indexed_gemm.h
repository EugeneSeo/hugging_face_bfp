#pragma once

#include <cstdint>

extern "C" {
void zero_indexed_gemm(
    const float* lhs_ptr,
    const bool* lhs_zero_index_ptr,

    const float* rhs_ptr,
    const bool* rhs_zero_index_ptr,

    float* output_ptr,

    const int32_t M,
    const int32_t K,
    const int32_t N
);

}