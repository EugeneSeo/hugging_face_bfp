from ctypes.wintypes import POINT
import sys
import math
import torch
import ctypes
from ctypes import *

from util.bfp.cuda.test_cuda_mem import CudaFloatStorage, CudaInt32Storage, CudaInt64Storage

if "/home/yskim/projects/sparse-bfp" not in sys.path:
    sys.path.append("/home/yskim/projects/sparse-bfp")

from util.bfp.bfp_config import BfpConfig

# bfp_so_file_path = "/home/yskim/projects/sparse-bfp/util/bfp/bfp_converter.so"
# c_lib = ctypes.CDLL(bfp_so_file_path)


# sample_lib = ctypes.CDLL("/home/yskim/projects/sparse-bfp/util/bfp/sample.so")


class BfpWrapper:
    def __init__(self, fp_tensor: torch.Tensor, should_sort: bool):
        super().__init__()

        self.device = "cpu"

        self.fp_tensor = fp_tensor

        self.bfp_S = torch.zeros(size=fp_tensor.shape,
                                 dtype=torch.int32, 
                                 device=self.device)

        self.bfp_E = torch.zeros(size=fp_tensor.shape,
                                 dtype=torch.int32)

        self.bfp_M = torch.zeros(size=fp_tensor.shape, 
                                 dtype=torch.int64, 
                                 device=self.device)

        self.ori_E = torch.zeros(size=fp_tensor.shape,
                                 dtype=torch.int32)

        # self.bfp_original_E = torch.zeros(size=(fp_tensor.shape[0], 
        #                                         fp_tensor.shape[1]),
        #                                  dtype=torch.int32)

        # self.bfp_original_w_index = torch.zeros(size=(fp_tensor.shape[0], 
                                                    #   fp_tensor.shape[1]),
                                                # dtype=torch.int32)

        self.np_fp_tensor = self.fp_tensor.numpy()
        self.cuda_fp = CudaFloatStorage(data_count=np.prod(self.np_fp_tensor.shape))

        self.np_bfp_S = self.bfp_S.numpy()
        self.cuda_bfp_S = CudaInt32Storage(data_count=np.prod(self.np_bfp_S.shape))

        self.np_bfp_E = self.bfp_E.numpy()
        self.cuda_bfp_E = CudaInt32Storage(data_count=np.prod(self.np_bfp_E.shape))

        self.np_bfp_M = self.bfp_M.numpy()
        self.cuda_bfp_M = CudaInt64Storage(data_count=np.prod(self.np_bfp_M.shape))

        self.np_ori_E = self.ori_E.numpy()
        self.cuda_bfp_ori_E = CudaInt32Storage(data_count=np.prod(self.np_ori_E.shape))
        # self.np_bfp_original_w_index = self.bfp_original_w_index.numpy()


        self.should_sort = should_sort

    def run_convert_fp_to_bfp(self):
        # for r in range(self.fp_tensor.shape[0]):
        #     for c in range(self.fp_tensor.shape[1]):
        #         ori_E = c_lib.get_E(c_lib.get_exp_bit(c_float(self.fp_tensor[r, c])))
        #         self.bfp_original_E[r, c] = ori_E

        c_lib.convert_fp_to_bfp_2d(self.np_fp_tensor.ctypes.data_as(POINTER(c_float)),
                                   self.np_bfp_S.ctypes.data_as(POINTER(c_int32)),
                                   self.np_bfp_E.ctypes.data_as(POINTER(c_int32)),

                                   self.np_bfp_M.ctypes.data_as(POINTER(c_int64)),

                                   self.np_ori_E.ctypes.data_as(POINTER(c_int32)),
                                   c_bool(self.should_sort),

                                   c_int32(self.np_fp_tensor.shape[0]),
                                   c_int32(self.np_fp_tensor.shape[1]),
                                   c_int32(BfpConfig.group_size),
                                   c_int32(BfpConfig.bfp_M_Bit),
                                   c_int32(BfpConfig.thread_num))

    def get_fp_from_current_bfp_info(self):
        output = torch.zeros(size=self.fp_tensor.shape,
                             dtype=torch.float32,
                             device=self.device)

        c_lib.convert_bfp_to_fp_2d(self.np_bfp_S.ctypes.data_as(POINTER(c_int32)),
                                   self.np_bfp_E.ctypes.data_as(POINTER(c_int32)),

                                   self.np_bfp_M.ctypes.data_as(POINTER(c_int64)),

                                   output.numpy().ctypes.data_as(POINTER(c_float)),
                                   c_int32(self.np_fp_tensor.shape[0]),
                                   c_int32(self.np_fp_tensor.shape[1]),
                                   c_int32(BfpConfig.group_size),
                                   c_int32(BfpConfig.bfp_M_Bit),
                                   c_int32(BfpConfig.thread_num))

        return output


from util.reprod_util import set_reproducibility
import numpy as np


if __name__ == "__main__":
    # set_reproducibility(1)
    BfpConfig.bfp_M_Bit = 8

    fp_input = torch.randn((32, 4096), dtype=torch.float32)
    wrapper = BfpWrapper(fp_tensor=fp_input, should_sort=False)
    wrapper.run_convert_fp_to_bfp()
    cpy_output = wrapper.get_fp_from_current_bfp_info()

    wrapper_sorted = BfpWrapper(fp_tensor=fp_input, should_sort=True)
    wrapper_sorted.run_convert_fp_to_bfp()
    cpy_output_sorted = wrapper_sorted.get_fp_from_current_bfp_info()

    # print(fp_input)
    # print(cpy_output)
    print(f"mean diff          : {torch.mean(torch.abs(fp_input.flatten() - cpy_output.flatten())):.5f}")
    print(f"mean diff (sorted) : {torch.mean(torch.abs(fp_input.flatten() - cpy_output_sorted.flatten())):.5f}")


    r = 16
    c = 0
    print(f"{fp_input[r,c]}")
    print(f"{cpy_output[r,c]}")
    print(f"{cpy_output_sorted[r,c]}")


    # fp_sum = torch.sum(fp_input, dim=1)
    # bfp_sum = torch.sum(cpy_output, dim=1)
    # bfp_sorted_sum = torch.sum(cpy_output_sorted, dim=1)
    # print("sum(dim=1)")
    # print(f"mean diff          : {torch.mean(torch.abs(fp_sum.flatten() - bfp_sum.flatten()))}")
    # print(f"mean diff (sorted) : {torch.mean(torch.abs(fp_sum.flatten() - bfp_sorted_sum.flatten()))}")
    

    # fp_input_t = torch.tensor(np.array((np.transpose(fp_input.numpy(), (1, 0))).copy()))


    # wrapper = BfpWrapper(fp_tensor=fp_input.t(), should_sort=False)
    # wrapper.run_convert_fp_to_bfp()
    # cpy_output = wrapper.get_fp_from_current_bfp_info()

    # sample_lib.show(arr.numpy().ctypes.data_as(POINTER(c_float)), c_int32(4 * 2))

    # print()
    # print(cpy_output_t)
    # print()
    # print(cpy_output)