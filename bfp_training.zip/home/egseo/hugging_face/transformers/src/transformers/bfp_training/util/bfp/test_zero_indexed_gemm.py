import torch
from ctypes import *

import os
BFP_HOME = os.environ["BFP_HOME"]

from util.reprod_util import set_reproducibility


cuda_lib = CDLL(f"{BFP_HOME}/util/bfp/cuda/lib_cuda_zero_indexed_gemm.so")

if __name__ == "__main__":
    set_reproducibility(234256)
    M = 2342
    K = 1232
    N = 2434
    # lhs = torch.randn(size=(M, K)).to("cuda")
    lhs = torch.randint(low=-5, high=5, size=(M, K), dtype=torch.float).to("cuda")
    # rhs = torch.randn(size=(N, K)).to("cuda")
    rhs = torch.randint(low=-5, high=5, size=(N, K), dtype=torch.float).to("cuda")

    output_cmp = torch.matmul(lhs, rhs.t())
    # print("lhs")
    # print(lhs.cpu().numpy())
    # print("rhs^t")
    # print(rhs.t().cpu().numpy())
    # print("output")
    # print(output_cmp.cpu().numpy())

    mask = lhs >= 0.
    lhs_masked = lhs.clone().detach()
    lhs_masked[mask] = 0.
    # print("lhs masked")
    # print(lhs_masked.cpu().numpy())

    mask = rhs >= 0.
    rhs_masked = rhs.clone().detach()
    rhs_masked[mask] = 0.
    # print("rhs^t masked")
    # print(rhs_masked.t().cpu().numpy())

    output_masked = torch.matmul(lhs_masked, rhs_masked.t())


    lhs_zero_index = torch.zeros(size=(M, K), dtype=torch.bool).to("cuda")
    mask = lhs_masked == 0.
    lhs_zero_index[mask] = True

    rhs_zero_index = torch.zeros(size=(N, K), dtype=torch.bool).to("cuda")
    mask = rhs_masked == 0.
    rhs_zero_index[mask] = True

    output_add = torch.zeros(size=(M, N), dtype=torch.float).to("cuda")


    # output = torch.zeros(size=(M, N)).to("cuda")

    cuda_lib.zero_indexed_gemm(
        c_void_p(lhs.data_ptr()),
        c_void_p(lhs_zero_index.data_ptr()),
        c_void_p(rhs.data_ptr()),
        c_void_p(rhs_zero_index.data_ptr()),
        c_void_p(output_add.data_ptr()),
        c_int32(M),
        c_int32(K),
        c_int32(N)
    )

    output = output_masked + output_add
    # output = output_masked

    # print(output.shape)
    # print(output_cmp.shape)

    print(torch.sum(torch.abs(output_cmp.flatten() - output.flatten())))