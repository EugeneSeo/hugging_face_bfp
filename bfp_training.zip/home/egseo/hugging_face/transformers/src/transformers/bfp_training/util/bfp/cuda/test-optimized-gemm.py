import time
import torch
from ctypes import *

from util.bfp.bfp_config import BfpConfig
from util.reprod_util import set_reproducibility
from util.custom_transpose import custom_transpose_2d
from util.bfp.cuda_bfp_wrapper import CudaBfpWrapper

import os
BFP_HOME = os.environ["BFP_HOME"]

cuda_lib = CDLL(f"{BFP_HOME}/util/bfp/cuda/lib_not_sorted_gemm_cuda.so")
cuda_optimized_lib = CDLL(f"{BFP_HOME}/util/bfp/cuda/lib_not_sorted_gemm_optimized_cuda.so")

if __name__ == "__main__":
    set_reproducibility(1234)
    BfpConfig.group_size = 16
    BfpConfig.bfp_M_Bit = 8
    use_multi_exp = False
    apply_thresholding = False
    threshold = 100
    use_SR = False

    M, K, N = 1024, 1024, 1024

    dev = "cuda"
    lhs = torch.randn(size=(M, K), dtype=torch.float).to(dev)
    rhs = torch.randn(size=(N, K), dtype=torch.float).to(dev)
    fp_output = torch.matmul(lhs, rhs.t())

    lhs_wrapper = CudaBfpWrapper(
        fp_tensor_shape=lhs.shape, 
        use_multi_exp=use_multi_exp,
        apply_thresholding=apply_thresholding,
        threshold=threshold
    )
    lhs_wrapper.run_convert_fp_to_bfp(src_tensor=lhs, is_stochastic_rounding=use_SR)

    rhs_wrapper = CudaBfpWrapper(
        fp_tensor_shape=rhs.shape, 
        use_multi_exp=use_multi_exp,
        apply_thresholding=apply_thresholding,
        threshold=threshold
    )
    rhs_wrapper.run_convert_fp_to_bfp(src_tensor=rhs, is_stochastic_rounding=use_SR)

    bfp_output = torch.zeros(size=(M, N), dtype=torch.float).to(dev)
    bfp_optim_output = torch.zeros(size=(M, N), dtype=torch.float).to(dev)

    for i in range(10):
        lhs_wrapper.run_convert_fp_to_bfp(src_tensor=lhs, is_stochastic_rounding=use_SR)
        rhs_wrapper.run_convert_fp_to_bfp(src_tensor=rhs, is_stochastic_rounding=use_SR)

        cuda_lib.bfp_gemm_2d(
            c_void_p(lhs_wrapper.bfp_S.data_ptr()),
            c_void_p(lhs_wrapper.bfp_E.data_ptr()),
            c_void_p(lhs_wrapper.bfp_M.data_ptr()),

            c_void_p(rhs_wrapper.bfp_S.data_ptr()),
            c_void_p(rhs_wrapper.bfp_E.data_ptr()),
            c_void_p(rhs_wrapper.bfp_M.data_ptr()),

            c_void_p(bfp_output.data_ptr()),

            c_int32(M),
            c_int32(K),
            c_int32(N),

            c_int32(BfpConfig.group_size),
            c_int32(BfpConfig.bfp_M_Bit),
            c_int32(BfpConfig.bfp_M_Bit)
        )

        lhs_wrapper.run_convert_fp_to_bfp(src_tensor=lhs, is_stochastic_rounding=use_SR)
        rhs_wrapper.run_convert_fp_to_bfp(src_tensor=rhs, is_stochastic_rounding=use_SR)

        cuda_optimized_lib.bfp_gemm_2d(
            c_void_p(lhs_wrapper.bfp_S.data_ptr()),
            c_void_p(lhs_wrapper.bfp_E.data_ptr()),
            c_void_p(lhs_wrapper.bfp_M.data_ptr()),

            c_void_p(rhs_wrapper.bfp_S.data_ptr()),
            c_void_p(rhs_wrapper.bfp_E.data_ptr()),
            c_void_p(rhs_wrapper.bfp_M.data_ptr()),

            c_void_p(bfp_optim_output.data_ptr()),

            c_int32(M),
            c_int32(K),
            c_int32(N),

            c_int32(BfpConfig.group_size),
            c_int32(BfpConfig.bfp_M_Bit),
            c_int32(BfpConfig.bfp_M_Bit)
        )

    print(f"naive diff: {torch.mean(torch.abs(fp_output.flatten() - bfp_output.flatten())):.10f}")
    print(f"optim diff: {torch.mean(torch.abs(fp_output.flatten() - bfp_optim_output.flatten())):.10f}")


    iterations = 20

    cvt_time = 0
    run_time = 0
    for i in range(iterations):
        torch.cuda.synchronize()
        start = time.time_ns()
        lhs_wrapper.run_convert_fp_to_bfp(src_tensor=lhs, is_stochastic_rounding=use_SR)
        rhs_wrapper.run_convert_fp_to_bfp(src_tensor=rhs, is_stochastic_rounding=use_SR)
        torch.cuda.synchronize()
        end = time.time_ns()
        cvt_time += (end - start)

        torch.cuda.synchronize()
        start = time.time_ns()
        cuda_lib.bfp_gemm_2d(
            c_void_p(lhs_wrapper.bfp_S.data_ptr()),
            c_void_p(lhs_wrapper.bfp_E.data_ptr()),
            c_void_p(lhs_wrapper.bfp_M.data_ptr()),

            c_void_p(rhs_wrapper.bfp_S.data_ptr()),
            c_void_p(rhs_wrapper.bfp_E.data_ptr()),
            c_void_p(rhs_wrapper.bfp_M.data_ptr()),

            c_void_p(bfp_output.data_ptr()),

            c_int32(M),
            c_int32(K),
            c_int32(N),

            c_int32(BfpConfig.group_size),
            c_int32(BfpConfig.bfp_M_Bit),
            c_int32(BfpConfig.bfp_M_Bit)
        )

        torch.cuda.synchronize()
        end = time.time_ns()
        run_time += (end - start)
    print(f"naive cvt exec: {cvt_time / iterations / 1000_000:.3f}ms")
    print(f"naive run exec: {run_time / iterations / 1000_000:.3f}ms")


    cvt_time = 0
    run_time = 0
    for i in range(iterations):
        torch.cuda.synchronize()
        start = time.time_ns()
        lhs_wrapper.run_convert_fp_to_bfp(src_tensor=lhs, is_stochastic_rounding=use_SR)
        rhs_wrapper.run_convert_fp_to_bfp(src_tensor=rhs, is_stochastic_rounding=use_SR)
        torch.cuda.synchronize()
        end = time.time_ns()
        cvt_time += (end - start)

        torch.cuda.synchronize()
        start = time.time_ns()
        cuda_optimized_lib.bfp_gemm_2d(
            c_void_p(lhs_wrapper.bfp_S.data_ptr()),
            c_void_p(lhs_wrapper.bfp_E.data_ptr()),
            c_void_p(lhs_wrapper.bfp_M.data_ptr()),

            c_void_p(rhs_wrapper.bfp_S.data_ptr()),
            c_void_p(rhs_wrapper.bfp_E.data_ptr()),
            c_void_p(rhs_wrapper.bfp_M.data_ptr()),

            c_void_p(bfp_output.data_ptr()),

            c_int32(M),
            c_int32(K),
            c_int32(N),

            c_int32(BfpConfig.group_size),
            c_int32(BfpConfig.bfp_M_Bit),
            c_int32(BfpConfig.bfp_M_Bit)
        )
        torch.cuda.synchronize()
        end = time.time_ns()
        run_time += (end - start)
    print(f"optim cvt exec: {cvt_time / iterations / 1000_000:.3f}ms")
    print(f"optim run exec: {run_time / iterations / 1000_000:.3f}ms")





    # print(bfp_output)
    # print(bfp_optim_output)