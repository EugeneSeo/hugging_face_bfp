import torch
from ctypes import *

import sys
if "/home/yskim/projects/sparse-bfp" not in sys.path:
    sys.path.append("/home/yskim/projects/sparse-bfp")

from util.bfp.bfp_config import BfpConfig
from util.reprod_util import set_reproducibility

lib = CDLL("./lib_cuda_bfp_converter_sorted.so")
# lib = CDLL("./lib_cuda_bfp_converter.so")

if __name__ == "__main__":
    set_reproducibility(1234)

    device = "cuda"
    shape = (16, 4096)
    chunk_size = 1024

    inputs = torch.rand(shape).to(device) * 0.001
    fp_from_bfp = torch.empty(shape).to(device)

    bfp_S = torch.zeros(
        size=shape,
        dtype=torch.int32, 
        device=device)

    bfp_E = torch.zeros(
        size=shape,
        dtype=torch.int32,
        device=device)

    bfp_E_indice = torch.zeros(
        size=shape,
        dtype=torch.int32,
        device=device)

    bfp_M = torch.zeros(
        size=shape, 
        dtype=torch.int64,
        device=device)

    ori_E = torch.zeros(
        size=shape,
        dtype=torch.int32,
        device=device)
    
    BfpConfig.bfp_M_Bit = 4

    should_sort = True

    lib.fp_to_bfp(
        c_void_p(inputs.data_ptr()),
        c_void_p(bfp_S.data_ptr()),
        c_void_p(bfp_E.data_ptr()),
        c_void_p(bfp_M.data_ptr()),

        c_void_p(bfp_E_indice.data_ptr()),
        c_int32(chunk_size),

        c_void_p(ori_E.data_ptr()),
        c_bool(should_sort),
        
        c_int32(inputs.shape[0]),
        c_int32(inputs.shape[1]),
        c_int32(BfpConfig.group_size),
        c_int32(BfpConfig.bfp_M_Bit),
        c_bool(True)
    )

    lib.bfp_to_fp(
        c_void_p(bfp_S.data_ptr()),
        c_void_p(bfp_E.data_ptr()),
        c_void_p(bfp_M.data_ptr()),
        c_void_p(fp_from_bfp.data_ptr()),
        c_bool(False),
        c_int32(inputs.shape[0]),
        c_int32(inputs.shape[1]),
        c_int32(BfpConfig.group_size),
        c_int32(BfpConfig.bfp_M_Bit),
        c_bool(True)
    )

    print(f"mean diff: {torch.mean(torch.abs(inputs - fp_from_bfp).flatten()):.10f}")


"""

c_lib.fp_to_bfp(
            c_void_p(src_tensor.data_ptr()),
            
            c_void_p(self.bfp_S.data_ptr()),
            c_void_p(self.bfp_E.data_ptr()),
            c_void_p(self.bfp_M.data_ptr()),
            
            c_void_p(self.ori_E.data_ptr()),

            c_bool(self.should_sort),

            c_int32(src_tensor.shape[0]),
            c_int32(src_tensor.shape[1]),
            c_int32(BfpConfig.group_size),
            c_int32(BfpConfig.bfp_M_Bit),
            c_bool(is_stochastic_rounding))

c_lib.bfp_to_fp(
    c_void_p(self.bfp_S.data_ptr()),
    c_void_p(self.bfp_E.data_ptr()),
    c_void_p(self.bfp_M.data_ptr()),
    c_void_p(dst_tensor.data_ptr()),

    c_bool(self.should_sort),
    
    c_int32(dst_tensor.shape[0]),
    c_int32(dst_tensor.shape[1]),
    c_int32(BfpConfig.group_size),
    c_int32(BfpConfig.bfp_M_Bit))
"""