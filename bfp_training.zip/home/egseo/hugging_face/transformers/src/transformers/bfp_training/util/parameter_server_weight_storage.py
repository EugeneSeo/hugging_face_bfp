import torch
import torch.nn as nn
from torchvision import models
from typing import List
from typing import Callable
import torch.distributed as dist

# def ps_send_gradients(module: nn.Module, dst: int):

class ParameterServerWeightStorage:
    def __init__(self, module: nn.Module, num_replicas: int, rank: int):
        self.device = f"cuda:{rank}"
        self.master_rank = 0
        self.module = module
        self.num_replicas = num_replicas
        # self.first_dim = torch.Size((num_replicas,))
        self.weights = []
        self.curr_gradient_idx = 0
        
        self.__generate_weight_buffers()
        
        
    def __append_linear_weights(self, layer: nn.Linear):
        self.weights.append(torch.empty(
            size=(layer.weight.shape),
            dtype=layer.weight.dtype,
            device=self.device))
        
        if layer.bias is not None:
            self.weights.append(torch.empty(
                size=(layer.bias.shape),
                dtype=layer.bias.dtype,
                device=self.device))
            
            
    def __append_conv_2d_weights(self, layer: nn.Conv2d):
        self.weights.append(torch.empty(
            size=(layer.weight.shape),
            dtype=layer.weight.dtype,
            device=self.device))
        
        if layer.bias is not None:
            self.weights.append(torch.empty(
                size=(layer.bias.shape),
                dtype=layer.bias.dtype,
                device=self.device))
            
            
    def __append_batch_norm_2d_weights(self, layer: nn.BatchNorm2d):
        if layer.affine == True:
            self.weights.append(torch.empty(
                size=(layer.weight.shape),
                dtype=layer.weight.dtype,
                device=self.device))
            
            self.weights.append(torch.empty(
                size=(layer.bias.shape),
                dtype=layer.bias.dtype,
                device=self.device))
        
            
    def __send_linear_weights(self, layer: nn.Linear):
        for dst_rank in range(1, self.num_replicas):
            dist.send(layer.weight, dst=dst_rank)

        if layer.bias is not None:
            for dst_rank in range(1, self.num_replicas):
                dist.send(layer.bias, dst=dst_rank)
        
        
    def __send_conv_2d_weights(self, layer: nn.Conv2d):
        for dst_rank in range(1, self.num_replicas):
            dist.send(layer.weight, dst=dst_rank)

        if layer.bias is not None:
            for dst_rank in range(1, self.num_replicas):
                dist.send(layer.bias, dst=dst_rank)
            
            
    def __send_batch_norm_2d_weights(self, layer: nn.BatchNorm2d):
        if layer.affine == True:
            for dst_rank in range(1, self.num_replicas):
                dist.send(layer.weight, dst=dst_rank)
            
            for dst_rank in range(1, self.num_replicas):
                dist.send(layer.bias, dst=dst_rank)


    def __recv_linear_weights(self, layer: nn.Linear):
        dist.recv(self.weights[self.curr_gradient_idx], src=self.master_rank)
        self.curr_gradient_idx += 1
            
        if layer.bias is not None:
            dist.recv(self.weights[self.curr_gradient_idx], src=self.master_rank)
            self.curr_gradient_idx += 1
            
            
    def __recv_conv_2d_weights(self, layer: nn.Conv2d):
        dist.recv(self.weights[self.curr_gradient_idx], src=self.master_rank)
        self.curr_gradient_idx += 1    
            
        if layer.bias is not None:
            dist.recv(self.weights[self.curr_gradient_idx], src=self.master_rank)
            self.curr_gradient_idx += 1
            
            
    def __recv_batch_norm_2d_weights(self, layer: nn.BatchNorm2d):
        if layer.affine == True:
            dist.recv(self.weights[self.curr_gradient_idx], src=self.master_rank)
            self.curr_gradient_idx += 1    
                
            if layer.bias is not None:
                dist.recv(self.weights[self.curr_gradient_idx], src=self.master_rank)
                self.curr_gradient_idx += 1
                
        
    def __recursive_action(self, module: nn.Module, linear_func: Callable, conv_2d_func: Callable, batch_norm_2d_func: Callable):
        for name, _ in module.named_children():
            child = getattr(module, name)
            child_cnt = 0
            for _ in child.children():
                child_cnt += 1

            if child_cnt == 0:
                layer = getattr(module, name)
                for _, param in layer.named_parameters():
                    if param.requires_grad:
                        pass

                if "Linear" in str(layer):
                    # print(f"linear w: {layer.weight.shape} b: {layer.bias.shape if layer.bias is not None else 'none'}")
                    linear_func(layer)
                elif "Conv" in str(layer):
                    # print(f"conv2d w: {layer.weight.shape} b: {layer.bias.shape if layer.bias is not None else 'none'}")
                    conv_2d_func(layer)
                        
                elif "BatchNorm" in str(layer):
                    # print(f"b-norm w: {layer.weight.shape} b: {layer.bias.shape if layer.bias is not None else 'none'}")
                    # print(f"running mean: {layer.running_mean.shape}, variance: {layer.running_var.shape}")
                    batch_norm_2d_func(layer)
            else:
                self.__recursive_action(child, linear_func, conv_2d_func, batch_norm_2d_func)


    def __load_linear_weights(self, layer: nn.Linear):
        self.weights[self.curr_gradient_idx].copy_(layer.weight)
        self.curr_gradient_idx += 1    
            
        if layer.bias is not None:
            self.weights[self.curr_gradient_idx].copy_(layer.bias)
            self.curr_gradient_idx += 1


    def __load_conv_2d_weights(self, layer: nn.Conv2d):
        self.weights[self.curr_gradient_idx].copy_(layer.weight)
        self.curr_gradient_idx += 1    
            
        if layer.bias is not None:
            self.weights[self.curr_gradient_idx].copy_(layer.bias)
            self.curr_gradient_idx += 1


    def __load_batch_norm_2d_weights(self, layer: nn.BatchNorm2d):
        if layer.affine == True:
            self.weights[self.curr_gradient_idx].copy_(layer.weight)
            self.curr_gradient_idx += 1    
                
            if layer.bias is not None:
                self.weights[self.curr_gradient_idx].copy_(layer.bias)
                self.curr_gradient_idx += 1
                
    
    def __store_linear_weights(self, layer: nn.Linear):
        with torch.no_grad():
            layer.weight.copy_(self.weights[self.curr_gradient_idx])
            self.curr_gradient_idx += 1    
                
            if layer.bias is not None:
                layer.bias.copy_(self.weights[self.curr_gradient_idx])
                self.curr_gradient_idx += 1


    def __store_conv_2d_weights(self, layer: nn.Conv2d):
        with torch.no_grad():
            layer.weight.copy_(self.weights[self.curr_gradient_idx])
            self.curr_gradient_idx += 1    
                
            if layer.bias is not None:
                layer.bias.copy_(self.weights[self.curr_gradient_idx])
                self.curr_gradient_idx += 1


    def __store_batch_norm_2d_weights(self, layer: nn.BatchNorm2d):
        with torch.no_grad():
            if layer.affine == True:
                layer.weight.copy_(self.weights[self.curr_gradient_idx])
                self.curr_gradient_idx += 1    
                    
                if layer.bias is not None:
                    layer.bias.copy_(self.weights[self.curr_gradient_idx])
                    self.curr_gradient_idx += 1


    def __generate_weight_buffers(self):    
        self.__recursive_action(
            self.module,
            self.__append_linear_weights,
            self.__append_conv_2d_weights,
            self.__append_batch_norm_2d_weights)

        
    def send_weights(self):
        self.__recursive_action(
            self.module,
            self.__send_linear_weights,
            self.__send_conv_2d_weights,
            self.__send_batch_norm_2d_weights)

        
    def recv_weights(self):
        self.curr_gradient_idx = 0
        self.__recursive_action(
            self.module,
            self.__recv_linear_weights,
            self.__recv_conv_2d_weights,
            self.__recv_batch_norm_2d_weights)

        
    def load_weights_from_module(self):
        self.curr_gradient_idx = 0
        self.__recursive_action(
            self.module,
            self.__load_linear_weights,
            self.__load_conv_2d_weights,
            self.__load_batch_norm_2d_weights)

        
    def store_weights_to_module(self):
        self.curr_gradient_idx = 0
        self.__recursive_action(
            self.module,
            self.__store_linear_weights,
            self.__store_conv_2d_weights,
            self.__store_batch_norm_2d_weights)


if __name__ == "__main__":
    model = models.alexnet(pretrained=False)
    
    weight_storage = ParameterServerWeightStorage(model, 4, 0)
    
    weight_storage.load_weights_from_module()
    
    for weight in weight_storage.weights:
        print(weight)