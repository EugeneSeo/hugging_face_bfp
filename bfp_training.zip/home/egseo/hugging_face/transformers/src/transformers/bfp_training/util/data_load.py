import os
from typing import Tuple, Optional
from torch.utils.data import DataLoader
from torchvision import datasets, transforms
from torchvision.datasets import ImageFolder
from util.reprod_util import seed_worker
from torch.utils.data.distributed import DistributedSampler

import torch.distributed as dist

DL_TYPE_CIFAR_10 = 0
DL_TYPE_CIFAR_100 = 1
DL_TYPE_IMAGENET = 2

data_norm = {
    'imagenet': {
        'mean': (0.485, 0.456, 0.406),
        'std': (0.229, 0.224, 0.225)
    },
    'cifar-10': {
        'mean': (0.491, 0.482, 0.446),
        'std': (0.247, 0.243, 0.261)
    },
    'cifar-100': {
        'mean': (0.507, 0.486, 0.440),
        'std': (0.267, 0.256, 0.276)
    }
}

BFP_HOME = os.environ["BFP_HOME"]
data_root = f"{BFP_HOME}/data"

def generate_data_loaders(type,
                          batch_size=32,
                          num_workers=0,
                          is_distributed=False) -> Tuple[DataLoader, DataLoader, Optional[DistributedSampler]]:
    if type == DL_TYPE_CIFAR_10:
        image_size = (32, 32)
        mean = data_norm['cifar-10']['mean']
        std = data_norm['cifar-10']['std']
    elif type == DL_TYPE_CIFAR_100:
        image_size = (32, 32)
        mean = data_norm['cifar-100']['mean']
        std = data_norm['cifar-100']['std']
    elif type == DL_TYPE_IMAGENET:
        image_size = (224, 224)
        mean = data_norm['imagenet']['mean']
        std = data_norm['imagenet']['std']
    else:
        raise ValueError(f"invalid data loader type: {type}")

    data_transforms_train = transforms.Compose([
        # transforms.Resize(image_size),
        # transforms.RandomGrayscale(),
        # transforms.ColorJitter(brightness=0.5, hue=0.3),
        # transforms.RandomVerticalFlip(),

        transforms.RandomResizedCrop(image_size[0]),
        # transforms.RandomRotation(degrees=(-45, 45)),
        transforms.RandomHorizontalFlip(),

        # transforms.Resize(image_size),
        transforms.ToTensor(),
        transforms.Normalize(mean=mean, std=std),
    ])

    data_transforms_valid = transforms.Compose([
        transforms.Resize(image_size),
        transforms.ToTensor(),
        transforms.Normalize(mean=mean, std=std),
    ])

    if type == DL_TYPE_CIFAR_10:
        train_data = datasets.CIFAR10(root=data_root, train=True, transform=data_transforms_train, download=True)
        valid_data = datasets.CIFAR10(root=data_root, train=False, transform=data_transforms_valid, download=True)
    elif type == DL_TYPE_CIFAR_100:
        train_data = datasets.CIFAR100(root=data_root, train=True, transform=data_transforms_train, download=True)
        valid_data = datasets.CIFAR100(root=data_root, train=False, transform=data_transforms_valid, download=True)
    elif type == DL_TYPE_IMAGENET:
        train_data = ImageFolder(root="/data/imagenet/train", transform=data_transforms_train)
        valid_data = ImageFolder(root="/data/imagenet/val", transform=data_transforms_valid)
    else:
        raise ValueError(f"invalid data loader type: {type}")

    if is_distributed:
        # print(f"my rank: {dist.get_rank()}, # of replicas: {dist.get_world_size()}")
        train_dist_sampler = DistributedSampler(train_data)
    else:
        train_dist_sampler = None

    train_data_loader = DataLoader(train_data,
                               batch_size=batch_size,
                               worker_init_fn=seed_worker,
                               num_workers=num_workers,
                               pin_memory=True,
                               drop_last=True, # because of pre-allocated CUDA buffers (it must be fixed)
                               shuffle=(train_dist_sampler is None),
                               sampler=train_dist_sampler if is_distributed else None) # TODO: set true

    valid_data_loader = DataLoader(valid_data,
                               batch_size=batch_size,
                               worker_init_fn=seed_worker,
                               num_workers=num_workers,
                               pin_memory=True,
                               drop_last=True,
                               shuffle=False)

    return train_data_loader, valid_data_loader, train_dist_sampler