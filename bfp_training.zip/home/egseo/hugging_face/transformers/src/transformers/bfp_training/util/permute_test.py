import time
import torch
from ctypes import *

lib = CDLL("./lib_sample.so")
perm_lib = CDLL("/home/yskim/projects/sparse-bfp/util/bfp/cuda/lib_cuda_memory_helper.so")

if __name__ == "__main__":
    # batch, channels, width, height = 3, 196, 224, 224
    batch, channels, width, height = 32, 196, 224, 224
    # batch, channels, width, height = 3, 32, 32, 32
    # batch, channels, width, height = 2, 8, 8, 8
    shape = (batch, channels, width, height)

    mat = torch.randint(low=-3, high=3, size=shape, dtype=torch.float)
    # print(mat.numpy())
    mat = mat.to('cuda')
    print(mat.shape)

    start = time.time_ns()
    # mat_perm = mat.permute([0, 2, 3, 1])
    mat_perm = mat.permute([0, 3, 1, 2])
    end = time.time_ns()
    print(f"torch time : {((end - start) / 1000_000)}ms")

    mat_perm_our = torch.empty(size=(mat_perm.shape), dtype=torch.float).to('cuda')

    
    # perm_lib.permute_nchw_to_nhwc(
    perm_lib.permute_nhwc_to_nchw(
        c_void_p(mat_perm_our.data_ptr()),
        c_void_p(mat.data_ptr()),
        c_size_t(mat.shape[0]),
        c_size_t(mat.shape[1]),
        c_size_t(mat.shape[2]),
        c_size_t(mat.shape[3]),
    )

    start = time.time_ns()
    # perm_lib.permute_nchw_to_nhwc(
    perm_lib.permute_nhwc_to_nchw(
        c_void_p(mat_perm_our.data_ptr()),
        c_void_p(mat.data_ptr()),
        c_size_t(mat.shape[0]),
        c_size_t(mat.shape[1]),
        c_size_t(mat.shape[2]),
        c_size_t(mat.shape[3]),
    )
    end = time.time_ns()
    print(f"cuda time  : {((end - start) / 1000_000)}ms")


    print(mat_perm.shape)

    mat_perm = mat_perm.to('cpu')
    mat_perm_our = mat_perm_our.to('cpu')

    print(torch.mean(torch.abs((mat_perm - mat_perm_our).flatten())))


    height = 4096
    width = 128
    shape = (height, width)
    mat_2d = torch.randn(size=shape).to('cuda')

    start = time.time_ns()
    mat_2d_t_torch = mat_2d.t()
    end = time.time_ns()
    print(f"transpose torch time  : {((end - start) / 1000_000)}ms")

    mat_2d_t_cuda = torch.empty(size=mat_2d_t_torch.shape, dtype=torch.float).to('cuda')

    perm_lib.transpose_2d(
        c_void_p(mat_2d_t_cuda.data_ptr()),
        c_void_p(mat_2d.data_ptr()),
        c_size_t(shape[0]),
        c_size_t(shape[1])
    )
    start = time.time_ns()
    perm_lib.transpose_2d(
        c_void_p(mat_2d_t_cuda.data_ptr()),
        c_void_p(mat_2d.data_ptr()),
        c_size_t(shape[0]),
        c_size_t(shape[1])
    )
    end = time.time_ns()
    print(f"transpose cuda time   : {((end - start) / 1000_000)}ms")

    mat_2d_t_torch = mat_2d_t_torch.to('cpu')
    mat_2d_t_cuda = mat_2d_t_cuda.to('cpu')

    print(torch.mean(torch.abs((mat_2d_t_torch - mat_2d_t_cuda).flatten())))


    shape = (32, 196, 128, 256)
    mat_4d = torch.randn(size=shape).to('cuda')

    start = time.time_ns()
    mat_4d_t_torch = mat_4d.permute([0, 1, 3, 2])
    end = time.time_ns()
    print(f"transpose torch time  : {((end - start) / 1000_000)}ms")

    mat_4d_t_cuda = torch.empty(size=mat_4d_t_torch.shape, dtype=torch.float).to('cuda')

    perm_lib.transpose_4d(
        c_void_p(mat_4d_t_cuda.data_ptr()),
        c_void_p(mat_4d.data_ptr()),
        c_size_t(shape[0]),
        c_size_t(shape[1]),
        c_size_t(shape[2]),
        c_size_t(shape[3])
    )
    start = time.time_ns()
    perm_lib.transpose_4d(
        c_void_p(mat_4d_t_cuda.data_ptr()),
        c_void_p(mat_4d.data_ptr()),
        c_size_t(shape[0]),
        c_size_t(shape[1]),
        c_size_t(shape[2]),
        c_size_t(shape[3])
    )
    end = time.time_ns()
    print(f"transpose cuda time   : {((end - start) / 1000_000)}ms")

    mat_4d_t_torch = mat_4d_t_torch.to('cpu')
    mat_4d_t_cuda = mat_4d_t_cuda.to('cpu')

    print(torch.mean(torch.abs((mat_4d_t_torch - mat_4d_t_cuda).flatten())))


    shape = (32 * 196, 128, 256)
    mat_3d = torch.randn(size=shape).to('cuda')

    start = time.time_ns()
    mat_3d_t_torch = mat_3d.permute([0, 2, 1])
    end = time.time_ns()
    print(f"transpose torch time  : {((end - start) / 1000_000)}ms")

    mat_3d_t_cuda = torch.empty(size=mat_3d_t_torch.shape, dtype=torch.float).to('cuda')

    perm_lib.transpose_4d(
        c_void_p(mat_3d_t_cuda.data_ptr()),
        c_void_p(mat_3d.data_ptr()),
        c_size_t(1),
        c_size_t(shape[0]),
        c_size_t(shape[1]),
        c_size_t(shape[2])
    )
    start = time.time_ns()
    perm_lib.transpose_4d(
        c_void_p(mat_3d_t_cuda.data_ptr()),
        c_void_p(mat_3d.data_ptr()),
        c_size_t(1),
        c_size_t(shape[0]),
        c_size_t(shape[1]),
        c_size_t(shape[2])
    )
    end = time.time_ns()
    print(f"transpose cuda time   : {((end - start) / 1000_000)}ms")

    mat_3d_t_torch = mat_3d_t_torch.to('cpu')
    mat_3d_t_cuda = mat_3d_t_cuda.to('cpu')

    print(f"shapes: {mat_3d_t_torch.shape}, {mat_3d_t_cuda.shape}")

    print(torch.mean(torch.abs((mat_3d_t_torch - mat_3d_t_cuda).flatten())))