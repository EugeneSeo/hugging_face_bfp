import torch
import torch.nn as nn
from torchvision import models
from typing import List
from typing import Callable
import torch.distributed as dist

# def ps_send_gradients(module: nn.Module, dst: int):

class ParameterServerGradientStorage:
    def __init__(self, module: nn.Module, num_replicas: int, rank: int):
        self.device = f"cuda:{rank}"
        self.master_rank = 0
        self.module = module
        self.num_replicas = num_replicas
        self.first_dim = torch.Size((num_replicas,))
        self.gradients = []
        self.curr_gradient_idx = 0
        
        self.__generate_gradient_buffers(module, num_replicas, self.gradients)
        
        
    def __append_linear_gradients(self, layer: nn.Linear):
        self.gradients.append(torch.empty(
            size=(self.first_dim + layer.weight.shape),
            dtype=layer.weight.dtype,
            device=self.device))
        
        if layer.bias is not None:
            self.gradients.append(torch.empty(
                size=(self.first_dim + layer.bias.shape),
                dtype=layer.bias.dtype,
                device=self.device))
            
            
    def __append_conv_2d_gradients(self, layer: nn.Conv2d):
        self.gradients.append(torch.empty(
            size=(self.first_dim + layer.weight.shape),
            dtype=layer.weight.dtype,
            device=self.device))
        
        if layer.bias is not None:
            self.gradients.append(torch.empty(
                size=(self.first_dim + layer.bias.shape),
                dtype=layer.bias.dtype,
                device=self.device))
            
            
    def __append_batch_norm_2d_gradients(self, layer: nn.BatchNorm2d):
        if layer.affine == True:
            self.gradients.append(torch.empty(
                size=(self.first_dim + layer.weight.shape),
                dtype=layer.weight.dtype,
                device=self.device))
            
            self.gradients.append(torch.empty(
                size=(self.first_dim + layer.bias.shape),
                dtype=layer.bias.dtype,
                device=self.device))
        
            
    def __send_linear_gradients(self, layer: nn.Linear):
        dist.send(layer.weight.grad, dst=self.master_rank)

        if layer.bias is not None:
            dist.send(layer.bias.grad, dst=self.master_rank)
        
        
    def __send_conv_2d_gradients(self, layer: nn.Conv2d):    
        dist.send(layer.weight.grad, dst=self.master_rank)

        if layer.bias is not None:
            dist.send(layer.bias.grad, dst=self.master_rank)
            
            
    def __send_batch_norm_2d_gradients(self, layer: nn.BatchNorm2d):
        if layer.affine == True:
            dist.send(layer.weight.grad, dst=self.master_rank)
            dist.send(layer.bias.grad, dst=self.master_rank)


    def __recv_linear_gradients(self, layer: nn.Linear):
        for src_idx in range(1, self.num_replicas):
            dist.recv(self.gradients[self.curr_gradient_idx][src_idx], src=src_idx)
        self.curr_gradient_idx += 1    
            
        if layer.bias is not None:
            for src_idx in range(1, self.num_replicas):
                dist.recv(self.gradients[self.curr_gradient_idx][src_idx], src=src_idx)
            self.curr_gradient_idx += 1
            
            
    def __recv_conv_2d_gradients(self, layer: nn.Conv2d):
        for src_idx in range(1, self.num_replicas):
            dist.recv(self.gradients[self.curr_gradient_idx][src_idx], src=src_idx)
        self.curr_gradient_idx += 1    
            
        if layer.bias is not None:
            for src_idx in range(1, self.num_replicas):
                dist.recv(self.gradients[self.curr_gradient_idx][src_idx], src=src_idx)
            self.curr_gradient_idx += 1
            
            
    def __recv_batch_norm_2d_gradients(self, layer: nn.BatchNorm2d):
        if layer.affine == True:
            for src_idx in range(1, self.num_replicas):
                dist.recv(self.gradients[self.curr_gradient_idx][src_idx], src=src_idx)
            self.curr_gradient_idx += 1    
                
            if layer.bias is not None:
                for src_idx in range(1, self.num_replicas):
                    dist.recv(self.gradients[self.curr_gradient_idx][src_idx], src=src_idx)
                self.curr_gradient_idx += 1
                
        
    def __recursive_action(self, module: nn.Module, linear_func: Callable, conv_2d_func: Callable, batch_norm_2d_func: Callable):
        for name, _ in module.named_children():
            child = getattr(module, name)
            child_cnt = 0
            for _ in child.children():
                child_cnt += 1

            if child_cnt == 0:
                layer = getattr(module, name)
                for _, param in layer.named_parameters():
                    if param.requires_grad:
                        pass

                if "Linear" in str(layer):
                    # print(f"linear w: {layer.weight.shape} b: {layer.bias.shape if layer.bias is not None else 'none'}")
                    linear_func(layer)
                elif "Conv" in str(layer):
                    # print(f"conv2d w: {layer.weight.shape} b: {layer.bias.shape if layer.bias is not None else 'none'}")
                    conv_2d_func(layer)
                        
                elif "BatchNorm" in str(layer):
                    # print(f"b-norm w: {layer.weight.shape} b: {layer.bias.shape if layer.bias is not None else 'none'}")
                    # print(f"running mean: {layer.running_mean.shape}, variance: {layer.running_var.shape}")
                    batch_norm_2d_func(layer)
            else:
                self.__recursive_action(child, linear_func, conv_2d_func, batch_norm_2d_func)


    def __master_copy_linear_gradients(self, layer: nn.Linear):
        self.gradients[self.curr_gradient_idx][0] = layer.weight.grad.clone().detach()
        self.curr_gradient_idx += 1    
            
        if layer.bias is not None:
            self.gradients[self.curr_gradient_idx][0] = layer.bias.grad.clone().detach()
            self.curr_gradient_idx += 1
            
    def __master_copy_conv_2d_gradients(self, layer: nn.Conv2d):
        self.gradients[self.curr_gradient_idx][0] = layer.weight.grad.clone().detach()
        self.curr_gradient_idx += 1    
            
        if layer.bias is not None:
            self.gradients[self.curr_gradient_idx][0] = layer.bias.grad.clone().detach()
            self.curr_gradient_idx += 1
            
    def __master_copy_batch_norm_2d_gradients(self, layer: nn.BatchNorm2d):
        if layer.affine == True:
            self.gradients[self.curr_gradient_idx][0] = layer.weight.grad.clone().detach()
            self.curr_gradient_idx += 1    
                
            if layer.bias is not None:
                self.gradients[self.curr_gradient_idx][0] = layer.bias.grad.clone().detach()
                self.curr_gradient_idx += 1


    def __generate_gradient_buffers(self, module: torch.nn.Module, num_replicas: int, result: List[torch.Tensor]):    
        self.__recursive_action(
            self.module,
            self.__append_linear_gradients,
            self.__append_conv_2d_gradients,
            self.__append_batch_norm_2d_gradients)
        
    def send_gradients(self):
        self.__recursive_action(
            self.module,
            self.__send_linear_gradients,
            self.__send_conv_2d_gradients,
            self.__send_batch_norm_2d_gradients)
        
    def recv_gradients(self):
        self.curr_gradient_idx = 0
        self.__recursive_action(
            self.module,
            self.__recv_linear_gradients,
            self.__recv_conv_2d_gradients,
            self.__recv_batch_norm_2d_gradients)
        
    def master_copy_gradients(self):
        if dist.get_rank() != 0:
            raise ValueError(f"only master rank can call this function (this rank: {dist.get_rank()})")
    
        self.curr_gradient_idx = 0
        self.__recursive_action(
            self.module,
            self.__master_copy_linear_gradients,
            self.__master_copy_conv_2d_gradients,
            self.__master_copy_batch_norm_2d_gradients)

def add(x: int):
    x += 1

if __name__ == "__main__":
    model = models.alexnet(pretrained=False)
    
    gradient_storage = ParameterServerGradientStorage(model, 4)
    
    for grad in gradient_storage.gradients:
        print(grad.shape)
    
    x = 1
    add(x)
    print(x)