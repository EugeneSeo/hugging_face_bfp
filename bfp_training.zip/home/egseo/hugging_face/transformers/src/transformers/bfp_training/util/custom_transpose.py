import torch

from ctypes import *

import os
BFP_HOME = os.environ["BFP_HOME"]
perm_lib = CDLL(f"{BFP_HOME}/util/bfp/cuda/lib_cuda_memory_helper.so")


def custom_nhwc_to_nchw(dst: torch.Tensor, src: torch.Tensor):
    shape = src.shape
    n, h, w, c = shape[0], shape[1], shape[2], shape[3]

    # result = torch.empty(size=(n, c, h, w), dtype=torch.float, device='cuda')

    perm_lib.permute_nhwc_to_nchw(
        c_void_p(dst.data_ptr()),
        c_void_p(src.data_ptr()),
        c_size_t(n),
        c_size_t(h),
        c_size_t(w),
        c_size_t(c),
    )

    # return result


def custom_nchw_to_nhwc(dst: torch.Tensor, src: torch.Tensor):
    shape = src.shape
    n, c, h, w = shape[0], shape[1], shape[2], shape[3]

    perm_lib.permute_nchw_to_nhwc(
        c_void_p(dst.data_ptr()),
        c_void_p(src.data_ptr()),
        c_size_t(n),
        c_size_t(c),
        c_size_t(h),
        c_size_t(w),
    )


def custom_transpose_2d(dst: torch.Tensor, src: torch.Tensor):
    if len(src.shape) > 2:
        h = int(torch.prod(torch.tensor(src.shape[:-1])).item())
        w = int(src.shape[-1])
    else:
        h = int(src.shape[0])
        w = int(src.shape[1])
        
    # shape = src.shape
    # h, w = shape[0], shape[1]

    perm_lib.transpose_2d(
        c_void_p(dst.data_ptr()),
        c_void_p(src.data_ptr()),
        c_size_t(h),
        c_size_t(w),
    )

def custom_transpose_3d(dst: torch.Tensor, src: torch.Tensor):
    shape = src.shape
    c, h, w = shape[0], shape[1], shape[2]

    perm_lib.transpose_4d(
        c_void_p(dst.data_ptr()),
        c_void_p(src.data_ptr()),
        c_size_t(1),
        c_size_t(c),
        c_size_t(h),
        c_size_t(w),
    )

def custom_transpose_4d(dst: torch.Tensor, src: torch.Tensor):
    shape = src.shape
    n, c, h, w = shape[0], shape[1], shape[2], shape[3]

    perm_lib.transpose_4d(
        c_void_p(dst.data_ptr()),
        c_void_p(src.data_ptr()),
        c_size_t(n),
        c_size_t(c),
        c_size_t(h),
        c_size_t(w),
    )


if __name__ == "__main__":
    shape_4d = (32, 3, 224, 224)
    
    nchw = torch.randn(size=shape_4d).to('cuda')
    nhwc_torch = nchw.permute([0, 2, 3, 1])
    nhwc_cuda = torch.randn(size=nhwc_torch.shape).to('cuda')
    custom_nchw_to_nhwc(nhwc_cuda, nchw)
    
    print(torch.mean(torch.abs((nhwc_torch - nhwc_cuda).flatten())))


    nhwc = torch.randn(size=shape_4d).to('cuda')
    nchw_torch = nhwc.permute([0, 3, 1, 2])
    nchw_cuda = torch.randn(size=nchw_torch.shape).to('cuda')
    custom_nhwc_to_nchw(nchw_cuda, nhwc)
    
    print(torch.mean(torch.abs((nchw_torch - nchw_cuda).flatten())))

    shape_2d = (32 * 3, 224 * 224)
    hw = torch.randn(size=shape_2d).to('cuda')
    wh_torch = hw.permute([1, 0])
    hw_cuda = torch.randn(size=wh_torch.shape).to('cuda')
    custom_transpose_2d(hw, hw_cuda)
    print(torch.mean(torch.abs((wh_torch - hw_cuda).flatten())))

    shape_3d = (32 * 3, 224, 256)
    hw = torch.randn(size=shape_3d).to('cuda')
    wh_torch = hw.permute([0, 2, 1])
    hw_cuda = torch.randn(size=wh_torch.shape).to('cuda')
    custom_transpose_3d(hw, hw_cuda)
    print(torch.mean(torch.abs((wh_torch - hw_cuda).flatten())))

    shape_4d = (32, 3, 224, 256)
    hw = torch.randn(size=shape_4d).to('cuda')
    wh_torch = hw.permute([0, 1, 3, 2])
    hw_cuda = torch.randn(size=wh_torch.shape).to('cuda')
    custom_transpose_4d(hw, hw_cuda)
    print(torch.mean(torch.abs((wh_torch - hw_cuda).flatten())))


