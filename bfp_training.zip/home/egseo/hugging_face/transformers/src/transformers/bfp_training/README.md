# BFP-Training
## Requirements
* PyTorch
* NumPy
## Environment Variable
In your ***.zshrc***, set ***PYPATH*** and add ***BFP_HOME*** environment variable

    # in .zshrc
    export PYTHONPATH="${PYTHONPATH}:<repository-path>"
    export BFP_HOME=<repository-path>
## Build required .so files
To use C/C++ based CUDA modules, build some ***.so*** files at ***\<repository-path\>/util/bfp/cuda***

    $ make lib_cuda_bfp_converter.so
    $ make lib_cuda_bfp_multi_exp_converter.so
    $ make lib_cuda_memory_helper.so
    $ make lib_not_sorted_gemm_cuda.so
    $ make lib_multi_exp_gemm_cuda.so
## Unit test custom layers
At ***\<repository-path\>/util***, you can test custom 2D convolution layer and fully connected layer
    
    $ python custom_conv2d.py
    $ python custom_linear.py