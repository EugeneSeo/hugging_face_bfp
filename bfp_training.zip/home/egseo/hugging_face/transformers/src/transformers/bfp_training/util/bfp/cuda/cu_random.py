import torch
from ctypes import *

import os
BFP_HOME = os.environ["BFP_HOME"]
c_lib = CDLL(f"{BFP_HOME}/util/bfp/cuda/lib_random.so")

if __name__ == "__main__":
    size = 1024
    t = torch.empty(size=(size,), dtype=torch.float, device="cuda")
    c_lib.generate_random_values(
        c_void_p(t.data_ptr()),
        c_size_t(size)
    )

    t = t.cpu()

    print(t[0:10])
