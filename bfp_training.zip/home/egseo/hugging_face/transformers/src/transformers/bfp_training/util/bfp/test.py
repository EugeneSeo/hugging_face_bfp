import sys
import torch
import ctypes
import numpy as np
from ctypes import *


if "/home/yskim/projects/sparse-bfp" not in sys.path:
    sys.path.append("/home/yskim/projects/sparse-bfp")

from util.bfp.bfp_config import BfpConfig
from util.reprod_util import set_reproducibility
from util.bfp.cuda.test_cuda_mem import CudaFloatStorage, CudaInt32Storage, CudaInt64Storage

bfp_so_file_path = "/home/yskim/projects/sparse-bfp/util/bfp/cuda/lib_cuda_memory_helper.so"
c_lib = ctypes.CDLL(bfp_so_file_path)

# bfp_so_file_path = "/home/yskim/projects/sparse-bfp/util/bfp/cuda/lib_cuda_bfp_converter.so"
# c_lib = ctypes.CDLL(bfp_so_file_path)


if __name__ == "__main__":
    device = "cuda"
    # shape = [8, 3, 224, 224]
    shape = [1, 1, 2, 2]
    
    torch_tensor = torch.randn(size=shape).to(device)
    # ptr = torch_tensor.data_ptr

    cmp_tensor = torch.zeros(size=shape).to(device)

    c_lib.cuda_d2d_copy(
        c_void_p(cmp_tensor.data_ptr()),
        c_void_p(torch_tensor.data_ptr()),
        c_size_t(np.prod(shape)),
        c_size_t(4),
    )

    print("torch_tensor")
    print(torch_tensor.cpu().numpy())

    print("cmp")
    print(cmp_tensor.cpu().numpy())
