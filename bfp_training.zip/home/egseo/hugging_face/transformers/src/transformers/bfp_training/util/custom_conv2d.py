from typing import OrderedDict
import torch
import torch.nn as nn

import numpy as np
import time

import os
BFP_HOME = os.environ["BFP_HOME"]

import math

from util.bfp.bfp_config import BfpConfig, PrecisionFlag
from util.bfp.bfp_gemm import BfpGemm
from util.bfp.fast_bfp_gemm import FastBfpGemm
from util.custom_transpose import custom_transpose_2d, custom_transpose_3d, custom_nchw_to_nhwc, custom_nhwc_to_nchw
from util.reprod_util import set_reproducibility

from ctypes import *
cuda_lib = CDLL(f"{BFP_HOME}/util/bfp/cuda/lib_cuda_zero_indexed_gemm.so")

class Conv2dFunction(torch.autograd.Function):
    @staticmethod
    def calculate_output_width(width, kernel_size, stride, padding):
        return math.floor(((width + 2 * padding - (kernel_size)) / stride) + 1)

    @staticmethod
    def remove_padding(tensor: torch.Tensor, padding) -> torch.Tensor:
        h, w = tensor.shape[2], tensor.shape[3]
        
        return tensor[:, :, padding:h-padding, padding:w-padding]

    @staticmethod
    def im2col(padded_inputs: torch.Tensor, 
               in_channels, out_width, 
               kernel_size, stride) -> torch.Tensor:
        batch_size = padded_inputs.shape[0]

        results = torch.empty(batch_size, 
                              out_width, 
                              out_width, 
                              in_channels * kernel_size * kernel_size)

        reshaped_results = results.reshape(batch_size * out_width * out_width,
                                           in_channels * kernel_size * kernel_size)

        row_index = 0
        for batch_idx in range(batch_size):
            single_inputs = padded_inputs[batch_idx]
            for h_out in range(out_width):
                for w_out in range(out_width):
                    h_start = h_out * stride
                    w_start = w_out * stride
                    window = single_inputs[:,
                                           h_start : h_start + kernel_size,
                                           w_start : w_start + kernel_size]
                    reshaped_results[row_index] = window.flatten()

                    row_index += 1

        return results

    @staticmethod
    def col2im(im2col: torch.Tensor,
               padded_inputs_shape: torch.Size, 
               in_channels, out_width, 
               kernel_size, stride) -> torch.Tensor:
        batch_size = padded_inputs_shape[0]

        results = torch.zeros(padded_inputs_shape)

        row_index = 0
        for batch_idx in range(batch_size):
            for h_out in range(out_width):
                for w_out in range(out_width):
                    h_start = h_out * stride
                    w_start = w_out * stride
                    sub_inputs = im2col[row_index].reshape(in_channels, 
                                                           kernel_size,
                                                           kernel_size)
                    results[batch_idx,
                            :,
                            h_start : h_start + kernel_size,
                            w_start : w_start + kernel_size] += sub_inputs

                    row_index += 1

        return results

    @staticmethod
    def forward(ctx, inputs, weights, bias,
                in_channels, out_channels,
                kernel_size, stride, padding,
                precision_flag: PrecisionFlag,
                bfp_gemms,
                im2col,
                col2im,
                intermediate_memory,
                id,
                global_id):
        if inputs.shape[2] != inputs.shape[3]:
            raise ValueError(f"not supported inputs widht, and height ({inputs.shape[2]}, {inputs.shape[3]})")

        if precision_flag == PrecisionFlag.FP:
            prec_name = "fp"
        elif precision_flag == PrecisionFlag.BFP:
            if BfpConfig.use_multi_exp:
                prec_name = "multi-exp"
            else:
                prec_name = "bfp"
        else:
            raise ValueError(f"not supported precision flag: {precision_flag}")

        batch_size = inputs.shape[0]
        out_width = Conv2dFunction.calculate_output_width(inputs.shape[2], 
                                                          kernel_size,
                                                          stride,
                                                          padding)

        # im2col_start = time.time_ns()
        im2col_3d = im2col(inputs)
        if intermediate_memory["im2col-inputs-2d"] is None:
            # shape = im2col_3d.shape
            intermediate_memory["im2col-inputs-2d"] = torch.empty(
                size=(im2col_3d.shape[0] * im2col_3d.shape[2], im2col_3d.shape[1]),
                dtype=torch.float,
                device="cuda")

        im2col_inputs_2d = intermediate_memory["im2col-inputs-2d"]
    
        custom_transpose_3d(dst=im2col_inputs_2d, src=im2col_3d)

        # im2col_inputs = torch.permute(im2col_inputs, [0, 2, 1])
        
        # im2col_inputs = im2col_inputs.reshape(
        #     im2col_inputs.shape[0] * im2col_inputs.shape[1],
        #     im2col_inputs.shape[2])

        # im2col_end = time.time_ns()
        # print(f"fwd im2col time: {((im2col_end - im2col_start) / 1000_000):.5f}ms")

        # weight_reshape_start = time.time_ns()
        weight_reshaped = weights.reshape((out_channels, -1))
        # weight_reshape_end = time.time_ns()
        # print(f"fwd weight reshaped time: {((weight_reshape_end - weight_reshape_start) / 1000_000):.5f}ms")

        ctx.save_for_backward(im2col_inputs_2d, weights, bias)

        ctx.in_channels = in_channels
        ctx.out_channels = out_channels
        ctx.stride = stride
        ctx.kernel_size = kernel_size
        ctx.padding = padding
        ctx.in_width = inputs.shape[2]
        ctx.out_width = out_width
        # ctx.padded_inputs_shape = padded_inputs.shape
        ctx.precision_flag = precision_flag
        ctx.bfp_gemms = bfp_gemms
        ctx.col2im = col2im
        ctx.intermediate_memory = intermediate_memory
        ctx.id = id
        ctx.global_id = global_id
        ctx.prec_name = prec_name

        M = im2col_inputs_2d.shape[0] # im2col_inputs.shape[0] * im2col_inputs.shape[1] * im2col_inputs.shape[2] 
        K = im2col_inputs_2d.shape[1] # im2col_inputs.shape[3]

        # im2col_inputs_reshaped = im2col_inputs.reshape(M, K)

        if precision_flag == PrecisionFlag.FP:
            outputs_2d = torch.matmul(im2col_inputs_2d, weight_reshaped.t())

        elif precision_flag == PrecisionFlag.BFP:
            if bfp_gemms["fwd"] is None:
                if BfpConfig.is_fast:
                    bfp_gemms["fwd"] = FastBfpGemm(
                        im2col_inputs_2d.shape,
                        weight_reshaped.shape,
                        use_stochastic_rounding=BfpConfig.f_st,
                        use_flex_bfp=BfpConfig.use_flex_bfp,
                        layer_index=global_id,
                        name=f"conv2d-{id}-fwd")
                else:
                    bfp_gemms["fwd"] = BfpGemm(
                        im2col_inputs_2d.shape,
                        weight_reshaped.shape,
                        use_stochastic_rounding=BfpConfig.f_st,
                        use_multi_exp=BfpConfig.use_multi_exp,
                        apply_thresholding=BfpConfig.f_thres,
                        threshold=BfpConfig.threshold)

            bfp_gemm = bfp_gemms["fwd"]
            outputs_2d = bfp_gemm.run(im2col_inputs_2d, weight_reshaped)

            # if BfpConfig.f_thres:
                # fp_outputs_2d = torch.matmul(im2col_inputs_2d, weight_reshaped.t())
                # error_outputs_2d = torch.abs((fp_outputs_2d - outputs_2d) / (fp_outputs_2d + 1e-15)) * 100.
                # mask = error_outputs_2d >= BfpConfig.error_threshold
                # outputs_2d[mask] = fp_outputs_2d[mask]

                # bfp_gemm.output_add.zero_()
                # output_add = bfp_gemm.output_add
                # lhs_zero_index = bfp_gemm.lhs_wrapper.zero_M_index
                # rhs_zero_index = bfp_gemm.rhs_wrapper.zero_M_index

                # cuda_lib.zero_indexed_gemm(
                #     c_void_p(im2col_inputs_2d.data_ptr()),
                #     c_void_p(lhs_zero_index.data_ptr()),
                #     c_void_p(weight_reshaped.data_ptr()),
                #     c_void_p(rhs_zero_index.data_ptr()),
                #     c_void_p(output_add.data_ptr()),
                #     c_int32(im2col_inputs_2d.shape[0]),
                #     c_int32(im2col_inputs_2d.shape[1]),
                #     c_int32(weight_reshaped.shape[0])
                # )
                
                # for m in range(bfp_gemm.output_shape[0]):
                #     for n in range(bfp_gemm.output_shape[1]):
                #         mask = lhs_zero_index[m] + rhs_zero_index[n]
                #         output_add[m,n] = torch.dot(im2col_inputs_2d[m][mask], weight_reshaped[n][mask])

                # outputs_2d += output_add

        else:
            raise ValueError(f"not supported precision flag: {precision_flag}")

        outputs_nhwc = outputs_2d.reshape(batch_size, out_width, out_width, out_channels)

        if intermediate_memory["fwd-output-nchw"] is None:
            intermediate_memory["fwd-output-nchw"] = torch.empty(
                size=(batch_size, out_channels, out_width, out_width),
                dtype=torch.float,
                device="cuda"
            )
        outputs_nchw = intermediate_memory["fwd-output-nchw"]
        custom_nhwc_to_nchw(dst=outputs_nchw, src=outputs_nhwc)

        if bias is not None:
            bias = bias.unsqueeze(1)
            bias = bias.unsqueeze(1)
            bias = bias.unsqueeze(0)
            outputs_nchw += bias.expand_as(outputs_nchw)

        return outputs_nchw

    @staticmethod
    def backward(ctx, grad_output_nchw):
        precision_flag = ctx.precision_flag
        in_width = ctx.in_width
        out_width = ctx.out_width
        stride = ctx.stride
        kernel_size = ctx.kernel_size
        padding = ctx.padding
        bfp_gemms = ctx.bfp_gemms
        col2im = ctx.col2im
        intermediate_memory = ctx.intermediate_memory
        id = ctx.id
        global_id = ctx.global_id
        prec_name = ctx.prec_name

        im2col_inputs_2d, weights, bias = ctx.saved_tensors
        grad_input = grad_weight = grad_bias = None

        B = grad_output_nchw.shape[0]
        C = grad_output_nchw.shape[1]
        H = grad_output_nchw.shape[2]
        W = grad_output_nchw.shape[3]
    
        if intermediate_memory["grad-output-nhwc"] is None:
            intermediate_memory["grad-output-nhwc"] = torch.empty(
                size=(B, H, W, C),
                dtype=torch.float,
                device="cuda"
            )
        grad_output_nhwc = intermediate_memory["grad-output-nhwc"]

        custom_nchw_to_nhwc(dst=grad_output_nhwc, src=grad_output_nchw)

        grad_output_nhwc_2d = grad_output_nhwc.reshape(B * H * W , -1)

        weights_2d = weights.reshape(C, -1)

        if ctx.needs_input_grad[0]:
            if precision_flag == PrecisionFlag.FP:
                grad_input_2d = grad_output_nhwc_2d.mm(weights_2d)

            elif precision_flag == PrecisionFlag.BFP:
                if intermediate_memory["grad-a-weight-2d-t"] is None:
                    intermediate_memory["grad-a-weight-2d-t"] = torch.empty(
                        size=(weights_2d.shape[1], weights_2d.shape[0]),
                        dtype=torch.float,
                        device="cuda"
                    )

                weights_2d_t = intermediate_memory["grad-a-weight-2d-t"]
                custom_transpose_2d(dst=weights_2d_t, src=weights_2d)
                
                if bfp_gemms["grad-a"] is None:
                    if BfpConfig.is_fast:
                        bfp_gemms["grad-a"] = FastBfpGemm(
                            grad_output_nhwc_2d.shape,
                            weights_2d_t.shape,
                            use_stochastic_rounding=BfpConfig.a_st,
                            use_flex_bfp=BfpConfig.use_flex_bfp,
                            layer_index=global_id,
                            name=f"conv2d-{id}-grad-a")
                    else:
                        bfp_gemms["grad-a"] = BfpGemm(
                            grad_output_nhwc_2d.shape,
                            weights_2d_t.shape,
                            use_stochastic_rounding=BfpConfig.a_st,
                            use_multi_exp=BfpConfig.use_multi_exp,
                            apply_thresholding=BfpConfig.a_thres,
                            threshold=BfpConfig.threshold)

                bfp_gemm = bfp_gemms["grad-a"]
                grad_input_2d = bfp_gemm.run(grad_output_nhwc_2d, weights_2d_t)

                # if BfpConfig.a_thres:
                    # fp_grad_input_2d = grad_output_nhwc_2d.mm(weights_2d)
                    # error_input_2d = torch.abs((fp_grad_input_2d - grad_input_2d) / (fp_grad_input_2d + 1e-15)) * 100.
                    # mask = error_input_2d >= BfpConfig.error_threshold
                    # grad_input_2d[mask] = fp_grad_input_2d[mask]

                    # bfp_gemm.output_add.zero_()
                    # output_add = bfp_gemm.output_add
                    # lhs_zero_index = bfp_gemm.lhs_wrapper.zero_M_index
                    # rhs_zero_index = bfp_gemm.rhs_wrapper.zero_M_index

                    # cuda_lib.zero_indexed_gemm(
                    #     c_void_p(grad_output_nhwc_2d.data_ptr()),
                    #     c_void_p(lhs_zero_index.data_ptr()),
                    #     c_void_p(weights_2d_t.data_ptr()),
                    #     c_void_p(rhs_zero_index.data_ptr()),
                    #     c_void_p(output_add.data_ptr()),
                    #     c_int32(grad_output_nhwc_2d.shape[0]),
                    #     c_int32(grad_output_nhwc_2d.shape[1]),
                    #     c_int32(weights_2d_t.shape[0])
                    # )
                    
                    # for m in range(bfp_gemm.output_shape[0]):
                    #     for n in range(bfp_gemm.output_shape[1]):
                    #         mask = lhs_zero_index[m] + rhs_zero_index[n]
                    #         output_add[m,n] = torch.dot(grad_output_nhwc_2d[m][mask], weights_2d_t[n][mask])

                    # grad_input_2d += output_add

            else:
                raise ValueError(f"not supported precision flag: {precision_flag}")

            if col2im is None:
                col2im = torch.nn.Fold(
                    output_size=in_width,
                    kernel_size=kernel_size,
                    padding=padding,
                    stride=stride
                )

            grad_input_3d = grad_input_2d.reshape(B, out_width * out_width, -1)
            if intermediate_memory["grad-input-3d-t"] is None:
                intermediate_memory["grad-input-3d-t"] = torch.empty(
                    size=(grad_input_3d.shape[0], grad_input_3d.shape[2], grad_input_3d.shape[1]),
                    dtype=torch.float,
                    device="cuda"
                )

            grad_input_3d_t = intermediate_memory["grad-input-3d-t"]
            custom_transpose_3d(dst=grad_input_3d_t, src=grad_input_3d)

            grad_input = col2im(grad_input_3d_t)

        if ctx.needs_input_grad[1]:
            if precision_flag == PrecisionFlag.FP:
                grad_weight = grad_output_nhwc_2d.t().mm(im2col_inputs_2d).reshape(weights.shape)

            elif precision_flag == PrecisionFlag.BFP:
                if intermediate_memory["grad-output-nhwc-2d-t"] is None:
                    intermediate_memory["grad-output-nhwc-2d-t"] = torch.empty(
                        size=(grad_output_nhwc_2d.shape[1], grad_output_nhwc_2d.shape[0]),
                        dtype=torch.float,
                        device="cuda"
                    )
                grad_output_nhwc_2d_t = intermediate_memory["grad-output-nhwc-2d-t"]
                custom_transpose_2d(dst=grad_output_nhwc_2d_t, src=grad_output_nhwc_2d)

                if intermediate_memory["im2col-inputs-2d-t"] is None:
                    intermediate_memory["im2col-inputs-2d-t"] = torch.empty(
                        size=(im2col_inputs_2d.shape[1], im2col_inputs_2d.shape[0]),
                        dtype=torch.float,
                        device="cuda"
                    )
                im2col_inputs_2d_t = intermediate_memory["im2col-inputs-2d-t"]
                custom_transpose_2d(dst=im2col_inputs_2d_t, src=im2col_inputs_2d)

                if bfp_gemms["grad-w"] is None:
                    if BfpConfig.is_fast:
                        bfp_gemms["grad-w"] = FastBfpGemm(
                            grad_output_nhwc_2d_t.shape,
                            im2col_inputs_2d_t.shape,
                            use_stochastic_rounding=BfpConfig.w_st,
                            use_flex_bfp=BfpConfig.use_flex_bfp,
                            layer_index=global_id,
                            name=f"conv2d-{id}-grad-w")
                    else:
                        bfp_gemms["grad-w"] = BfpGemm(
                            grad_output_nhwc_2d_t.shape,
                            im2col_inputs_2d_t.shape,
                            use_stochastic_rounding=BfpConfig.w_st,
                            use_multi_exp=BfpConfig.use_multi_exp,
                            apply_thresholding=BfpConfig.w_thres,
                            threshold=BfpConfig.threshold)

                bfp_gemm = bfp_gemms["grad-w"]
                grad_weight = bfp_gemm.run(grad_output_nhwc_2d_t, im2col_inputs_2d_t).reshape(weights.shape)

                # if BfpConfig.w_thres:
                    # fp_grad_weight = grad_output_nhwc_2d.t().mm(im2col_inputs_2d).reshape(weights.shape)
                    # error_grad_weight = torch.abs((fp_grad_weight - grad_weight) / (fp_grad_weight + 1e-15)) * 100.
                    # mask = error_grad_weight >= BfpConfig.error_threshold
                    # grad_weight[mask] = fp_grad_weight[mask]

                    # bfp_gemm.output_add.zero_()
                    # output_add = bfp_gemm.output_add
                    # lhs_zero_index = bfp_gemm.lhs_wrapper.zero_M_index
                    # rhs_zero_index = bfp_gemm.rhs_wrapper.zero_M_index

                    # cuda_lib.zero_indexed_gemm(
                    #     c_void_p(grad_output_nhwc_2d_t.data_ptr()),
                    #     c_void_p(lhs_zero_index.data_ptr()),
                    #     c_void_p(im2col_inputs_2d_t.data_ptr()),
                    #     c_void_p(rhs_zero_index.data_ptr()),
                    #     c_void_p(output_add.data_ptr()),
                    #     c_int32(grad_output_nhwc_2d_t.shape[0]),
                    #     c_int32(grad_output_nhwc_2d_t.shape[1]),
                    #     c_int32(im2col_inputs_2d_t.shape[0])
                    # )
                    
                    # for m in range(bfp_gemm.output_shape[0]):
                    #     for n in range(bfp_gemm.output_shape[1]):
                    #         mask = lhs_zero_index[m] + rhs_zero_index[n]
                    #         output_add[m,n] = torch.dot(grad_output_nhwc_2d_t[m][mask], im2col_inputs_2d_t[n][mask])

                    # grad_weight += output_add.reshape(weights.shape)

            else:
                raise ValueError(f"not supported precision flag: {precision_flag}")

        if bias is not None and ctx.needs_input_grad[2]:
            # grad_bias = grad_output.sum(0)
            grad_bias = grad_output_nhwc_2d.sum(0)

        return grad_input, grad_weight, grad_bias, \
            None, None, None, None, None, None, None, None, None, None, None, None


class CustomConv2d(nn.Module):
    current_id = 0

    def __init__(self, 
                 in_channels,
                 out_channels,
                 kernel_size,
                 stride,
                 padding,
                 bias,
                 precision_flag: PrecisionFlag,
                 global_id: int):
        super(CustomConv2d, self).__init__()

        self.id = CustomConv2d.current_id
        CustomConv2d.current_id += 1

        self.global_id = global_id

        self.in_channels = in_channels
        self.out_channels = out_channels
        self.kernel_size = kernel_size
        self.stride = stride
        self.padding = padding

        self.weight = nn.Parameter(torch.empty(self.out_channels,
                                               self.in_channels,
                                               self.kernel_size,
                                               self.kernel_size))

        if bias:
            self.bias = nn.Parameter(torch.empty(self.out_channels))
        else:
            self.register_parameter('bias', None)

        self.precision_flag = precision_flag

        self.bfp_gemms = {
            "fwd": None,
            "grad-w": None,
            "grad-a": None
        }

        self.im2col = torch.nn.Unfold(
            kernel_size=kernel_size,
            padding=padding,
            stride=stride
        )

        self.col2im = None

        self.intermediate_memory = {
            "im2col-inputs-2d": None,
            "fwd-output-nchw": None,
            "grad-output-nhwc": None,
            "grad-a-weight-2d-t": None,
            "grad-output-nhwc-2d-t": None,
            "im2col-inputs-2d-t": None,
            "grad-input-3d-t": None
        }

    def forward(self, inputs):
        if self.precision_flag == PrecisionFlag.FP or PrecisionFlag.BFP:
            return Conv2dFunction.apply(inputs, self.weight, self.bias, 
                                        self.in_channels, self.out_channels,
                                        self.kernel_size, 
                                        self.stride, 
                                        self.padding, 
                                        self.precision_flag,
                                        self.bfp_gemms,
                                        self.im2col,
                                        self.col2im,
                                        self.intermediate_memory,
                                        self.id,
                                        self.global_id)
        else:
            raise ValueError(f"not supported precision flag: {self.precision_flag}")


if __name__ == "__main__":
    set_reproducibility(1234)

    BfpConfig.group_size = 16
    BfpConfig.bfp_M_Bit = 8
    BfpConfig.use_flex_bfp = False

    BfpConfig.f_thres = True
    BfpConfig.a_thres = True
    BfpConfig.w_thres = True
    BfpConfig.threshold = 8

    batch_size = 1
    width = 224
    in_channels_list = [3, 64]
    out_channels_list = [64, 192]
    kernel_sizes = [11, 5]
    strides = [4, 1]
    padding = 2
    bias = True

    pool_kernel = 3
    pool_stride = 2

    max_val = 15
    min_val = -15

    conv2ds = nn.Sequential(OrderedDict([
        ("conv0", nn.Conv2d(in_channels_list[0], out_channels_list[0], kernel_size=kernel_sizes[0], stride=strides[0], bias=bias, padding=padding)),
        ("relu", nn.ReLU()),
        ("maxpool", nn.MaxPool2d(kernel_size=pool_kernel, stride=pool_stride)),
        ("conv1", nn.Conv2d(in_channels_list[1], out_channels_list[1], kernel_size=kernel_sizes[1], stride=strides[1], bias=bias, padding=padding))
    ]))

    with torch.no_grad():
        mask = torch.randint(low=-5, high=10, size=(conv2ds.conv0.weight.shape), dtype=torch.float) < 0
        conv2ds.conv0.weight[mask] *= 1e-5

        mask = torch.randint(low=-5, high=10, size=(conv2ds.conv1.weight.shape), dtype=torch.float) < 0
        conv2ds.conv1.weight[mask] *= 1e-5

    weights = [
        conv2ds.conv0.weight.data.clone().detach(),
        conv2ds.conv1.weight.data.clone().detach(),

        # torch.randint(low=min_val, high=max_val, size=conv2ds.conv0.weight.shape, dtype=torch.float),
        # torch.randint(low=min_val, high=max_val, size=conv2ds.conv1.weight.shape, dtype=torch.float),
    ]

    # print("weight0")
    # print(weights[0].cpu().numpy())
    # print("weight1")
    # print(weights[1].cpu().numpy())

    bias = [
        conv2ds.conv0.bias.data.clone().detach(),
        conv2ds.conv1.bias.data.clone().detach(),

        # torch.randint(low=min_val, high=max_val, size=(conv2ds.conv0.weight.shape[0],), dtype=torch.float),
        # torch.randint(low=min_val, high=max_val, size=(conv2ds.conv1.weight.shape[0],), dtype=torch.float)
    ]

    precision_flag = PrecisionFlag.BFP
    custom_conv2ds = nn.Sequential(OrderedDict([
        ("conv0", CustomConv2d(in_channels_list[0], out_channels_list[0], kernel_size=kernel_sizes[0], stride=strides[0], padding=padding, bias=bias, precision_flag=precision_flag, global_id=0)),
        ("relu", nn.ReLU()),
        ("maxpool", nn.MaxPool2d(kernel_size=pool_kernel, stride=pool_stride)),
        ("conv1", CustomConv2d(in_channels_list[1], out_channels_list[1], kernel_size=kernel_sizes[1], stride=strides[1], padding=padding, bias=bias, precision_flag=precision_flag, global_id=1))
    ]))

    for i in range(1):
        conv2ds.conv0.weight = nn.Parameter(weights[0].clone().detach())
        if bias:
            conv2ds.conv0.bias = nn.Parameter(bias[0].clone().detach())

        custom_conv2ds.conv0.weight = nn.Parameter(weights[0].clone().detach())
        if bias:
            custom_conv2ds.conv0.bias = nn.Parameter(bias[0].clone().detach())

        conv2ds.conv1.weight = nn.Parameter(weights[1].clone().detach())
        if bias:
            conv2ds.conv1.bias = nn.Parameter(bias[1].clone().detach())

        custom_conv2ds.conv1.weight = nn.Parameter(weights[1].clone().detach())
        if bias:
            custom_conv2ds.conv1.bias = nn.Parameter(bias[1].clone().detach())

    models = [conv2ds.to("cuda"), custom_conv2ds.to("cuda")]
    criterions = [nn.CrossEntropyLoss().to("cuda") for _ in models]
    optimizers = [torch.optim.SGD(model.parameters(), lr=1.0) for model in models]

    scale = 0.001
    iterations = 1

    ns_etts = [0, 0]

    for iteration in range(iterations):

        # inputs = torch.randint(low=min_val, high=max_val, size=(batch_size, in_channels_list[0], width, width), dtype=torch.float).to("cuda")
        # print("input")
        # print(inputs.cpu().numpy())

        inputs = torch.randn(batch_size, in_channels_list[0], width, width).to("cuda") * scale


        # targets = torch.randint(low=min_val, high=max_val, size=(batch_size, out_channels_list[1], 3, 3), dtype=torch.float).to("cuda")
        targets = torch.randn(batch_size, out_channels_list[1], 27, 27).to("cuda")

        # targets = torch.randint(low=-5, high=5, size=(batch_size, out_channels_list[1], width, width), dtype=torch.float)
        # targets = torch.randn(batch_size, out_channels_list[1], width, width)

        # for model in models:
        #     model = model.to('cuda')

        # for criterion in criterions:
        #     criterion = criterion.to('cuda')

        # inputs = inputs.to('cuda')
        # targets = targets.to('cuda')

        outputs_list = []

        for i in range(len(models)):
            print([f"[MODEL {i}]"])
            
            start = time.time_ns()
            outputs = models[i](inputs)
            # print(f"{outputs.shape}")
            # print(f"{outputs.cpu().clone().detach().numpy()}")

            outputs_list.append(outputs.clone().detach())

            # loss = torch.sum(torch.abs(outputs - targets))
            # loss = torch.sum(torch.abs(outputs - targets))
            loss = torch.sum(torch.abs(outputs - targets))
            print(f"loss: {loss}")
            # loss = torch.sum(torch.abs(outputs - outputs))
            # loss = criterions[i](outputs, targets)

            optimizers[i].zero_grad()
            loss.backward()
            optimizers[i].step()
            end = time.time_ns()

            if iteration > 0:
                ns_etts[i] += (end - start)

        

        diff = torch.abs(outputs_list[0].flatten() - outputs_list[1].flatten())
        print(f"fwd output mean diff:  {torch.mean(diff):.10f}")
        # print(f"fwd output sum diff: {torch.sum(diff):.10f}")

        diff = torch.abs(conv2ds.conv0.weight.flatten() - custom_conv2ds.conv0.weight.flatten())
        print(f"fwd weight0 mean diff: {torch.mean(diff):.10f}")
        # print(f"weight0 sum diff: {torch.sum(diff):.10f}")

        diff = torch.abs(conv2ds.conv1.weight.flatten() - custom_conv2ds.conv1.weight.flatten())
        print(f"fwd weight1 mean diff: {torch.mean(diff):.10f}")
        # print(f"weight1 sum diff: {torch.sum(diff):.10f}")

    # print(f"[ett]")
    # print(f"torch  : {ns_etts[0] / 100 / 1000_000}ms")
    # print(f"custom : {ns_etts[1] / 100 / 1000_000}ms")
