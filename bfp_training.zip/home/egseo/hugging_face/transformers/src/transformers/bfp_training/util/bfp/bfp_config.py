class BfpConfig:
    use_bfp = False
    # use_bfp = True
    use_flex_bfp = False
    use_multi_exp = False
    group_size = 16
    # bfp_M_Bit = 8
    bfp_M_Bit = 16
    thread_num = 16
    is_fast = False

    f_st = False
    a_st = True 
    w_st = True

    # f_thres = False
    # a_thres = True
    # w_thres = True
    # threshold = None
    f_thres = False
    a_thres = False
    w_thres = False
    threshold = 1e+6


class PrecisionFlag:
    FP = 0
    BFP = 1
