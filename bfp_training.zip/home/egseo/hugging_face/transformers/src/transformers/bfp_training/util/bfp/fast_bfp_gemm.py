import numpy as np
import sys
import torch
import time
from ctypes import *

# if "/home/yskim/projects/sparse-bfp" not in sys.path:
#     sys.path.append("/home/yskim/projects/sparse-bfp")

from util.bfp.bfp_config import BfpConfig
from util.reprod_util import set_reproducibility
from util.custom_transpose import custom_transpose_2d
from util.bfp.cuda_bfp_wrapper import CudaBfpWrapper
from util.bfp.cuda.cuda_memory_helper import CudaFloatStorage

import os
BFP_HOME = os.environ["BFP_HOME"]
# cuda_sort_lib = CDLL(f"{BFP_HOME}/util/bfp/cuda/lib_sorted_gemm_cuda.so")
cuda_lib = CDLL(f"{BFP_HOME}/util/bfp/cuda/lib_not_sorted_gemm_cuda.so")
# cuda_bit_level_lib = CDLL(f"{BFP_HOME}/util/bfp/cuda/lib_bit_level_gemm_cuda.so")


class FastBfpGemm:
    alpha = 7.
    beta = 3.5
    total_layers = 1
    total_iterations = 1

    def __init__(
        self, lhs_shape: torch.Size, 
        rhs_shape: torch.Size, 
        use_stochastic_rounding: bool, 
        use_flex_bfp: bool,
        layer_index: int,
        name: str
        ):
        self.device = "cuda"

        self.use_flex_bfp = use_flex_bfp

        self.lhs_wrapper = CudaBfpWrapper(
            fp_tensor_shape=lhs_shape, 
            use_multi_exp=False)
        self.rhs_wrapper = CudaBfpWrapper(
            fp_tensor_shape=rhs_shape, 
            use_multi_exp=False)

        self.output = torch.zeros(
            size=(lhs_shape[0], rhs_shape[0]),
            dtype=torch.float,
            device=self.device)

        self.use_stochastic_rounding = use_stochastic_rounding


        self.layer_index = layer_index

        self.name = name

        self.lhs_bit_log = []
        self.rhs_bit_log = []

    def run(self, lhs: torch.Tensor, rhs: torch.Tensor):
        # relative improvement
        self.lhs_wrapper.bfp_M_bit = 4
        self.rhs_wrapper.bfp_M_bit = 4

        self.lhs_wrapper.run_convert_fp_to_bfp(src_tensor=lhs, is_stochastic_rounding=self.use_stochastic_rounding)
        self.rhs_wrapper.run_convert_fp_to_bfp(src_tensor=rhs, is_stochastic_rounding=self.use_stochastic_rounding)

        lhs_4bit = self.lhs_wrapper.bfp_S * self.lhs_wrapper.bfp_M
        rhs_4bit = self.rhs_wrapper.bfp_S * self.rhs_wrapper.bfp_M

        # relative improvement
        self.lhs_wrapper.bfp_M_bit = 2
        self.rhs_wrapper.bfp_M_bit = 2

        self.lhs_wrapper.run_convert_fp_to_bfp(src_tensor=lhs, is_stochastic_rounding=self.use_stochastic_rounding)
        self.rhs_wrapper.run_convert_fp_to_bfp(src_tensor=rhs, is_stochastic_rounding=self.use_stochastic_rounding)

        lhs_2bit = self.lhs_wrapper.bfp_S * self.lhs_wrapper.bfp_M
        rhs_2bit = self.rhs_wrapper.bfp_S * self.rhs_wrapper.bfp_M

        lhs_ri  = torch.sum(torch.abs(lhs_4bit - lhs_2bit)) / torch.sum(torch.abs(lhs_2bit))
        rhs_ri  = torch.sum(torch.abs(rhs_4bit - rhs_2bit)) / torch.sum(torch.abs(rhs_2bit))

        # print(f"lhs ri: {lhs_ri}")
        # print(f"rhs ri: {rhs_ri}")

        threshold = FastBfpGemm.alpha - FastBfpGemm.beta * ((BfpConfig.curr_iteration / FastBfpGemm.total_iterations) + (self.layer_index / FastBfpGemm.total_layers))
        # print(f"thres: {threshold}")

        if lhs_ri >= threshold:
            self.lhs_wrapper.bfp_M_bit = 4
            self.lhs_wrapper.run_convert_fp_to_bfp(src_tensor=lhs, is_stochastic_rounding=self.use_stochastic_rounding)

        if rhs_ri >= threshold:
            self.rhs_wrapper.bfp_M_bit = 4
            self.rhs_wrapper.run_convert_fp_to_bfp(src_tensor=rhs, is_stochastic_rounding=self.use_stochastic_rounding)

        if self.lhs_wrapper.bfp_M.shape[1] != self.rhs_wrapper.bfp_M.shape[1]:
            raise ValueError(f"cannot matched dim: {self.lhs_wrapper.bfp_M.shape} x {self.rhs_wrapper.bfp_M.shape}")

        M = self.lhs_wrapper.bfp_M.shape[0]
        K = self.lhs_wrapper.bfp_M.shape[1]
        N = self.rhs_wrapper.bfp_M.shape[0]
        bfp_M_bit = BfpConfig.bfp_M_Bit
        group_size = BfpConfig.group_size

        # print(f"l: {self.layer_index}, L: {FastBfpGemm.total_layers} / i: {BfpConfig.curr_iteration}, I: {FastBfpGemm.total_iterations} / lhs: {self.lhs_wrapper.bfp_M_bit}, rhs: {self.rhs_wrapper.bfp_M_bit}")

        self.lhs_bit_log.append(self.lhs_wrapper.bfp_M_bit)
        self.rhs_bit_log.append(self.rhs_wrapper.bfp_M_bit)

        cuda_lib.bfp_gemm_2d(
            c_void_p(self.lhs_wrapper.bfp_S.data_ptr()),
            c_void_p(self.lhs_wrapper.bfp_E.data_ptr()),
            c_void_p(self.lhs_wrapper.bfp_M.data_ptr()),
            # c_void_p(self.lhs_wrapper.bfp_bit_level.data_ptr()),


            c_void_p(self.rhs_wrapper.bfp_S.data_ptr()),
            c_void_p(self.rhs_wrapper.bfp_E.data_ptr()),
            c_void_p(self.rhs_wrapper.bfp_M.data_ptr()),
            # c_void_p(self.rhs_wrapper.bfp_bit_level.data_ptr()),

            c_void_p(self.output.data_ptr()),

            c_int32(M),
            c_int32(K),
            c_int32(N),

            c_int32(group_size),
            c_int32(self.lhs_wrapper.bfp_M_bit),
            c_int32(self.rhs_wrapper.bfp_M_bit)
        )

        return self.output

    def save_bits(self, path, epoch):
        np.save(f"{path}/epoch-{epoch}-{self.name}-lhs-bit.npy", self.lhs_bit_log, allow_pickle=False)
        self.lhs_bit_log = []

        np.save(f"{path}/epoch-{epoch}-{self.name}-rhs-bit.npy", self.rhs_bit_log, allow_pickle=False)
        self.rhs_bit_log = []

def load_inout(path_root, phase, layer_index, n_index, k_cnt, m_index):
    path = f"{path_root}/{phase}-{layer_index}-fp"

    lhs = np.load(f"{path}-lhs.npy", allow_pickle=False)
    rhs = np.load(f"{path}-rhs.npy", allow_pickle=False)
    output = np.matmul(lhs, rhs)
    # print(f"lhs: {lhs.shape} X rhs: {rhs.shape} = output: {output.shape}")
    
    # lhs = lhs[n_index,0:k_cnt]
    # rhs = rhs[0:k_cnt,m_index]
    # output = np.dot(lhs, rhs)
    # print(f"lhs: {lhs.shape} X rhs: {rhs.shape} = output: {output.shape}")

    return lhs, rhs, output

if __name__ == "__main__":
    set_reproducibility(1234)
    BfpConfig.group_size = 16 # 1
    BfpConfig.bfp_M_Bit = 8
    use_flex_bfp = False
    use_SR = True
    # BfpConfig.chunk_size_to_sort = 256

    log_path = "/home/yskim/projects/sparse-bfp/resnet50-inout-log/epoch0-lr0.001"
    lhs, rhs, output = load_inout(log_path, "fwd", 3, 32, 0, 34)
    print(lhs.shape)
    print(rhs.shape)

    # return

    M = lhs.shape[0] # 1024 # 1
    K = lhs.shape[1] # 2024 * 4 # 2
    N = rhs.shape[1] # 1024 # 1
    print(f"dims: [{M}, {K}] x [{K}, {N}]")
    # print(f"bfp m bits: {BfpConfig.bfp_M_Bit}")

    # if should_sort:
    #     print(f"bfp m bits: {BfpConfig.bfp_M_Bit}")
    #     # print(f"sort size: {BfpConfig.chunk_size_to_sort}")
    # else:
    #     print("dynamic precision")
    #     # print("not sort")

    # scale = 1 # 0.001
    lhs = torch.tensor(lhs, dtype=torch.float32) # torch.randn((M, K), dtype=torch.float32) * scale
    # lhs = torch.randn((M, K), dtype=torch.float32) * scale
    # lhs = torch.randint(low=-25, high=25, size=(M, K), dtype=torch.float32)
    lhs = lhs.to('cuda')

    rhs = torch.tensor(rhs, dtype=torch.float32) # torch.randn((K, N), dtype=torch.float32) * scale
    # rhs = torch.randn((K, N), dtype=torch.float32) * scale
    rhs = rhs.to('cuda')
    # rhs = torch.randint(low=-25, high=25, size=(K, N), dtype=torch.float32)
    rhs_t = torch.empty((N, K), dtype=torch.float).to('cuda')

    custom_transpose_2d(dst=rhs_t, src=rhs)
    
    bfp_gemm = FastBfpGemm(
        lhs.shape, 
        rhs_t.shape, 
        use_stochastic_rounding=use_SR, 
        use_flex_bfp=use_flex_bfp)

    FastBfpGemm.total_layers = 52
    FastBfpGemm.total_iterations = 100
    bfp_gemm.layer_index = 51

    # change bfp precision manually
    bfp_gemm.lhs_wrapper.bfp_M_bit = 4
    bfp_gemm.rhs_wrapper.bfp_M_bit = 4

    print(f"lhs: {bfp_gemm.lhs_wrapper.bfp_M_bit}-bit, rhs: {bfp_gemm.rhs_wrapper.bfp_M_bit}-bit")

    outputs_cuda = bfp_gemm.run(lhs, rhs_t)

    # print(outputs_cuda.cpu().numpy())

    start = time.time_ns()
    # for i in range(1):
        # outputs_cuda = bfp_gemm.run(lhs, rhs_t)
    end = time.time_ns()

    print(f"exec time: {((end - start) / 10 / 1000_000):.3f}ms")

    fp_outputs = torch.matmul(lhs, rhs)

    # diff = torch.abs(fp_outputs.flatten() - outputs.flatten())
    diff_cuda = torch.abs(fp_outputs.flatten() - outputs_cuda.flatten())

    if use_flex_bfp:
        print(f"lhs bits: {torch.mean(bfp_gemm.lhs_wrapper.bfp_bit_level.type(torch.float))}")
        print(f"rhs bits: {torch.mean(bfp_gemm.rhs_wrapper.bfp_bit_level.type(torch.float))}")

    # print(f"[diff not sorted]\nmean: {torch.mean(diff):.10f}\nmax: {torch.max(diff):.10f}\nmin: {torch.min(diff):.10f}")
    print(f"[diffs]\nmean: {torch.mean(diff_cuda):.10f}\nmax: {torch.max(diff_cuda):.10f}\nmin: {torch.min(diff_cuda):.10f}")