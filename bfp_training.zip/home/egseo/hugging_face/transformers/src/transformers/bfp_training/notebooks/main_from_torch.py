import argparse
import os
import random
from re import L
import shutil
import time
import warnings
from enum import Enum

import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.nn.parallel
import torch.backends.cudnn as cudnn
import torch.distributed as dist
import torch.optim
from torch.optim.lr_scheduler import StepLR
import torch.multiprocessing as mp
import torch.utils.data
import torch.utils.data.distributed
import torchvision.transforms as transforms
import torchvision.datasets as datasets
import torchvision.models as models

from torch.utils.tensorboard import SummaryWriter

import sys
from util.bfp.fast_bfp_gemm import FastBfpGemm
from util.data_load import DL_TYPE_CIFAR_10, DL_TYPE_CIFAR_100, DL_TYPE_IMAGENET, generate_data_loaders
from util.reprod_util import set_reproducibility

from util.bfp.bfp_config import BfpConfig, PrecisionFlag

from util.custom_linear import CustomLinear
from util.custom_conv2d import CustomConv2d


model_names = sorted(name for name in models.__dict__
    if name.islower() and not name.startswith("__")
    and callable(models.__dict__[name]))
model_names.append("sample-nn")

parser = argparse.ArgumentParser(description='PyTorch ImageNet Training')
# parser.add_argument('data', metavar='DIR', default='imagenet',
#                     help='path to dataset (default: imagenet)')
parser.add_argument('-a', '--arch', metavar='ARCH', default='resnet18',
                    choices=model_names,
                    help='model architecture: ' +
                        ' | '.join(model_names) +
                        ' (default: resnet18)')
parser.add_argument('-j', '--workers', default=4, type=int, metavar='N',
                    help='number of data loading workers (default: 4)')
parser.add_argument('--epochs', default=90, type=int, metavar='N',
                    help='number of total epochs to run')
parser.add_argument('--start-epoch', default=0, type=int, metavar='N',
                    help='manual epoch number (useful on restarts)')
parser.add_argument('-b', '--batch-size', default=256, type=int,
                    metavar='N',
                    help='mini-batch size (default: 256), this is the total '
                         'batch size of all GPUs on the current node when '
                         'using Data Parallel or Distributed Data Parallel')
parser.add_argument('--lr', '--learning-rate', default=0.1, type=float,
                    metavar='LR', help='initial learning rate', dest='lr')
parser.add_argument('--momentum', default=0.9, type=float, metavar='M',
                    help='momentum')
parser.add_argument('--wd', '--weight-decay', default=1e-4, type=float,
                    metavar='W', help='weight decay (default: 1e-4)',
                    dest='weight_decay')
parser.add_argument('-p', '--print-freq', default=10, type=int,
                    metavar='N', help='print frequency (default: 10)')
parser.add_argument('--resume', default='', type=str, metavar='PATH',
                    help='path to latest checkpoint (default: none)')
parser.add_argument('-e', '--evaluate', dest='evaluate', action='store_true',
                    help='evaluate model on validation set')
parser.add_argument('--pretrained', dest='pretrained', action='store_true',
                    help='use pre-trained model')
parser.add_argument('--world-size', default=-1, type=int,
                    help='number of nodes for distributed training')
parser.add_argument('--rank', default=-1, type=int,
                    help='node rank for distributed training')
parser.add_argument('--dist-url', default='tcp://224.66.41.62:23456', type=str,
                    help='url used to set up distributed training')
parser.add_argument('--dist-backend', default='nccl', type=str,
                    help='distributed backend')
parser.add_argument('--seed', default=None, type=int,
                    help='seed for initializing training. ')
parser.add_argument('--gpu', default=None, type=int,
                    help='GPU id to use.')
parser.add_argument('--multiprocessing-distributed', action='store_true',
                    help='Use multi-processing distributed training to launch '
                         'N processes per node, which has N GPUs. This is the '
                         'fastest way to use PyTorch for either single node or '
                         'multi node data parallel training')

parser.add_argument('--use-bfp', action='store_true',
                    help='use BFP format otherwise FP32')
parser.add_argument('--bfp-m-bits', default=None, type=int,
                    help='set BFP mantissa bits')
parser.add_argument('--dataset-type', default=None, type=int,
                    help='type of dataset (0: CIFAR-10, 1: CIFAR-100, 2: ImageNet)')
parser.add_argument('--num-classes', default=None, type=int,
                    help='number of class labels')
parser.add_argument('--initial-weights-path', default=None, type=str,
                    help='path of initial weights')

parser.add_argument('--use-flex-bfp', action='store_true',
                    help='use Flex BFP')

parser.add_argument('--is-fast', action='store_true',
                    help='FAST like thresholding')

parser.add_argument('--test-iteration', default=None, type=int,
                    help='set number of iterations to test')

parser.add_argument('--error-thres', default=None, type=float,
                    help='set error threshold')


parser.add_argument('--thres-f', action='store_true',
                    help='turn on error thresholding to forwarding')
parser.add_argument('--threshold', type=int,
                    help='threshold value to make mantissa zero')
parser.add_argument('--no-thres-w', action='store_false',
                    help='turn off error thresholding to back-propagation weight')
parser.add_argument('--no-thres-a', action='store_false',
                    help='turn off error thresholding to back-propagation activation')

parser.add_argument('--use-multi-exp', action='store_true',
                    help='use multi exponent BFP')

parser.add_argument('--group-size', type=int,
                    help='size of a single BFP group')

best_acc1 = 0
best_acc5 = 0
layer_cnt = 0

BFP_HOME = os.environ["BFP_HOME"]

#####################################################################################
#***********************************************************************************#


def get_project_name(args):
    if args.use_bfp and args.bfp_m_bits is None:
        raise ValueError(f"in BFP training, mantissa bits must be set")

    arch = args.arch
    data_format = f"bfp-m{args.bfp_m_bits}" if args.use_bfp else "fp32"

    model_info = f"{arch}-{data_format}"

    momentum = f"m{args.momentum}"
    weight_decay = f"wd{args.weight_decay}"
    lr = f"lr{args.lr}"
    sgd_info = f"sgd-{lr}-{weight_decay}-{momentum}"
    # adam_info = f"adam-{lr}-{weight_decay}"

    if args.dataset_type == DL_TYPE_CIFAR_10:
        dataset_type = "cifar10"
    elif args.dataset_type == DL_TYPE_CIFAR_100:
        dataset_type = "cifar100"
    elif args.dataset_type == DL_TYPE_IMAGENET:
        dataset_type = "imagenet"
    else:
        raise ValueError(f"not supported dataset: {args.dataset_type}")
    batch_size = f"global_batch{args.batch_size}"
    is_dist = "multi_gpus" if args.multiprocessing_distributed else "single_gpu"
    dataset_info = f"{dataset_type}-{batch_size}-{is_dist}"

    if args.seed is None:
        seed_info = "no_seed"
    else:
        seed_info = f"seed{args.seed}"


    if args.use_bfp:
        if args.use_flex_bfp and args.is_fast:
            raise ValueError("options Flex BFP and FAST cannot be set at the same time")

    if args.use_flex_bfp:
        bfp_info = "-flex-bfp"
    elif args.is_fast:
        bfp_info = "-fast"
    else:
        bfp_info = ""

    if args.test_iteration is not None:
        test_iter_info = f"test_iter_{args.test_iteration}-"
    else:
        test_iter_info = ""

    st_info = f"st_{'f' if BfpConfig.f_st else ''}{'w' if BfpConfig.w_st else ''}{'a' if BfpConfig.a_st else ''}"

    if not args.use_bfp:
        st_info = "no_st"

    if args.thres_f is not None and args.thres_f == True:
        BfpConfig.f_thres = True

    if args.no_thres_w is not None and args.no_thres_w == False:
        BfpConfig.w_thres = False

    if args.no_thres_a is not None and args.no_thres_a == False:
        BfpConfig.a_thres = False

    thres_info = f"thres_{'f' if BfpConfig.f_thres else ''}{'w' if BfpConfig.w_thres else ''}{'a' if BfpConfig.a_thres else ''}{BfpConfig.threshold}"

    if (BfpConfig.f_thres == False and BfpConfig.w_thres == False and BfpConfig.a_thres == False) or not args.use_bfp:
        thres_info = "no_thres"

    if BfpConfig.use_multi_exp:
        multi_exp_info = "multi_exp-"
    else:
        multi_exp_info = ""

    group_size = args.group_size

    return f"{multi_exp_info}{st_info}-{thres_info}-{test_iter_info}{model_info}-{sgd_info}-{dataset_info}-{seed_info}{bfp_info}-g{group_size}-step30-epochs{args.epochs}"

def wrap_modules(module, precision_flag: PrecisionFlag):
    global layer_cnt

    for name, _ in module.named_children():
        child = getattr(module, name)
        child_cnt = 0
        for _ in child.children():
            child_cnt += 1

        if child_cnt == 0:
            layer = getattr(module, name)
            for _, param in layer.named_parameters():
                if param.requires_grad:
                    pass

            if "Linear" in str(layer):
                layer_cnt += 1

                custom_layer = CustomLinear(input_features=layer.in_features, 
                                            output_features=layer.out_features, 
                                            bias=True if layer.bias is not None else False, 
                                            precision_flag=precision_flag,
                                            global_id=layer_cnt)
                custom_layer.weight = nn.Parameter(layer.weight.data.clone().detach())
                if layer.bias is not None:
                    custom_layer.bias = nn.Parameter(layer.bias.data.clone().detach())
                setattr(module, name, custom_layer)
            elif "Conv" in str(layer):
                layer_cnt += 1

                custom_layer = CustomConv2d(in_channels=layer.in_channels,
                                            out_channels=layer.out_channels,
                                            kernel_size=layer.kernel_size[0],
                                            stride=layer.stride[0],
                                            padding=layer.padding[0],
                                            bias=True if layer.bias is not None else False,
                                            precision_flag=precision_flag,
                                            global_id=layer_cnt)
                custom_layer.weight = nn.Parameter(layer.weight.data.clone().detach())
                if layer.bias is not None:
                    custom_layer.bias = nn.Parameter(layer.bias.data.clone().detach())
                setattr(module, name, custom_layer)
        else:
            wrap_modules(child, precision_flag)


def save_bits(module, path, epoch):
    for name, _ in module.named_children():
        child = getattr(module, name)
        child_cnt = 0
        for _ in child.children():
            child_cnt += 1

        layer = getattr(module, name)

        if isinstance(layer, CustomLinear) or isinstance(layer, CustomConv2d):
                layer.bfp_gemms["fwd"].save_bits(path, epoch)

                if layer.bfp_gemms["grad-a"] is not None:
                    layer.bfp_gemms["grad-a"].save_bits(path, epoch)

                layer.bfp_gemms["grad-w"].save_bits(path, epoch)

        if child_cnt != 0:
            save_bits(child, path, epoch)

#***********************************************************************************#
#####################################################################################


def main():
    args = parser.parse_args()

    if args.threshold is not None:
        BfpConfig.threshold = args.threshold

    if args.use_multi_exp:
        BfpConfig.use_multi_exp = True

    project_name = get_project_name(args)

    project_path = os.path.join(f"{BFP_HOME}/train-log", project_name)
    # exit()

    if args.seed is not None:
        set_reproducibility(args.seed)
        warnings.warn('You have chosen to seed training. '
                      'This will turn on the CUDNN deterministic setting, '
                      'which can slow down your training considerably! '
                      'You may see unexpected behavior when restarting '
                      'from checkpoints.')

    if args.gpu is not None:
        warnings.warn('You have chosen a specific GPU. This will completely '
                      'disable data parallelism.')

    if args.dist_url == "env://" and args.world_size == -1:
        args.world_size = int(os.environ["WORLD_SIZE"])

    args.distributed = args.world_size > 1 or args.multiprocessing_distributed

    ngpus_per_node = torch.cuda.device_count()
    if args.multiprocessing_distributed:
        # Since we have ngpus_per_node processes per node, the total world_size
        # needs to be adjusted accordingly
        args.world_size = ngpus_per_node * args.world_size
        # Use torch.multiprocessing.spawn to launch distributed processes: the
        # main_worker process function
        mp.spawn(main_worker, nprocs=ngpus_per_node, args=(ngpus_per_node, args, project_path))
    else:
        # Simply call main_worker function
        main_worker(args.gpu, ngpus_per_node, args, project_path)


def main_worker(gpu, ngpus_per_node, args, project_path):
    if args.seed is not None:
        # pass
        set_reproducibility(args.seed)

    if args.threshold is not None:
        BfpConfig.threshold = args.threshold

    if args.use_multi_exp:
        BfpConfig.use_multi_exp = True
        print("use multi exponent BFP")

    if args.thres_f is not None and args.thres_f == True:
        BfpConfig.f_thres = True

    if args.no_thres_w is not None and args.no_thres_w == False:
        BfpConfig.w_thres = False

    if args.no_thres_a is not None and args.no_thres_a == False:
        BfpConfig.a_thres = False

    BfpConfig.group_size = args.group_size

    global best_acc1
    global best_acc5
    args.gpu = gpu

    if args.gpu is not None:
        print("Use GPU: {} for training".format(args.gpu))

    if args.distributed:
        if args.dist_url == "env://" and args.rank == -1:
            args.rank = int(os.environ["RANK"])
        if args.multiprocessing_distributed:
            # For multiprocessing distributed training, rank needs to be the
            # global rank among all the processes
            args.rank = args.rank * ngpus_per_node + gpu
        dist.init_process_group(backend=args.dist_backend, init_method=args.dist_url,
                                world_size=args.world_size, rank=args.rank)
    # create model
    if args.pretrained:
        print("=> using pre-trained model '{}'".format(args.arch))
        model = models.__dict__[args.arch](pretrained=True)
    else:
        print("=> creating model '{}'".format(args.arch))
        model = models.__dict__[args.arch](num_classes=args.num_classes)

        if args.initial_weights_path is not None:
            print(f"load initial weights for {args.arch} at {args.initial_weights_path}")
            model.load_state_dict(torch.load(
                args.initial_weights_path
            )["state_dict"])

    if args.use_bfp:
        print("enable BFP format")
        BfpConfig.bfp_M_Bit = args.bfp_m_bits

        if args.use_flex_bfp:
            print("enable Flex BFP")
            BfpConfig.use_flex_bfp = True

        if args.is_fast:
            print("enable FAST")

        wrap_modules(model, precision_flag=PrecisionFlag.BFP)
    else:
        wrap_modules(model, precision_flag=PrecisionFlag.FP)

    if not torch.cuda.is_available():
        print('using CPU, this will be slow')
    elif args.distributed:
        # For multiprocessing distributed, DistributedDataParallel constructor
        # should always set the single device scope, otherwise,
        # DistributedDataParallel will use all available devices.
        if args.gpu is not None:
            torch.cuda.set_device(args.gpu)
            model.cuda(args.gpu)
            # When using a single GPU per process and per
            # DistributedDataParallel, we need to divide the batch size
            # ourselves based on the total number of GPUs of the current node.
            args.batch_size = int(args.batch_size / ngpus_per_node)
            args.workers = int((args.workers + ngpus_per_node - 1) / ngpus_per_node)
            model = torch.nn.parallel.DistributedDataParallel(model, device_ids=[args.gpu])
        else:
            model.cuda()
            # DistributedDataParallel will divide and allocate batch_size to all
            # available GPUs if device_ids are not set
            model = torch.nn.parallel.DistributedDataParallel(model)
    elif args.gpu is not None:
        torch.cuda.set_device(args.gpu)
        model = model.cuda(args.gpu)
    else:
        # DataParallel will divide and allocate batch_size to all available GPUs
        if args.arch.startswith('alexnet') or args.arch.startswith('vgg'):
            model.features = torch.nn.DataParallel(model.features)
            model.cuda()
        else:
            model = torch.nn.DataParallel(model).cuda()

    # define loss function (criterion), optimizer, and learning rate scheduler
    criterion = nn.CrossEntropyLoss().cuda(args.gpu)

    optimizer = torch.optim.SGD(model.parameters(), 
                                lr=args.lr,
                                momentum=args.momentum,
                                weight_decay=args.weight_decay)
    
    """Sets the learning rate to the initial LR decayed by 10 every 30 epochs"""
    scheduler = StepLR(optimizer, step_size=30, gamma=0.1)
    
    # optionally resume from a checkpoint
    if args.resume:
        if os.path.isfile(args.resume):
            print("=> loading checkpoint '{}'".format(args.resume))
            if args.gpu is None:
                checkpoint = torch.load(args.resume)
            else:
                # Map model to be loaded to specified single gpu.
                loc = 'cuda:{}'.format(args.gpu)
                checkpoint = torch.load(args.resume, map_location=loc)
            args.start_epoch = checkpoint['epoch'] + 1
            best_acc1 = checkpoint['best_acc1']
            best_acc5 = checkpoint['best_acc5']
            if args.gpu is not None:
                # best_acc1 may be from a checkpoint from a different GPU
                best_acc1 = best_acc1.to(args.gpu)
                best_acc5 = best_acc5.to(args.gpu)
            model.load_state_dict(checkpoint['state_dict'])
            optimizer.load_state_dict(checkpoint['optimizer'])
            scheduler.load_state_dict(checkpoint['scheduler'])
            print("=> loaded checkpoint '{}' (epoch {})"
                  .format(args.resume, checkpoint['epoch']))
        else:
            print("=> no checkpoint found at '{}'".format(args.resume))

    cudnn.benchmark = True

    # Data loading code
    # traindir = os.path.join(args.data, 'train')
    # valdir = os.path.join(args.data, 'val')
    # normalize = transforms.Normalize(mean=[0.485, 0.456, 0.406],
    #                                  std=[0.229, 0.224, 0.225])

    # train_dataset = datasets.ImageFolder(
    #     traindir,
    #     transforms.Compose([
    #         transforms.RandomResizedCrop(224),
    #         transforms.RandomHorizontalFlip(),
    #         transforms.ToTensor(),
    #         normalize,
    #     ]))

    # if args.distributed:
    #     train_sampler = torch.utils.data.distributed.DistributedSampler(train_dataset)
    # else:
    #     train_sampler = None

    train_loader, val_loader, train_dist_sampler = generate_data_loaders(
        type=args.dataset_type,
        batch_size=args.batch_size,
        num_workers=args.workers,
        is_distributed=args.distributed)

    train_iterations = len(train_loader)
    print(f"train iterations: {train_iterations} / batch size: {args.batch_size}")
    print(f"layer cnt: {layer_cnt}")

    if args.is_fast:
        FastBfpGemm.total_iterations = train_iterations
        FastBfpGemm.total_layers = layer_cnt
        BfpConfig.is_fast = True

    # train_loader = torch.utils.data.DataLoader(
    #     train_dataset, batch_size=args.batch_size, shuffle=(train_sampler is None),
    #     num_workers=args.workers, pin_memory=True, sampler=train_sampler)

    # val_loader = torch.utils.data.DataLoader(
    #     datasets.ImageFolder(valdir, transforms.Compose([
    #         transforms.Resize(256),
    #         transforms.CenterCrop(224),
    #         transforms.ToTensor(),
    #         normalize,
    #     ])),
    #     batch_size=args.batch_size, shuffle=False,
    #     num_workers=args.workers, pin_memory=True)

    if args.evaluate:
        validate(val_loader, model, criterion, args)
        return

    is_dist = args.multiprocessing_distributed
    dist_but_rank_0 = args.multiprocessing_distributed and args.rank % ngpus_per_node == 0

    if not is_dist or dist_but_rank_0:
        writer = SummaryWriter(os.path.join(project_path, "tensorboard"))

    for epoch in range(args.start_epoch, args.epochs):
        if args.distributed:
            train_dist_sampler.set_epoch(epoch)

        # train for one epoch
        train_top1, train_top5, train_loss = train(train_loader, model, criterion, optimizer, epoch, args)

        if args.is_fast:
            save_bits(model, f"{BFP_HOME}/bit-log", epoch)

        if args.test_iteration:
            break

        # evaluate on validation set
        valid_top1, valid_top5, valid_loss = validate(val_loader, model, criterion, args)
        print(f"path: {project_path}")
        print(f"[best valid acc] top-1: {best_acc1:.3f}, top-5: {best_acc5:.3f}")
        
        scheduler.step()

        
        # remember best acc@1 and save checkpoint
        is_best = valid_top1 > best_acc1
        if is_best:
            best_acc1 = valid_top1
            best_acc5 = valid_top5

        if not is_dist or dist_but_rank_0:
            writer.add_scalar('loss/train', train_loss, epoch)
            writer.add_scalar('top1-accuracy/train', train_top1, epoch)
            writer.add_scalar('top5-accuracy/train', train_top5, epoch)

            writer.add_scalar('loss/valid', valid_loss, epoch)
            writer.add_scalar('top1-accuracy/valid', valid_top1, epoch)
            writer.add_scalar('top5-accuracy/valid', valid_top5, epoch)

            save_epoch_info(
                state={
                    'epoch': epoch,
                    'train_top1': train_top1,
                    'train_top5': train_top5,
                    'train_loss': train_loss,
                    'valid_top1': valid_top1,
                    'valid_top5': valid_top5,
                    'valid_loss': valid_loss
                },
                project_path=project_path,
                filename=f'epoch-{epoch}-info.pth'
            )

            save_checkpoint(
                state={
                    'epoch': epoch,
                    'arch': args.arch,
                    'state_dict': model.state_dict(),
                    'best_acc1': best_acc1,
                    'best_acc5': best_acc5,
                    'optimizer' : optimizer.state_dict(),
                    'scheduler' : scheduler.state_dict()
                }, is_best=is_best,
                project_path=project_path,
                epoch=epoch,
                filename=f'checkpoint-epoch-{epoch}.pth'
            )


def train(train_loader, model, criterion, optimizer, epoch, args):
    batch_time = AverageMeter('Time', ':6.3f')
    data_time = AverageMeter('Data', ':6.3f')
    losses = AverageMeter('Loss', ':.4e')
    top1 = AverageMeter('Acc@1', ':6.2f')
    top5 = AverageMeter('Acc@5', ':6.2f')
    progress = ProgressMeter(
        len(train_loader),
        [batch_time, data_time, losses, top1, top5],
        prefix="Epoch: [{}]".format(epoch))

    # switch to train mode
    model.train()

    # set curr_iteration
    BfpConfig.curr_iteration = 1

    end = time.time()
    for i, (images, target) in enumerate(train_loader):
        # print(f"epoch: {epoch}, iter: {BfpConfig.curr_iteration} / {FastBfpGemm.total_iterations}")
        # measure data loading time
        data_time.update(time.time() - end)

        if args.gpu is not None:
            images = images.cuda(args.gpu, non_blocking=True)
        if torch.cuda.is_available():
            target = target.cuda(args.gpu, non_blocking=True)

        # compute output
        output = model(images)
        loss = criterion(output, target)

        # measure accuracy and record loss
        acc1, acc5 = accuracy(output, target, topk=(1, 5))
        losses.update(loss.item(), images.size(0))
        top1.update(acc1[0], images.size(0))
        top5.update(acc5[0], images.size(0))

        # compute gradient and do SGD step
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        # measure elapsed time
        batch_time.update(time.time() - end)
        end = time.time()

        if i % args.print_freq == 0:
            progress.display(i)

        if args.test_iteration is not None and i >= args.test_iteration:
            break

        BfpConfig.curr_iteration += 1

    return top1.avg, top5.avg, losses.avg


def validate(val_loader, model, criterion, args):
    batch_time = AverageMeter('Time', ':6.3f', Summary.NONE)
    losses = AverageMeter('Loss', ':.4e', Summary.NONE)
    top1 = AverageMeter('Acc@1', ':6.2f', Summary.AVERAGE)
    top5 = AverageMeter('Acc@5', ':6.2f', Summary.AVERAGE)
    progress = ProgressMeter(
        len(val_loader),
        [batch_time, losses, top1, top5],
        prefix='Test: ')

    # switch to evaluate mode
    model.eval()

    with torch.no_grad():
        end = time.time()
        for i, (images, target) in enumerate(val_loader):
            if args.gpu is not None:
                images = images.cuda(args.gpu, non_blocking=True)
            if torch.cuda.is_available():
                target = target.cuda(args.gpu, non_blocking=True)

            # compute output
            output = model(images)
            loss = criterion(output, target)

            # measure accuracy and record loss
            acc1, acc5 = accuracy(output, target, topk=(1, 5))
            losses.update(loss.item(), images.size(0))
            top1.update(acc1[0], images.size(0))
            top5.update(acc5[0], images.size(0))

            # measure elapsed time
            batch_time.update(time.time() - end)
            end = time.time()

            if i % args.print_freq == 0:
                progress.display(i)

        progress.display_summary()

    return top1.avg, top5.avg, losses.avg


def save_epoch_info(state, project_path, filename):
    torch.save(state, os.path.join(project_path, filename))

def save_checkpoint(state, epoch, is_best, project_path, filename):
    if epoch % 10 == 0:
        torch.save(state, os.path.join(project_path, filename))

    if is_best:
        torch.save(state, os.path.join(project_path, 'model_best.pth'))
        # shutil.copyfile(filename, 'model_best.pth.tar')

class Summary(Enum):
    NONE = 0
    AVERAGE = 1
    SUM = 2
    COUNT = 3

class AverageMeter(object):
    """Computes and stores the average and current value"""
    def __init__(self, name, fmt=':f', summary_type=Summary.AVERAGE):
        self.name = name
        self.fmt = fmt
        self.summary_type = summary_type
        self.reset()

    def reset(self):
        self.val = 0
        self.avg = 0
        self.sum = 0
        self.count = 0

    def update(self, val, n=1):
        self.val = val
        self.sum += val * n
        self.count += n
        self.avg = self.sum / self.count

    def __str__(self):
        fmtstr = '{name} {val' + self.fmt + '} ({avg' + self.fmt + '})'
        return fmtstr.format(**self.__dict__)
    
    def summary(self):
        fmtstr = ''
        if self.summary_type is Summary.NONE:
            fmtstr = ''
        elif self.summary_type is Summary.AVERAGE:
            fmtstr = '{name} {avg:.3f}'
        elif self.summary_type is Summary.SUM:
            fmtstr = '{name} {sum:.3f}'
        elif self.summary_type is Summary.COUNT:
            fmtstr = '{name} {count:.3f}'
        else:
            raise ValueError('invalid summary type %r' % self.summary_type)
        
        return fmtstr.format(**self.__dict__)


class ProgressMeter(object):
    def __init__(self, num_batches, meters, prefix=""):
        self.batch_fmtstr = self._get_batch_fmtstr(num_batches)
        self.meters = meters
        self.prefix = prefix

    def display(self, batch):
        entries = [self.prefix + self.batch_fmtstr.format(batch)]
        entries += [str(meter) for meter in self.meters]
        print('\t'.join(entries))
        
    def display_summary(self):
        entries = [" *"]
        entries += [meter.summary() for meter in self.meters]
        print(' '.join(entries))

    def _get_batch_fmtstr(self, num_batches):
        num_digits = len(str(num_batches // 1))
        fmt = '{:' + str(num_digits) + 'd}'
        return '[' + fmt + '/' + fmt.format(num_batches) + ']'

def accuracy(output, target, topk=(1,)):
    """Computes the accuracy over the k top predictions for the specified values of k"""
    with torch.no_grad():
        maxk = max(topk)
        batch_size = target.size(0)

        _, pred = output.topk(maxk, 1, True, True)
        pred = pred.t()
        correct = pred.eq(target.view(1, -1).expand_as(pred))

        res = []
        for k in topk:
            correct_k = correct[:k].reshape(-1).float().sum(0, keepdim=True)
            res.append(correct_k.mul_(100.0 / batch_size))
        return res


if __name__ == '__main__':
    main()
