from gzip import _PaddedFile
from typing import OrderedDict
import torch
import torch.nn as nn

import numpy as np
import time
import sys

if "/home/yskim/projects/sparse-bfp" not in sys.path:
    sys.path.append("/home/yskim/projects/sparse-bfp")

import math

from util.bfp.bfp_config import BfpConfig
from util.bfp.bfp_wrapper import BfpWrapper
from util.bfp.bfp_gemm import BfpGemm
from util.custom_transpose import custom_transpose
from util.bfp.cuda.test_cuda_mem import CudaFloatStorage
from torch.autograd import Variable

from util.reprod_util import set_reproducibility
from util.bfp.cuda_bfp_wrapper import CudaBfpWrapper

def show_time(start, end, hint):
    print(f"{hint}: {((end - start) / 1000_000)}ms")

class PrecisionFlag:
    FP = 0
    BFP = 1
    BFP_SORTED = 2


class Conv2dLogConfig:
    should_log = False
    path = "/home/yskim/projects/sparse-bfp/outputs"
    iter = 0 
    layer_index = 0


class Conv2dFunction(torch.autograd.Function):
    @staticmethod
    def calculate_output_width(width, kernel_size, stride, padding):
        return math.floor(((width + 2 * padding - (kernel_size)) / stride) + 1)

    @staticmethod
    def remove_padding(tensor: torch.Tensor, padding) -> torch.Tensor:
        h, w = tensor.shape[2], tensor.shape[3]
        
        return tensor[:, :, padding:h-padding, padding:w-padding]

    @staticmethod
    def im2col(padded_inputs: torch.Tensor, 
               in_channels, out_width, 
               kernel_size, stride) -> torch.Tensor:
        batch_size = padded_inputs.shape[0]

        results = torch.empty(batch_size, 
                              out_width, 
                              out_width, 
                              in_channels * kernel_size * kernel_size)

        reshaped_results = results.reshape(batch_size * out_width * out_width,
                                           in_channels * kernel_size * kernel_size)

        row_index = 0
        for batch_idx in range(batch_size):
            single_inputs = padded_inputs[batch_idx]
            for h_out in range(out_width):
                for w_out in range(out_width):
                    h_start = h_out * stride
                    w_start = w_out * stride
                    window = single_inputs[:,
                                           h_start : h_start + kernel_size,
                                           w_start : w_start + kernel_size]
                    # print(f"{results[row_index].shape}, {window.shape}")
                    reshaped_results[row_index] = window.flatten()

                    row_index += 1

        return results

    @staticmethod
    def col2im(im2col: torch.Tensor,
               padded_inputs_shape: torch.Size, 
               in_channels, out_width, 
               kernel_size, stride) -> torch.Tensor:
        batch_size = padded_inputs_shape[0]

        results = torch.zeros(padded_inputs_shape)

        row_index = 0
        for batch_idx in range(batch_size):
            for h_out in range(out_width):
                for w_out in range(out_width):
                    h_start = h_out * stride
                    w_start = w_out * stride
                    sub_inputs = im2col[row_index].reshape(in_channels, 
                                                           kernel_size,
                                                           kernel_size)
                    results[batch_idx,
                            :,
                            h_start : h_start + kernel_size,
                            w_start : w_start + kernel_size] += sub_inputs

                    row_index += 1

        return results

    @staticmethod
    def forward(ctx, inputs, weights, bias,
                in_channels, out_channels,
                kernel_size, stride, padding,
                precision_flag: PrecisionFlag,
                bfp_gemms, 
                id):
        if inputs.shape[2] != inputs.shape[3]:
            raise ValueError(f"not supported inputs widht, and height ({inputs.shape[2]}, {inputs.shape[3]})")
        
        if precision_flag == PrecisionFlag.FP:
            prec_name = "fp"
        elif precision_flag == PrecisionFlag.BFP:
            prec_name = "bfp"
        else:
            raise ValueError(f"not supported precision flag: {precision_flag}")

        batch_size = inputs.shape[0]

        start = time.time_ns()
        zero_pad_2d = nn.ZeroPad2d(padding)
        end = time.time_ns()
        show_time(start, end, "zero padd create")

        start = time.time_ns()
        padded_inputs = zero_pad_2d(inputs)
        end = time.time_ns()
        show_time(start, end, "zero padding")

        # print(f"input: {inputs.shape}")
        # print(f"padd : {padded_inputs.shape}")

        out_width = Conv2dFunction.calculate_output_width(inputs.shape[2], 
                                                          kernel_size,
                                                          stride,
                                                          padding)

        im2col_start = time.time_ns()
        im2col_inputs = Conv2dFunction.im2col(padded_inputs, 
                                              in_channels, 
                                              out_width,
                                              kernel_size,
                                              stride)
        im2col_end = time.time_ns()
        print(f"fwd im2col time: {((im2col_end - im2col_start) / 1000_000):.5f}ms")

        weight_reshape_start = time.time_ns()
        weight_reshaped = weights.reshape((out_channels, -1))
        weight_reshape_end = time.time_ns()
        print(f"fwd weight reshaped time: {((weight_reshape_end - weight_reshape_start) / 1000_000):.5f}ms")

        ctx.save_for_backward(im2col_inputs, weights, bias)

        ctx.in_channels = in_channels
        ctx.out_channels = out_channels
        ctx.stride = stride
        ctx.kernel_size = kernel_size
        ctx.padding = padding
        ctx.out_width = out_width
        ctx.padded_inputs_shape = padded_inputs.shape
        ctx.precision_flag = precision_flag
        ctx.bfp_gemms = bfp_gemms
        ctx.id = id
        ctx.prec_name = prec_name

        M = im2col_inputs.shape[0] * im2col_inputs.shape[1] * im2col_inputs.shape[2] 
        K = im2col_inputs.shape[3]

        im2col_inputs_reshaped = im2col_inputs.reshape(M, K)

        if precision_flag == PrecisionFlag.FP:
            outputs = torch.matmul(im2col_inputs_reshaped, weight_reshaped.t())

            if Conv2dLogConfig.should_log:
                path = Conv2dLogConfig.path

                with open(f"{path}/conv2d-{id}-fwd-lhs-{prec_name}.npy", "wb") as f:
                    np.save(f, im2col_inputs_reshaped.numpy(), allow_pickle=False)

                with open(f"{path}/conv2d-{id}-fwd-rhs-{prec_name}.npy", "wb") as f:
                    np.save(f, weight_reshaped.t().numpy(), allow_pickle=False)

        elif precision_flag == PrecisionFlag.BFP:
            if bfp_gemms["fwd"] is None:
                    bfp_gemms["fwd"] = BfpGemm(im2col_inputs_reshaped.shape, weight_reshaped.shape)

            bfp_gemm = bfp_gemms["fwd"]

            fwd_start = time.time_ns()
            outputs = bfp_gemm.run(im2col_inputs_reshaped, weight_reshaped)
            fwd_end = time.time_ns()
            print(f"fwd gemm time: {((fwd_end - fwd_start) / 1000_000):.5f}ms")

            if Conv2dLogConfig.should_log:
                path = Conv2dLogConfig.path

                with open(f"{path}/conv2d-{id}-fwd-lhs-E-{prec_name}.npy", "wb") as f:
                    np.save(f, bfp_gemm.lhs_wrapper.bfp_E.numpy(), allow_pickle=False)

                with open(f"{path}/conv2d-{id}-fwd-lhs-ori-E-{prec_name}.npy", "wb") as f:
                    np.save(f, bfp_gemm.lhs_wrapper.ori_E.numpy(), allow_pickle=False)

                with open(f"{path}/conv2d-{id}-fwd-lhs-M-{prec_name}.npy", "wb") as f:
                    np.save(f, bfp_gemm.lhs_wrapper.bfp_M.numpy(), allow_pickle=False)

                with open(f"{path}/conv2d-{id}-fwd-rhs-E-{prec_name}.npy", "wb") as f:
                    np.save(f, bfp_gemm.rhs_wrapper.bfp_E.numpy(), allow_pickle=False)

                with open(f"{path}/conv2d-{id}-fwd-rhs-ori-E-{prec_name}.npy", "wb") as f:
                    np.save(f, bfp_gemm.rhs_wrapper.ori_E.numpy(), allow_pickle=False)

                with open(f"{path}/conv2d-{id}-fwd-rhs-M-{prec_name}.npy", "wb") as f:
                    np.save(f, bfp_gemm.rhs_wrapper.bfp_M.numpy(), allow_pickle=False)
        else:
            raise ValueError(f"not supported precision flag: {precision_flag}")


        output_permute_start = time.time_ns()

        # outputs = torch.matmul(im2col_inputs.reshape(M, K), weight_reshaped.t())
        outputs = outputs.reshape(batch_size, out_width, out_width, out_channels)
        # outputs = outputs.permute([0, 3, 1, 2])
        outputs = custom_transpose(outputs, [0, 3, 1, 2])


        output_permute_end = time.time_ns()
        print(f"fwd output permute time: {((output_permute_end - output_permute_start) / 1000_000)}ms")

        if Conv2dLogConfig.should_log:
            path = Conv2dLogConfig.path

            with open(f"{path}/conv2d-{id}-fwd-{prec_name}.npy", "wb") as f:
                    np.save(f, outputs.numpy(), allow_pickle=False)

        if bias is not None:
            bias = bias.unsqueeze(1)
            bias = bias.unsqueeze(1)
            bias = bias.unsqueeze(0)
            outputs += bias.expand_as(outputs)

        return outputs

    @staticmethod
    def backward(ctx, grad_output):
        precision_flag = ctx.precision_flag
        bfp_gemms = ctx.bfp_gemms
        id = ctx.id
        prec_name = ctx.prec_name
        # print(f"precision_flag: {ctx.precision_flag}")

        im2col_inputs, weights, bias = ctx.saved_tensors
        grad_input = grad_weight = grad_bias = None
    
        # grad_output = grad_output.permute([0, 2, 3, 1]) # BCHW -> BHWC
        grad_output = custom_transpose(grad_output, [0, 2, 3, 1])
        B = grad_output.shape[0]
        H = grad_output.shape[1]
        W = grad_output.shape[2]
        C = grad_output.shape[3]

        grad_output = grad_output.reshape(B * H * W , -1)

        if ctx.needs_input_grad[0]:
            if precision_flag == PrecisionFlag.FP:
                grad_input = grad_output.mm(weights.reshape(C, -1))

                if Conv2dLogConfig.should_log:
                    path = Conv2dLogConfig.path

                    with open(f"{path}/conv2d-{id}-grad-a-lhs-{prec_name}.npy", "wb") as f:
                        np.save(f, grad_output.numpy(), allow_pickle=False)

                    with open(f"{path}/conv2d-{id}-grad-a-rhs-{prec_name}.npy", "wb") as f:
                        np.save(f, weights.reshape(C, -1).numpy(), allow_pickle=False)

            elif precision_flag == PrecisionFlag.BFP:
                weight_premute_start = time.time_ns()

                weights_t = custom_transpose(weights.reshape(C, -1), [1, 0])
                
                weight_premute_end = time.time_ns()
                show_time(weight_premute_start, weight_premute_end, "grad-a weight permute")

                if bfp_gemms["grad-a"] is None:
                    bfp_gemms["grad-a"] = BfpGemm(grad_output.shape, weights_t.shape)

                bfp_gemm = bfp_gemms["grad-a"]

                start = time.time_ns()

                grad_input = bfp_gemm.run(grad_output, weights_t)
                
                end = time.time_ns()
                show_time(start, end, "grad-a gemm")

                if Conv2dLogConfig.should_log:
                    path = Conv2dLogConfig.path

                    with open(f"{path}/conv2d-{id}-grad-a-lhs-E-{prec_name}.npy", "wb") as f:
                        np.save(f, bfp_gemm.lhs_wrapper.bfp_E.numpy(), allow_pickle=False)

                    with open(f"{path}/conv2d-{id}-grad-a-lhs-ori-E-{prec_name}.npy", "wb") as f:
                        np.save(f, bfp_gemm.lhs_wrapper.ori_E.numpy(), allow_pickle=False)

                    with open(f"{path}/conv2d-{id}-grad-a-lhs-M-{prec_name}.npy", "wb") as f:
                        np.save(f, bfp_gemm.lhs_wrapper.bfp_M.numpy(), allow_pickle=False)

                    with open(f"{path}/conv2d-{id}-grad-a-rhs-E-{prec_name}.npy", "wb") as f:
                        np.save(f, bfp_gemm.rhs_wrapper.bfp_E.numpy(), allow_pickle=False)

                    with open(f"{path}/conv2d-{id}-grad-a-rhs-ori-E-{prec_name}.npy", "wb") as f:
                        np.save(f, bfp_gemm.rhs_wrapper.ori_E.numpy(), allow_pickle=False)

                    with open(f"{path}/conv2d-{id}-grad-a-rhs-M-{prec_name}.npy", "wb") as f:
                        np.save(f, bfp_gemm.rhs_wrapper.bfp_M.numpy(), allow_pickle=False)

            else:
                raise ValueError(f"not supported precision flag: {precision_flag}")

            start = time.time_ns()
            grad_input = Conv2dFunction.col2im(grad_input,
                                               ctx.padded_inputs_shape,
                                               ctx.in_channels,
                                               ctx.out_width,
                                               ctx.kernel_size,
                                               ctx.stride)
            grad_input = Conv2dFunction.remove_padding(grad_input, ctx.padding)
            end = time.time_ns()
            show_time(start , end, "grad-a col2im")

            if Conv2dLogConfig.should_log:
                path = Conv2dLogConfig.path
                iter = Conv2dLogConfig.iter

                with open(f"{path}/conv2d-{id}-grad-a-{prec_name}.npy", "wb") as f:
                    np.save(f, grad_input.numpy(), allow_pickle=False)

        if ctx.needs_input_grad[1]:
            im2col_inputs = im2col_inputs.reshape(B * H * W , -1)

            if precision_flag == PrecisionFlag.FP:
                grad_weight = grad_output.t().mm(im2col_inputs).reshape(weights.shape)

                if Conv2dLogConfig.should_log:
                    path = Conv2dLogConfig.path

                    with open(f"{path}/conv2d-{id}-grad-w-lhs-{prec_name}.npy", "wb") as f:
                        np.save(f, grad_output.t().numpy(), allow_pickle=False)

                    with open(f"{path}/conv2d-{id}-grad-w-rhs-{prec_name}.npy", "wb") as f:
                        np.save(f, im2col_inputs.numpy(), allow_pickle=False)

            elif precision_flag == PrecisionFlag.BFP:
                start = time.time_ns()
                grad_output_t = custom_transpose(grad_output, [1, 0])
                end = time.time_ns()
                show_time(start, end, "grad-w grad_output permute")

                start = time.time_ns()
                im2col_inputs_t = custom_transpose(im2col_inputs, [1, 0])
                end = time.time_ns()
                show_time(start, end, "grad-w grad_output permute")

                if bfp_gemms["grad-w"] is None:
                    bfp_gemms["grad-w"] = BfpGemm(grad_output_t.shape, im2col_inputs_t.shape)
                    
                bfp_gemm = bfp_gemms["grad-w"]
                start = time.time_ns()
                grad_weight = bfp_gemm.run(grad_output_t, im2col_inputs_t).reshape(weights.shape)
                end = time.time_ns()
                show_time(start, end, "grad-w gemm")


                if Conv2dLogConfig.should_log:
                    path = Conv2dLogConfig.path
                    iter = Conv2dLogConfig.iter

                    with open(f"{path}/conv2d-{id}-grad-w-lhs-E-{prec_name}.npy", "wb") as f:
                        np.save(f, bfp_gemm.lhs_wrapper.bfp_E.numpy(), allow_pickle=False)

                    with open(f"{path}/conv2d-{id}-grad-w-lhs-ori-E-{prec_name}.npy", "wb") as f:
                        np.save(f, bfp_gemm.lhs_wrapper.ori_E.numpy(), allow_pickle=False)

                    with open(f"{path}/conv2d-{id}-grad-w-lhs-M-{prec_name}.npy", "wb") as f:
                        np.save(f, bfp_gemm.lhs_wrapper.bfp_M.numpy(), allow_pickle=False)

                    with open(f"{path}/conv2d-{id}-grad-w-rhs-E-{prec_name}.npy", "wb") as f:
                        np.save(f, bfp_gemm.rhs_wrapper.bfp_E.numpy(), allow_pickle=False)

                    with open(f"{path}/conv2d-{id}-grad-w-rhs-ori-E-{prec_name}.npy", "wb") as f:
                        np.save(f, bfp_gemm.rhs_wrapper.ori_E.numpy(), allow_pickle=False)

                    with open(f"{path}/conv2d-{id}-grad-w-rhs-M-{prec_name}.npy", "wb") as f:
                        np.save(f, bfp_gemm.rhs_wrapper.bfp_M.numpy(), allow_pickle=False)
            else:
                raise ValueError(f"not supported precision flag: {precision_flag}")

            if Conv2dLogConfig.should_log:
                path = Conv2dLogConfig.path
                iter = Conv2dLogConfig.iter

                with open(f"{path}/conv2d-{id}-grad-w-{prec_name}.npy", "wb") as f:
                    np.save(f, grad_weight.numpy(), allow_pickle=False)


        if bias is not None and ctx.needs_input_grad[2]:
            grad_bias = grad_output.sum(0)

        return grad_input, grad_weight, grad_bias, None, None, None, None, None, None, None, None


class CustomConv2d(nn.Module):
    current_id = 0

    def __init__(self, 
                 in_channels,
                 out_channels,
                 kernel_size,
                 stride,
                 padding,
                 bias,
                 precision_flag: PrecisionFlag):
        super(CustomConv2d, self).__init__()
        self.id = CustomConv2d.current_id
        CustomConv2d.current_id += 1

        self.in_channels = in_channels
        self.out_channels = out_channels
        self.kernel_size = kernel_size
        self.stride = stride
        self.padding = padding

        self.weight = nn.Parameter(torch.empty(self.out_channels,
                                               self.in_channels,
                                               self.kernel_size,
                                               self.kernel_size))

        self.bfp_gemms = {
            "fwd": None,
            "grad-w": None,
            "grad-a": None
        }
        
        if bias:
            self.bias = nn.Parameter(torch.empty(self.out_channels))
        else:
            self.register_parameter('bias', None)

        self.precision_flag = precision_flag

    def forward(self, inputs):
        if self.precision_flag == PrecisionFlag.FP or PrecisionFlag.BFP:
            return Conv2dFunction.apply(inputs, self.weight, self.bias, 
                                        self.in_channels, self.out_channels,
                                        self.kernel_size, 
                                        self.stride, 
                                        self.padding, 
                                        self.precision_flag,
                                        self.bfp_gemms,
                                        self.id)
        else:
            raise ValueError(f"not supported precision flag: {self.precision_flag}")


if __name__ == "__main__":
    set_reproducibility(1234)

    BfpConfig.bfp_M_Bit = 24

    batch_size = 8
    width = 224
    in_channels_list = [3, 64]
    out_channels_list = [64, 192]
    kernel_sizes = [11, 5]
    strides = [4, 1]
    padding = 2
    bias = True

    pool_kernel = 3
    pool_stride = 2

    max_val = 5
    min_val = -5

    ########################

    inputs = torch.randn(size=(batch_size, in_channels_list[0], width, width))
    print(inputs.shape)

    zero_pad_2d = nn.ZeroPad2d(padding)
    
    start = time.time_ns()
    padded_inputs = zero_pad_2d(inputs)
    im2col_cpu = Conv2dFunction.im2col(
        padded_inputs, 
        in_channels_list[0], 
        Conv2dFunction.calculate_output_width(
            width, 
            kernel_sizes[0], 
            strides[0], 
            padding), 
        kernel_sizes[0], 
        strides[0])
    im2col_cpu = im2col_cpu.reshape(8 * 3025, 363)
    end = time.time_ns()
    show_time(start, end, "cpu time")

    unfold = torch.nn.Unfold(kernel_size=kernel_sizes[0], padding=padding, stride=strides[0])
    

    inputs = inputs.to('cuda')

    start = time.time_ns()
    im2col_torch = unfold(inputs)
    im2col_torch = torch.permute(im2col_torch, [0, 2, 1]).reshape(8 * 3025, 363)
    end = time.time_ns()
    show_time(start, end, "torch time")

    im2col_torch = im2col_torch.to('cpu')

    print(im2col_cpu.shape)
    print(im2col_torch.shape)
    print(torch.mean(torch.abs((im2col_cpu - im2col_torch).flatten())))

    exit()
    ########################

    Conv2dLogConfig.should_log = True

    conv2ds = nn.Sequential(OrderedDict([
        ("conv0", nn.Conv2d(in_channels_list[0], out_channels_list[0], kernel_size=kernel_sizes[0], stride=strides[0], bias=bias, padding=padding)),
        ("relu", nn.ReLU()),
        ("maxpool", nn.MaxPool2d(kernel_size=pool_kernel, stride=pool_stride)),
        ("conv1", nn.Conv2d(in_channels_list[1], out_channels_list[1], kernel_size=kernel_sizes[1], stride=strides[1], bias=bias, padding=padding))
    ]))

    weights = [
        conv2ds.conv0.weight.data.clone().detach(),
        conv2ds.conv1.weight.data.clone().detach(),

        # torch.randint(low=min_val, high=max_val, size=conv2ds.conv0.weight.shape, dtype=torch.float),
        # torch.randint(low=min_val, high=max_val, size=conv2ds.conv1.weight.shape, dtype=torch.float),
    ]

    bias = [
        conv2ds.conv0.bias.data.clone().detach(),
        conv2ds.conv1.bias.data.clone().detach(),

        # torch.randint(low=min_val, high=max_val, size=(conv2ds.conv0.weight.shape[0],), dtype=torch.float),
        # torch.randint(low=min_val, high=max_val, size=(conv2ds.conv1.weight.shape[0],), dtype=torch.float)
    ]

    precision_flag = PrecisionFlag.BFP
    custom_conv2ds = nn.Sequential(OrderedDict([
        ("conv0", CustomConv2d(in_channels_list[0], out_channels_list[0], kernel_size=kernel_sizes[0], stride=strides[0], padding=padding, bias=bias, precision_flag=precision_flag)),
        ("relu", nn.ReLU()),
        ("maxpool", nn.MaxPool2d(kernel_size=pool_kernel, stride=pool_stride)),
        ("conv1", CustomConv2d(in_channels_list[1], out_channels_list[1], kernel_size=kernel_sizes[1], stride=strides[1], padding=padding, bias=bias, precision_flag=precision_flag))
    ]))

    for i in range(1):
        conv2ds.conv0.weight = nn.Parameter(weights[0].clone().detach())
        if bias:
            conv2ds.conv0.bias = nn.Parameter(bias[0].clone().detach())

        custom_conv2ds.conv0.weight = nn.Parameter(weights[0].clone().detach())
        if bias:
            custom_conv2ds.conv0.bias = nn.Parameter(bias[0].clone().detach())

        conv2ds.conv1.weight = nn.Parameter(weights[1].clone().detach())
        if bias:
            conv2ds.conv1.bias = nn.Parameter(bias[1].clone().detach())

        custom_conv2ds.conv1.weight = nn.Parameter(weights[1].clone().detach())
        if bias:
            custom_conv2ds.conv1.bias = nn.Parameter(bias[1].clone().detach())

    models = [conv2ds, custom_conv2ds]
    criterions = [nn.CrossEntropyLoss() for _ in models]
    optimizers = [torch.optim.SGD(model.parameters(), lr=1.0) for model in models]


    # inputs = torch.randint(low=min_val, high=max_val, size=(batch_size, in_channels_list[0], width, width), dtype=torch.float)
    inputs = torch.randn(batch_size, in_channels_list[0], width, width)


    # targets = torch.randint(low=min_val, high=max_val, size=(batch_size, out_channels_list[1], 27, 27), dtype=torch.float)
    targets = torch.randn(batch_size, out_channels_list[1], 27, 27)

    # targets = torch.randint(low=-5, high=5, size=(batch_size, out_channels_list[1], width, width), dtype=torch.float)
    # targets = torch.randn(batch_size, out_channels_list[1], width, width)

    outputs_list = []

    # for model in models:
    #     model = model.to('cuda')

    # for criterion in criterions:
    #     criterion = criterion.to('cuda')

    # inputs = inputs.to('cuda')
    # targets = targets.to('cuda')


    for i in range(len(models)):
        print([f"[MODEL {i}]"])
        
        outputs = models[i](inputs)

        outputs_list.append(outputs.clone().detach())

        loss = torch.sum(torch.abs(outputs - targets))

        optimizers[i].zero_grad()
        loss.backward()
        optimizers[i].step()

    diff = torch.abs(outputs_list[0].flatten() - outputs_list[1].flatten())
    print(f"fwd output mean diff: {torch.mean(diff):.10f}")
    # print(f"fwd output sum diff: {torch.sum(diff):.10f}")

    diff = torch.abs(conv2ds.conv0.weight.flatten() - custom_conv2ds.conv0.weight.flatten())
    print(f"fwd weight0 mean diff: {torch.mean(diff):.10f}")
    # print(f"weight0 sum diff: {torch.sum(diff):.10f}")

    diff = torch.abs(conv2ds.conv1.weight.flatten() - custom_conv2ds.conv1.weight.flatten())
    print(f"fwd weight1 mean diff: {torch.mean(diff):.10f}")
    # print(f"weight1 sum diff: {torch.sum(diff):.10f}")