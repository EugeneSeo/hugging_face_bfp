from re import A
import sys
from xmlrpc.client import Boolean
import torch
import ctypes
import numpy as np
from ctypes import *


from util.bfp.bfp_config import BfpConfig
from util.reprod_util import set_reproducibility

import os
BFP_HOME = os.environ["BFP_HOME"]

bfp_cvt_lib = ctypes.CDLL(f"{BFP_HOME}/util/bfp/cuda/lib_cuda_bfp_converter.so")
bfp_cvt_lib_multi_exp = ctypes.CDLL(f"{BFP_HOME}/util/bfp/cuda/lib_cuda_bfp_multi_exp_converter.so")
bfp_cvt_lib_thresholding = ctypes.CDLL(f"{BFP_HOME}/util/bfp/cuda/lib_cuda_bfp_thresholding_converter.so")


class CudaBfpWrapper:
    def __init__(self, fp_tensor_shape: torch.Size, use_multi_exp: bool, apply_thresholding: bool, threshold: int):
        self.fp_tensor_shape = fp_tensor_shape

        shape_cnt = len(fp_tensor_shape)
        if shape_cnt > 2:
            self.batch = int(torch.prod(torch.tensor(fp_tensor_shape[:-2])).item())
            self.rows = int(fp_tensor_shape[-2])
            self.cols = int(fp_tensor_shape[-1])
        else:
            self.batch = 1
            self.rows = int(fp_tensor_shape[0])
            self.cols = int(fp_tensor_shape[1])

        self.size = (self.batch * self.rows, self.cols)

        super().__init__()

        self.device = "cuda"

        self.bfp_S = torch.zeros(size=self.size,
                                 dtype=torch.int32,
                                 device=self.device)

        self.bfp_E = torch.zeros(size=self.size,
                                 dtype=torch.int32,
                                 device=self.device)

        self.bfp_M = torch.zeros(size=self.size,
                                 dtype=torch.int32,
                                 device=self.device)

        self.bfp_32_bit_M = torch.zeros(size=self.size,
                                        dtype=torch.int32,
                                        device=self.device)

        if use_multi_exp:
            self.bfp_E_index_ptr = torch.zeros(size=self.size, 
                                               dtype=torch.uint8,
                                               device=self.device)

        self.ori_E = torch.zeros(size=self.size,
                                 dtype=torch.int32,
                                 device=self.device)

        self.use_multi_exp = use_multi_exp

        self.apply_thresholding = apply_thresholding
        self.threshold = threshold

        self.bfp_M_bit = BfpConfig.bfp_M_Bit

    def run_convert_fp_to_bfp(self, src_tensor: torch.Tensor, is_stochastic_rounding: bool):
        if self.use_multi_exp:
            bfp_cvt_lib_multi_exp.fp_to_bfp(
                c_void_p(src_tensor.data_ptr()),
                
                c_void_p(self.bfp_S.data_ptr()),
                c_void_p(self.bfp_E.data_ptr()),
                c_void_p(self.bfp_M.data_ptr()),

                c_void_p(self.bfp_E_index_ptr.data_ptr()),

                c_int32(self.size[0]),
                c_int32(self.size[1]),
                c_int32(BfpConfig.group_size),
                c_int32(self.bfp_M_bit),

                c_bool(is_stochastic_rounding))
        elif self.apply_thresholding:
            bfp_cvt_lib_thresholding.fp_to_bfp(
                c_void_p(src_tensor.data_ptr()),
                
                c_void_p(self.bfp_S.data_ptr()),
                c_void_p(self.bfp_E.data_ptr()),
                c_void_p(self.bfp_M.data_ptr()),

                c_void_p(self.bfp_32_bit_M.data_ptr()),
                c_void_p(self.ori_E.data_ptr()),

                c_int32(self.threshold),

                c_int32(self.size[0]),
                c_int32(self.size[1]),
                c_int32(BfpConfig.group_size),
                c_int32(self.bfp_M_bit),
                c_bool(is_stochastic_rounding))
        else:
            bfp_cvt_lib.fp_to_bfp(
                c_void_p(src_tensor.data_ptr()),
                
                c_void_p(self.bfp_S.data_ptr()),
                c_void_p(self.bfp_E.data_ptr()),
                c_void_p(self.bfp_M.data_ptr()),

                c_void_p(self.bfp_32_bit_M.data_ptr()),
                c_void_p(self.ori_E.data_ptr()),

                # c_void_p(self.zero_M_index.data_ptr()),

                c_int32(self.size[0]),
                c_int32(self.size[1]),
                c_int32(BfpConfig.group_size),
                c_int32(self.bfp_M_bit),
                c_bool(is_stochastic_rounding))

    def get_fp_from_current_bfp_info(self, dst_tensor: torch.Tensor):
        if self.use_multi_exp:
            bfp_cvt_lib_multi_exp.bfp_to_fp(
                c_void_p(self.bfp_S.data_ptr()),
                c_void_p(self.bfp_E.data_ptr()),
                c_void_p(self.bfp_M.data_ptr()),
                c_void_p(dst_tensor.data_ptr()),

                c_void_p(self.bfp_E_index_ptr.data_ptr()),
                
                c_int32(self.size[0]),
                c_int32(self.size[1]),
                c_int32(BfpConfig.group_size),
                c_int32(self.bfp_M_bit))
        else:
            bfp_cvt_lib.bfp_to_fp(
                c_void_p(self.bfp_S.data_ptr()),
                c_void_p(self.bfp_E.data_ptr()),
                c_void_p(self.bfp_M.data_ptr()),
                c_void_p(dst_tensor.data_ptr()),

                c_bool(False),
                
                c_int32(self.size[0]),
                c_int32(self.size[1]),
                c_int32(BfpConfig.group_size),
                c_int32(self.bfp_M_bit))

    def change_fp_tensor(self, fp_tensor: torch.Tensor):
        self.fp_tensor = fp_tensor
        self.np_fp_tensor = self.fp_tensor.numpy()


def load_inout(path_root, phase, layer_index):
    path = f"{path_root}/{phase}-{layer_index}-fp"

    lhs = np.load(f"{path}-lhs.npy", allow_pickle=False)
    rhs = np.load(f"{path}-rhs.npy", allow_pickle=False)
    output = np.matmul(lhs, rhs)
    # print(f"lhs: {lhs.shape} X rhs: {rhs.shape} = output: {output.shape}")
    
    # lhs = lhs[n_index,0:k_cnt]
    # rhs = rhs[0:k_cnt,m_index]
    # output = np.dot(lhs, rhs)
    # print(f"lhs: {lhs.shape} X rhs: {rhs.shape} = output: {output.shape}")

    return lhs, rhs, output

if __name__ == "__main__":
    set_reproducibility(1234)
    BfpConfig.bfp_M_Bit = 8
    
    use_multi_exp = False
    apply_thresholding = False
    threshold = 5

    log_path = f"{BFP_HOME}/resnet50-inout-log/epoch0-lr0.001"
    lhs, rhs, output = load_inout(log_path, "fwd", 3)
    print(lhs.shape)
    print(rhs.shape)

    # lhs = np.abs(lhs)
    # rhs = np.abs(rhs)

    # return

    M = lhs.shape[0] # 1024 # 1
    K = lhs.shape[1] # 2024 * 4 # 2
    N = rhs.shape[1] # 1024 # 1

    # M = 1
    # K = 16
    # N = 1
    # start = 4
    # lhs = lhs[start:M+start,0:K]
    # rhs = rhs[0:K,start:N+start]

    shape = (M, K)

    wrapper = CudaBfpWrapper(
        fp_tensor_shape=shape,
        use_multi_exp=use_multi_exp,
        apply_thresholding=apply_thresholding,
        threshold=threshold
    )
    for i in range(1):
        # fp_input = torch.randn(shape, dtype=torch.float32).to('cuda')
        fp_input = torch.tensor(lhs, dtype=torch.float32).to('cuda')
        fp_output = torch.randn(shape, dtype=torch.float32).to('cuda')
        # wrapper.change_fp_tensor(fp_input)
        wrapper.run_convert_fp_to_bfp(src_tensor=fp_input, is_stochastic_rounding=False)

        print(wrapper.bfp_M.cpu().numpy())
        # if wrapper.use_multi_exp:
        #     print(wrapper.bfp_E_index_ptr.cpu().numpy())
        #     print(wrapper.bfp_E.cpu().numpy()[0][0:4])
        # else:
        #     print(wrapper.bfp_E.cpu().numpy())
        #     print(wrapper.zero_M_index.cpu().numpy())

        wrapper.get_fp_from_current_bfp_info(dst_tensor=fp_output)


        fp_output_st = torch.randn(shape, dtype=torch.float32).to('cuda')
        # wrapper.change_fp_tensor(fp_input)
        wrapper.run_convert_fp_to_bfp(src_tensor=fp_input, is_stochastic_rounding=True)
        wrapper.get_fp_from_current_bfp_info(dst_tensor=fp_output_st)

        # print(fp_input)
        # print(cpy_output)
        print(f"mean diff          : {torch.mean(torch.abs(fp_input.flatten() - fp_output.flatten())):.15f}")
        print(f"mean diff *st      : {torch.mean(torch.abs(fp_input.flatten() - fp_output_st.flatten())):.15f}")
        # print(f"mean diff (sorted) : {torch.mean(torch.abs(fp_input.flatten() - cpy_output_sorted.flatten())):.5f}")