from ctypes import *

lib = CDLL("./lib_bfp_converter.so")

lib.sample(c_int(1234))