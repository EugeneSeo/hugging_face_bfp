#pragma once

#include <cstdint>

extern "C" {
    // void* allocate_cuda(const size_t size, const size_t data_size);
    void* allocate_cuda(const size_t size, const size_t data_size);

    void send(void* dst, const void* src, const size_t size, const size_t data_size);

    void recv(void* dst, const void* src, const size_t size, const size_t data_size);

    void cuda_d2d_copy(void* dst, const void* src, const size_t size, const size_t data_size);

    void free_cuda(void* addr);

    void permute_nchw_to_nhwc(
        void* dst,
        const void* src,
        const size_t dim_0,
        const size_t dim_1,
        const size_t dim_2,
        const size_t dim_3);

    void permute_nhwc_to_nchw(
        void* dst,
        const void* src,
        const size_t dim_0,
        const size_t dim_1,
        const size_t dim_2,
        const size_t dim_3);

    void transpose_2d(
        void* dst,
        const void* src,
        const size_t height,
        const size_t width);

    void transpose_4d(
        void* dst,
        const void* src,
        const size_t dim_0,
        const size_t dim_1,
        const size_t dim_2,
        const size_t dim_3);
}