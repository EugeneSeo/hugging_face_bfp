#pragma once

#include <cstdint>

extern "C" {
void fp_to_bfp(
    const float* fp_mat_ptr, 
    int32_t* bfp_mat_S_ptr,
    int32_t* bfp_mat_E_ptr,
    int32_t* bfp_mat_M_ptr,
    
    int32_t* bfp_mat_32_bit_M_ptr,
    int32_t* bfp_mat_ori_E_ptr,

    // bool* bfp_mat_zero_M_index_ptr,

    const int32_t fp_height,
    const int32_t fp_width,
    const int32_t group_size,
    const int32_t bfp_M_bit,
    const bool is_stochastic_rounding
);

void bfp_to_fp(
    const int32_t* bfp_mat_S_ptr,
    const int32_t* bfp_mat_E_ptr,
    const int32_t* bfp_mat_M_ptr,
    float* fp_mat_ptr, 

    const bool should_sort,

    const int32_t fp_height,
    const int32_t fp_width,
    const int32_t group_size,
    const int32_t bfp_M_bit
);

}