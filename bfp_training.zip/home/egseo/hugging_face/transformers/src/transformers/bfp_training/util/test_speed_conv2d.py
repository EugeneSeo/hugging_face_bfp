import time
import torch
import torch.nn as nn
from tqdm import tqdm
import torch.optim as optim
from torchvision import models

import sys
if "/home/yskim/projects/sparse-bfp" not in sys.path:
    sys.path.append("/home/yskim/projects/sparse-bfp")

from util.custom_conv2d import CustomConv2d, PrecisionFlag
from util.data_load import *
from util.bfp.bfp_config import BfpConfig
from util.reprod_util import set_reproducibility

def wrap_modules(module, precision_flag: PrecisionFlag):
    for name, _ in module.named_children():
        child = getattr(module, name)
        child_cnt = 0
        for _ in child.children():
            child_cnt += 1

        if child_cnt == 0:
            layer = getattr(module, name)
            for _, param in layer.named_parameters():
                if param.requires_grad:
                    pass

            if "Conv" in str(layer):
                custom_layer = CustomConv2d(in_channels=layer.in_channels,
                                            out_channels=layer.out_channels,
                                            kernel_size=layer.kernel_size[0],
                                            stride=layer.stride[0],
                                            padding=layer.padding[0],
                                            bias=True if layer.bias is not None else False,
                                            precision_flag=precision_flag)
                custom_layer.weight = nn.Parameter(layer.weight.data.clone().detach())
                if layer.bias is not None:
                    custom_layer.bias = nn.Parameter(layer.bias.data.clone().detach())
                setattr(module, name, custom_layer)
        else:
            wrap_modules(child, precision_flag)


if __name__ == "__main__":
    batch_size = 32
    # train_loader, valid_loader = generate_data_loaders(type=DL_TYPE_IMAGENET, batch_size=32)
    train_loader, valid_loader = generate_data_loaders(type=DL_TYPE_CIFAR_100, batch_size=batch_size)

    device = "cuda"

    iterations = 1000

    def get_ett_ns(model, crit, optimizer, train_loader, iterations):
        ett_ns = 0

        torch.cuda.synchronize()
        start = time.time_ns()
        
        for batch_index, (inputs, targets) in enumerate(tqdm(train_loader), 0):

            inputs = inputs.to(device)
            targets = targets.to(device)

            outputs = model(inputs)

            loss = crit(outputs, targets)

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            # if batch_index > 0:
                # ett_ns += (end - start)

            if batch_index >= iterations:
                break

        torch.cuda.synchronize()
        end = time.time_ns()

        ett_ns += (end - start)

        return ett_ns


    model_torch = models.resnet18(num_classes=100).to(device)
    crit_torch = nn.CrossEntropyLoss().to(device)
    sgd_torch = optim.SGD(model_torch.parameters(), lr=0.0001)
    ett_ns_torch = get_ett_ns(model_torch, crit_torch, sgd_torch, train_loader, iterations)


    model_custom = models.resnet18(num_classes=100)
    wrap_modules(model_custom, PrecisionFlag.BFP)
    model_custom = model_custom.to(device)
    crit_custom = nn.CrossEntropyLoss().to(device)
    sgd_custom = optim.SGD(model_custom.parameters(), lr=0.0001)
    ett_ns_custom = get_ett_ns(model_custom, crit_custom, sgd_custom, train_loader, iterations)

    print(f"[ETT] iteration: {iterations-1}")
    print(f"torch  : {ett_ns_torch / (iterations-1) / 1000_000:.5f}ms")
    print(f"custom : {ett_ns_custom / (iterations-1) / 1000_000:.5f}ms")