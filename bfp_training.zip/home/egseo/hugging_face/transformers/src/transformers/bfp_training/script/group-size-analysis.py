# python main_from_torch.py -a resnet50 --epochs 40 --gpu 3 --lr 0.1 --seed 4096 --dataset-type 1 --num-classes 100 --batch-size 128 --use-bfp --bfp-m-bits 4 --no-thres-w --no-thres-a
import os
import argparse
import subprocess
import torchvision.models as models

BFP_HOME = os.environ["BFP_HOME"]

model_names = sorted(name for name in models.__dict__
    if name.islower() and not name.startswith("__")
    and callable(models.__dict__[name]))

parser = argparse.ArgumentParser(description='FP/BFP training script')
parser.add_argument('-a', '--arch', metavar='ARCH',
                    choices=model_names,
                    help='model architecture: ' +
                        ' | '.join(model_names))
parser.add_argument('--epochs', type=int, metavar='N',
                    help='number of total epochs to run')
parser.add_argument('-b', '--batch-size', type=int,
                    metavar='N',
                    help='mini-batch size (default: 256), this is the total '
                         'batch size of all GPUs on the current node when '
                         'using Data Parallel or Distributed Data Parallel')
parser.add_argument('--lr', '--learning-rate', type=float,
                    metavar='LR', help='initial learning rate', dest='lr')
parser.add_argument('--seed', type=int,
                    help='seed for initializing training.')
parser.add_argument('--gpu', type=int,
                    help='GPU id to use.')
parser.add_argument('--dataset-type', default=None, type=int,
                    help='type of dataset (0: CIFAR-10, 1: CIFAR-100, 2: ImageNet)')
parser.add_argument('--num-classes', default=None, type=int,
                    help='number of class labels')
parser.add_argument('--test-iteration', default=None, type=int,
                    help='set number of iterations to test')


if __name__ == "__main__":
    args = parser.parse_args()

    if args.test_iteration is None:
        test_iteration_info = ""
    else:
        test_iteration_info = f" --test-iteration {args.test_iteration}"

    exec_file = f"{BFP_HOME}/notebooks/main_from_torch.py"

    common_command = f"python {exec_file} -a {args.arch} --epochs {args.epochs} --gpu {args.gpu} --lr {args.lr} --seed {args.seed} --dataset-type {args.dataset_type} --num-classes {args.num_classes} --batch-size {args.batch_size}"

    commands = [
        f"{common_command} --use-bfp --bfp-m-bits 4 --no-thres-w --no-thres-a --group-size 64{test_iteration_info}",
        f"{common_command} --use-bfp --bfp-m-bits 4 --no-thres-w --no-thres-a --group-size 32{test_iteration_info}",
        f"{common_command} --use-bfp --bfp-m-bits 4 --no-thres-w --no-thres-a --group-size 8{test_iteration_info}",
        f"{common_command} --use-bfp --bfp-m-bits 4 --no-thres-w --no-thres-a --group-size 4{test_iteration_info}",
        # f"{common_command} --use-bfp --bfp-m-bits 4 --no-thres-w --no-thres-a --group-size 2{test_iteration_info}",
        # f"{common_command} --use-bfp --bfp-m-bits 4 --no-thres-w --no-thres-a --group-size 1{test_iteration_info}",
        # f"{common_command}{test_iteration_info}",
    ]

    for i in range(len(commands)):
        proc = subprocess.Popen(commands[i], shell=True)
        output, error = proc.communicate()
        # print(output)

        if proc.returncode == 0:
            print("done")
        else:
            print(f"error: {output} {error}")
            exit()
